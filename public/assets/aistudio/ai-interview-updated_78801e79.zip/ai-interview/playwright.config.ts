import { defineConfig } from '@playwright/test';

// Start the backend (`python backend/app.py` with AI_PROVIDER=mock) and the web host
// (`npm run dev:server`) first, then run `npm run test:e2e`.
// CHROMIUM_PATH / CHROMIUM_ARGS are optional overrides for environments where
// `npx playwright install chromium` is not possible.
export default defineConfig({
  testDir: './e2e',
  fullyParallel: false,
  workers: 1,
  timeout: 60_000,
  reporter: [['list']],
  use: {
    baseURL: process.env.E2E_BASE_URL || 'http://localhost:3000',
    launchOptions: {
      executablePath: process.env.CHROMIUM_PATH || undefined,
      args: process.env.CHROMIUM_ARGS ? process.env.CHROMIUM_ARGS.split(' ') : undefined,
    },
  },
});
