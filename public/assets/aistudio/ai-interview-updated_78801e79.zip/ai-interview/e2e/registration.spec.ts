import { expect, test } from '@playwright/test';
import { PASSWORD, fillStep1, fillStep2, fillStep3, next, register, unique } from './helpers';

test.describe('registration validation (frontend)', () => {
  test('step 1 blocks invalid names and keeps the user on the step', async ({ page }) => {
    await page.goto('/onboarding');
    for (const bad of ['12345', '   ', 'A', '<b>x</b>']) {
      await page.getByLabel('Full name').fill(bad);
      await page.getByLabel('Date of birth').fill('2001-05-17');
      await next(page);
      await expect(page.getByText('Step 1 of 3')).toBeVisible();
      await expect(page.getByRole('alert').first()).toBeVisible();
    }
    await page.getByLabel('Full name').fill("Mary-Jane O'Neil");
    await next(page);
    await expect(page.getByText('Step 2 of 3')).toBeVisible();
  });

  test('step 2 rejects bad email, mobile, language and passwords', async ({ page }) => {
    await page.goto('/onboarding');
    await fillStep1(page); await next(page);

    for (const email of ['1234567890', 'abc', 'user@', '@example.com', '   ']) {
      await page.getByLabel('Email address').fill(email);
      await next(page);
      await expect(page.getByText('Step 2 of 3')).toBeVisible();
      await expect(page.getByText(/valid email|Enter your email/)).toBeVisible();
    }
    await page.getByLabel('Email address').fill('harish@example.com');
    await expect(page.getByText(/valid email/)).toBeHidden();

    for (const mobile of ['987654321', '98765432101', 'abcdefghij', '98765abc10', '0123456789', '+919876543210']) {
      await page.getByLabel('Mobile number').fill(mobile);
      await page.getByLabel('Mobile number').blur();
      await expect(page.locator('#' + (await page.getByLabel('Mobile number').getAttribute('id')) + '-error')).toBeVisible();
      // never silently truncated or rewritten
      await expect(page.getByLabel('Mobile number')).toHaveValue(mobile);
    }
    await page.getByLabel('Mobile number').fill('9876543210');

    // language is a closed list: only supported options, no free typing of numbers
    const options = await page.getByLabel('Preferred language').locator('option').allTextContents();
    expect(options).toEqual(['Select a language', 'English', 'Telugu', 'Hindi']);
    await next(page);
    await expect(page.getByText('Step 2 of 3')).toBeVisible();
    await expect(page.getByText('Select your preferred language.')).toBeVisible();
    await page.getByLabel('Preferred language').selectOption('Telugu');

    await page.getByLabel(/^Password\*?$/).fill('short');
    await page.getByLabel('Confirm password').fill('different1');
    await next(page);
    await expect(page.getByText('Step 2 of 3')).toBeVisible();
    await page.getByLabel(/^Password\*?$/).fill(PASSWORD);
    await page.getByLabel('Confirm password').fill(PASSWORD);
    await next(page);
    await expect(page.getByText('Step 3 of 3')).toBeVisible();
  });

  test('step 3 rejects invalid graduation years; typing and pasting are not truncated', async ({ page }) => {
    await page.goto('/onboarding');
    await fillStep1(page); await next(page);
    await fillStep2(page, unique('year')); await next(page);
    const year = page.getByLabel('Graduation (passing) year');
    for (const bad of ['1234567890', 'abcd', '20255', '202', '1850', '2099', '']) {
      await year.fill(bad);
      await page.getByRole('button', { name: 'Create account' }).click();
      await expect(page.getByText('Step 3 of 3')).toBeVisible();
      await expect(page.getByText(/year/i).filter({ hasText: /4-digit|between|Enter your graduation/ }).first()).toBeVisible();
      await expect(year).toHaveValue(bad);
    }
    // typed (key by key) 10 digits is also kept as typed and rejected
    await year.fill('');
    await year.pressSequentially('1234567890');
    await expect(year).toHaveValue('1234567890');
    await expect(page.getByText('Enter a 4-digit year, for example 2025.')).toBeVisible();
  });

  test('values persist across Back/Next and unrelated errors do not erase valid fields', async ({ page }) => {
    const email = unique('persist');
    await page.goto('/onboarding');
    await fillStep1(page, 'Persist Person'); await next(page);
    await fillStep2(page, email, '9123456789', 'Hindi'); await next(page);
    await fillStep3(page, '2024');
    await page.getByRole('button', { name: 'Back' }).click();
    await expect(page.getByLabel('Email address')).toHaveValue(email);
    await expect(page.getByLabel('Mobile number')).toHaveValue('9123456789');
    await expect(page.getByLabel('Preferred language')).toHaveValue('Hindi');
    await page.getByLabel('Mobile number').fill('bad');
    await next(page);
    await expect(page.getByText('Step 2 of 3')).toBeVisible();
    await expect(page.getByLabel('Email address')).toHaveValue(email);
    await page.getByLabel('Mobile number').fill('9123456789');
    await next(page);
    await page.getByRole('button', { name: 'Back' }).click(); await page.getByRole('button', { name: 'Back' }).click();
    await expect(page.getByLabel('Full name')).toHaveValue('Persist Person');
  });

  test('successful registration, then duplicate registration is refused with a path to sign in', async ({ page }) => {
    const email = unique('dup');
    await register(page, email);
    await expect(page.getByText('Account created. Sign in to get started.')).toBeVisible();
    await expect(page.getByLabel('Email')).toHaveValue(email);

    // second attempt with the same email (different casing)
    await page.goto('/onboarding');
    await fillStep1(page); await next(page);
    await fillStep2(page, email.toUpperCase()); await next(page);
    await fillStep3(page);
    await page.getByRole('button', { name: 'Create account' }).click();
    await expect(page.getByText(/already exists/).first()).toBeVisible();
    await expect(page.getByText('Step 2 of 3')).toBeVisible(); // jumps back to the offending field
    await page.getByRole('link', { name: 'Go to sign in' }).click();
    await expect(page).toHaveURL(/\/login$/);
  });

  test('the backend rejects invalid data even when the form is bypassed', async ({ request }) => {
    const base = { fullName: 'Valid Name', dob: '2001-05-17', gender: '', address: '', qualification: '', preferredLanguage: 'English', mobile: '9876543210',
      education: { degree: 'B.Tech', college: 'Example College', specialization: '', graduationYear: '2025', cgpa: '' } };
    const cases: [string, Record<string, unknown>][] = [
      ['mobile', { mobile: '98765abc10' }], ['preferredLanguage', { preferredLanguage: '123' }], ['email', { email: '1234567890' }],
      ['education.graduationYear', { education: { ...base.education, graduationYear: '1234567890' } }],
    ];
    for (const [field, override] of cases) {
      const body = { email: (override.email as string) || unique('bypass'), password: PASSWORD, profile: { ...base, ...override } };
      const response = await request.post('/api/auth/register', { data: body });
      expect(response.status(), field).toBe(422);
      expect(Object.keys((await response.json()).fields), field).toContain(field);
    }
  });
});
