import { expect, test } from '@playwright/test';
import type { BrowserContext } from '@playwright/test';
import { PASSWORD, login, register, unique } from './helpers';

test.describe.serial('authentication lifecycle', () => {
  const email = unique('life');
  let storage: Awaited<ReturnType<BrowserContext['storageState']>>;

  test('register, wrong password fails, correct password reaches dashboard', async ({ page }) => {
    await register(page, email);
    await login(page, email, 'wrong-password-1');
    await expect(page.getByRole('alert')).toContainText('Invalid email or password.');
    await expect(page).toHaveURL(/\/login$/);
    await page.getByLabel('Email').fill('nobody-here@example.com');
    await page.getByLabel(/^Password\*?$/).fill('whatever-123');
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page.getByRole('alert')).toContainText('Invalid email or password.'); // identical message: no account enumeration
    await login(page, email);
    await expect(page).toHaveURL(/\/dashboard$/);
    storage = await page.context().storageState();
  });

  test('refresh keeps the user signed in and registration/login are not offered', async ({ browser }) => {
    const context = await browser.newContext({ storageState: storage });
    const page = await context.newPage();
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/dashboard$/);
    await page.reload();
    await expect(page).toHaveURL(/\/dashboard$/);
    await expect(page.getByText(email)).toBeVisible();

    // clicking Get Started / Login while signed in never leads to account creation
    await page.goto('/');
    await expect(page.locator('header').getByRole('link', { name: 'Go to dashboard' })).toBeVisible();
    await expect(page.locator('header').getByRole('link', { name: 'Get Started' })).toHaveCount(0);
    await page.goto('/onboarding');
    await expect(page).toHaveURL(/\/dashboard$/);
    await page.goto('/login');
    await expect(page).toHaveURL(/\/dashboard$/);
    await context.close();
  });

  test('closing and reopening the browser (new context, same cookies) keeps the session', async ({ browser }) => {
    const reopened = await browser.newContext({ storageState: storage });
    const page = await reopened.newPage();
    await page.goto('/history');
    await expect(page).toHaveURL(/\/history$/);
    await reopened.close();
  });

  test('signed-out visitors are sent to login and returned to their page afterwards', async ({ page }) => {
    await page.goto('/history');
    await expect(page).toHaveURL(/\/login$/);
    await login(page, email);
    await expect(page).toHaveURL(/\/history$/);
  });

  test('unknown routes show a 404 inside the app, not a blank page', async ({ browser }) => {
    const context = await browser.newContext({ storageState: storage });
    const page = await context.newPage();
    await page.goto('/definitely-not-a-page');
    await expect(page.getByRole('heading', { name: 'Page not found' })).toBeVisible();
    await context.close();
  });

  test('logout ends the session; back button and protected API are refused', async ({ browser }) => {
    const context = await browser.newContext({ storageState: storage });
    const page = await context.newPage();
    await page.goto('/dashboard');
    await page.getByRole('button', { name: 'Sign out' }).first().click();
    await expect(page).toHaveURL(/\/login$/);
    await page.goBack();
    await expect(page).not.toHaveURL(/\/dashboard$/);
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login$/);
    const api = await page.request.get('/api/interviews');
    expect(api.status()).toBe(401);
    // the old cookie, replayed in a fresh context, is no longer valid server-side
    const replay = await (await context.browser()!.newContext({ storageState: storage })).newPage();
    expect((await replay.request.get('/api/auth/me')).status()).toBe(401);
    await replay.goto('/dashboard');
    await expect(replay).toHaveURL(/\/login$/);
    await context.close();
  });

  test('theme toggle class drives dark styles (dark variant fix)', async ({ page }) => {
    await page.goto('/login');
    await expect(page.locator('main')).toBeVisible();
    await page.evaluate(() => document.documentElement.classList.add('dark'));
    const bg = await page.evaluate(() => getComputedStyle(document.querySelector('main')!.parentElement!).backgroundColor);
    expect(bg).not.toBe('rgb(255, 255, 255)');
  });
});

test('protected API rejects unauthenticated calls', async ({ request }) => {
  for (const path of ['/api/interviews', '/api/performance', '/api/resumes', '/api/saved-jobs', '/api/auth/me']) {
    expect((await request.get(path)).status(), path).toBe(401);
  }
  expect(PASSWORD.length).toBeGreaterThanOrEqual(8);
});
