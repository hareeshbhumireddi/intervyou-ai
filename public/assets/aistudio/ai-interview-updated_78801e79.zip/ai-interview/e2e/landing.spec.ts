import { expect, test } from '@playwright/test';

test.describe('landing page', () => {
  test('header exposes working Login and Get Started actions', async ({ page }) => {
    await page.goto('/');
    const header = page.locator('header');
    for (const label of ['Home', 'Features', 'How It Works']) await expect(header.getByRole('link', { name: label, exact: true })).toBeVisible();
    await header.getByRole('link', { name: 'Login' }).click();
    await expect(page).toHaveURL(/\/login$/);
    await expect(page.getByRole('heading', { name: 'Welcome back' })).toBeVisible();
    await page.goBack();
    await page.locator('header').getByRole('link', { name: 'Get Started' }).click();
    await expect(page).toHaveURL(/\/onboarding$/);
    await expect(page.getByRole('heading', { name: 'Create your account' })).toBeVisible();
  });

  test('hero calls to action work and sections are anchored', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('main').getByRole('link', { name: 'Sign in' }).click();
    await expect(page).toHaveURL(/\/login$/);
    await page.goto('/');
    await page.getByRole('main').getByRole('link', { name: 'Start practising' }).click();
    await expect(page).toHaveURL(/\/onboarding$/);
    await page.goto('/#how-it-works');
    await expect(page.getByRole('heading', { name: 'How it works' })).toBeInViewport();
    await page.reload();
    await expect(page).toHaveURL(/#how-it-works$/);
  });

  test('mobile layout has a working menu', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 800 });
    await page.goto('/');
    await expect(page.locator('header').getByRole('link', { name: 'Login' })).toBeHidden();
    await page.getByRole('button', { name: 'Open menu' }).click();
    await page.locator('#mobile-menu').getByRole('link', { name: 'Login' }).click();
    await expect(page).toHaveURL(/\/login$/);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    expect(overflow).toBe(false);
  });
});
