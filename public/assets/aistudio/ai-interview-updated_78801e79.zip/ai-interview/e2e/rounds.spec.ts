import { expect, test } from '@playwright/test';
import type { Page } from '@playwright/test';
import { PASSWORD, register, unique } from './helpers';

const RESUME = `Harish Kumar
harish@example.com | +91 98765 43210 | github.com/harish

Summary
Computer Science graduate building full-stack web applications.

Experience
Software Intern, Example Technologies
- Built a REST API with Flask and PostgreSQL serving 5000 daily requests
- Reduced report generation time by 40% by optimizing SQL queries and adding Redis caching
- Implemented unit testing with pytest, raising coverage from 35% to 82%
- Automated deployments with Docker and CI/CD, cutting release time by 3 hours
- Collaborated with a team of 6 in an agile process using Git and Jira

Projects
Interview Preparation Platform
- Developed a React and Node.js application used by 200 students

Education
B.Tech in Computer Science, 2025

Skills
Python, Java, JavaScript, React, Node.js, SQL, PostgreSQL, Docker, Git, REST API, Linux, Agile
${'Additional detail about collaboration and delivery. '.repeat(40)}`;

const JOB_DESCRIPTION = `Backend Engineer. Build REST APIs with Python and Flask, work with PostgreSQL and Redis, deploy on AWS using Docker and Kubernetes.
Strong Python, PostgreSQL and Kubernetes skills required. Kubernetes experience is essential.`;

async function uploadResume(page: Page, name: string, content: string) {
  const input = page.locator('input[type=file]');
  await expect(input).toBeEnabled(); // the page disables upload until it has loaded the current resume
  await input.setInputFiles({ name, mimeType: 'text/plain', buffer: Buffer.from(content) });
}

async function signedIn(page: Page, tag: string) {
  const email = unique(tag);
  await register(page, email);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel(/^Password\*?$/).fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL(/\/dashboard$/);
}

async function startRound(page: Page, roundName: RegExp, startIfReady = true) {
  await page.goto('/setup');
  await page.getByRole('button', { name: /Private/ }).first().click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: /Software Developer/ }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: /Beginner/ }).click();
  await page.getByRole('radio', { name: roundName }).click();
  await expect(page.getByRole('radio', { name: roundName })).toHaveAttribute('aria-checked', 'true');
  await page.getByRole('button', { name: 'Continue' }).click();
  if (startIfReady) await page.getByRole('button', { name: 'Start Interview' }).click();
}

test('setup offers every round and only one is selected at a time', async ({ page }) => {
  await signedIn(page, 'rounds');
  await page.goto('/setup');
  await page.getByRole('button', { name: /Private/ }).first().click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: /Software Developer/ }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  const radios = page.getByRole('radio');
  await expect(radios).toHaveCount(6);
  await expect(radios.filter({ hasText: 'Mixed' })).toHaveAttribute('aria-checked', 'true');
  await radios.filter({ hasText: 'HR Round' }).click();
  await expect(page.locator('[role=radio][aria-checked=true]')).toHaveCount(1);
});

test('HR round asks only HR questions', async ({ page }) => {
  await signedIn(page, 'hr');
  await startRound(page, /HR Round/);
  await expect(page.getByPlaceholder('Click microphone to speak or type here...')).toBeVisible({ timeout: 20_000 });
  await expect(page.getByText('Category: HR')).toBeVisible();
  await expect(page.getByText('HR Round').first()).toBeVisible();
});

test('coding round: code editor, no camera/mic, rubric feedback, history badge and filter', async ({ page }) => {
  await signedIn(page, 'code');
  await startRound(page, /Coding Round/);
  const editor = page.getByLabel('Code editor');
  await expect(editor).toBeVisible({ timeout: 20_000 });
  await expect(page.getByText('Category: Coding')).toBeVisible();
  await expect(page.getByText('Listening...')).toBeHidden();          // voice UI is not shown for coding
  await expect(page.getByRole('button', { name: 'Skip Question' })).toBeVisible();
  await expect(page.getByText('Coding round tips')).toBeVisible();
  await expect(page.getByText(/not executed/i)).toBeVisible();

  // Tab inserts spaces instead of moving focus
  await editor.click();
  await editor.pressSequentially('def solve(nums, target):');
  await page.keyboard.press('Enter');
  await page.keyboard.press('Tab');
  await editor.pressSequentially('if not nums: return []  # Time O(n)');
  expect(await editor.inputValue()).toContain('\n    if not nums');
  await page.getByLabel('Language').selectOption('Python');

  await page.getByRole('button', { name: 'Submit answer' }).click();
  await expect(editor).toHaveValue('', { timeout: 20_000 });
  for (let i = 0; i < 10 && !/report/.test(page.url()); i++) {
    await page.getByRole('button', { name: 'Skip Question' }).click();
    await page.waitForTimeout(700);
  }
  await expect(page).toHaveURL(/\/report\//, { timeout: 30_000 });

  await page.goto('/history');
  await expect(page.getByText('Coding Round').first()).toBeVisible();
  await page.getByLabel('Filter by round').selectOption('HR');
  await expect(page.getByText(/couldn't find any sessions/i)).toBeVisible();
  await page.getByLabel('Filter by round').selectOption('Coding');
  await expect(page.getByText('Coding Round').first()).toBeVisible();
});

test('resume-based round without a resume explains what to do', async ({ page }) => {
  await signedIn(page, 'noresume');
  await startRound(page, /Resume-based Round/);
  await expect(page.getByText(/needs a resume/i)).toBeVisible();
  await expect(page).toHaveURL(/\/setup$/);
});

test('resume-based round uses the uploaded resume', async ({ page }) => {
  await signedIn(page, 'resume');
  await page.goto('/my-resume');
  await uploadResume(page, 'resume.txt', RESUME);
  await expect(page.getByText('resume.txt').first()).toBeVisible({ timeout: 15_000 });
  await startRound(page, /Resume-based Round/);
  await expect(page.getByText('Category: Resume')).toBeVisible({ timeout: 20_000 });
  await expect(page.locator('h2, h3, p').filter({ hasText: /resume|Interview Preparation Platform/i }).first()).toBeVisible();
});

test('ATS score: needs a resume first, then scores it with and without a job description', async ({ page }) => {
  await signedIn(page, 'ats');
  await page.goto('/my-resume');
  await expect(page.getByRole('heading', { name: 'ATS score' })).toBeVisible();
  await expect(page.getByText('Upload your resume above to get your ATS score.')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Analyse my resume' })).toBeDisabled();

  await uploadResume(page, 'resume.txt', RESUME);
  await expect(page.getByRole('button', { name: 'Analyse my resume' })).toBeEnabled({ timeout: 15_000 });

  await page.getByLabel('Target role (optional)').fill('Software Developer');
  await page.getByRole('button', { name: 'Analyse my resume' }).click();
  const score = page.getByTestId('ats-score');
  await expect(score).toBeVisible();
  const base = Number(await score.textContent());
  expect(base).toBeGreaterThanOrEqual(60);
  await expect(page.getByRole('progressbar')).toHaveCount(6);
  await expect(page.getByText('estimate from transparent rules')).toBeVisible();

  await page.getByLabel('Job description (optional)').fill(JOB_DESCRIPTION);
  await page.getByRole('button', { name: 'Analyse again' }).click();
  await expect(page.getByText(/keywords from the job description you pasted/)).toBeVisible();
  await expect(page.getByRole('region', { name: 'Missing keywords' }).getByText('kubernetes')).toBeVisible();
  await expect(page.getByRole('region', { name: 'Matched keywords' }).getByText('python')).toBeVisible();
  await expect(page.getByRole('region', { name: 'How to improve' })).toBeVisible();
});

test('ATS score explains unreadable resumes instead of crashing', async ({ page }) => {
  await signedIn(page, 'atsbad');
  await page.goto('/my-resume');
  await uploadResume(page, 'scan.txt', 'tiny');
  await expect(page.getByRole('button', { name: 'Analyse my resume' })).toBeEnabled({ timeout: 15_000 });
  await page.getByRole('button', { name: 'Analyse my resume' }).click();
  await expect(page.getByText(/could not read any text/i)).toBeVisible();
  await expect(page.getByText('Something went wrong')).toHaveCount(0);
});
