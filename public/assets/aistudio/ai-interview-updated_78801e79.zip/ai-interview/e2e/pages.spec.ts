import { expect, test } from '@playwright/test';
import { PASSWORD, register, unique } from './helpers';

const ROUTES = ['/dashboard', '/my-interview', '/my-resume', '/performance', '/setup', '/practice', '/history', '/jobs', '/saved-jobs', '/settings', '/profile'];

test('every signed-in page renders for a brand-new user without crashing', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  const email = unique('pages');
  await register(page, email);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel(/^Password\*?$/).fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL(/\/dashboard$/);
  // Check straight after sign-in, with no reload: this is the render path that
  // once crashed because the login response replaced the user without `stats`.
  await expect(page.getByText('Interviews Taken')).toBeVisible();
  await expect(page.getByText('Something went wrong')).toHaveCount(0);

  for (const route of ROUTES) {
    await page.goto(route);
    await expect(page.getByRole('navigation').or(page.locator('aside')).first()).toBeVisible();
    await page.waitForTimeout(400);
    await expect(page.getByText('Something went wrong'), `${route} crashed`).toHaveCount(0);
  }
  await page.goto('/dashboard');
  await expect(page.getByText('Interviews Taken')).toBeVisible();
  expect(errors, errors.join('\n')).toEqual([]);
});
