import { expect, test } from '@playwright/test';
import { PASSWORD, login, register, unique } from './helpers';

const STRONG = 'Because reliability matters, I designed a retry strategy for the payment service. For example, I implemented exponential backoff and idempotency keys, which reduced duplicate charges by 90%. The result was fewer support tickets and I learned to test failure modes early.';

test('mock interview: setup, answer, skip, report, history, performance', async ({ page }) => {
  const email = unique('iv');
  await register(page, email);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel(/^Password\*?$/).fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL(/\/dashboard$/);

  // New user: history is an empty state, not fabricated data.
  await page.goto('/history');
  await expect(page.getByText(/no (interviews|sessions|history)|haven.t|nothing|empty/i).first()).toBeVisible();

  await page.goto('/setup');
  await expect(page.getByTestId('mock-ai-banner')).toBeVisible();
  await page.getByRole('button', { name: /Private/ }).first().click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: /Software Developer/ }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: /Beginner/ }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: 'Start Interview' }).click();

  await expect(page).toHaveURL(/\/room$/);
  const answerBox = page.getByPlaceholder('Click microphone to speak or type here...');
  await expect(answerBox).toBeVisible({ timeout: 20_000 });
  await expect(page.getByText(/Category:/)).toBeVisible();

  // Answer question 1 (strong) and 2 (weak), then skip the rest until the report opens.
  for (const answer of [STRONG, 'yes']) {
    await answerBox.fill(answer);
    await page.getByRole('button', { name: 'Submit answer' }).click();
    await expect(answerBox).toHaveValue('', { timeout: 20_000 });
  }
  for (let i = 0; i < 20 && !/\/report\//.test(page.url()); i++) {
    await page.getByRole('button', { name: 'Skip Question' }).click();
    await page.waitForTimeout(700);
  }

  await expect(page).toHaveURL(/\/report\/[\w-]+/, { timeout: 30_000 });
  await expect(page.getByText(/simulated/i).first()).toBeVisible();

  // Real saved data shows up in history and performance.
  await page.goto('/history');
  await expect(page.getByText(/Software Developer/).first()).toBeVisible();
  await page.goto('/performance');
  await expect(page.getByText('No completed interviews yet.')).toHaveCount(0);
  await expect(page.getByText('Sessions completed').locator('xpath=..')).toContainText('1');
});
