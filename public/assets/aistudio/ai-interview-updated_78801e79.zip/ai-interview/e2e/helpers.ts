import { expect } from '@playwright/test';
import type { Page } from '@playwright/test';

export const unique = (tag = 'u') => `${tag}${Date.now()}${Math.floor(Math.random() * 1e4)}@example.com`;
export const PASSWORD = 'correct-horse-1';

export async function fillStep1(page: Page, name = 'Harish Kumar', dob = '2001-05-17') {
  await page.getByLabel('Full name').fill(name);
  await page.getByLabel('Date of birth').fill(dob);
}
export async function fillStep2(page: Page, email: string, mobile = '9876543210', language = 'English', password = PASSWORD) {
  await page.getByLabel('Email address').fill(email);
  await page.getByLabel('Mobile number').fill(mobile);
  await page.getByLabel('Preferred language').selectOption(language);
  await page.getByLabel(/^Password\*?$/).fill(password);
  await page.getByLabel('Confirm password').fill(password);
}
export async function fillStep3(page: Page, year = '2025') {
  await page.getByLabel('Degree').selectOption('B.Tech');
  await page.getByLabel('College / university').fill('Example Institute of Technology');
  await page.getByLabel('Graduation (passing) year').fill(year);
}
export const next = (page: Page) => page.getByRole('button', { name: /^Next/ }).click();

export async function register(page: Page, email: string) {
  await page.goto('/onboarding');
  await fillStep1(page); await next(page);
  await fillStep2(page, email); await next(page);
  await fillStep3(page);
  await page.getByRole('button', { name: 'Create account' }).click();
  await expect(page).toHaveURL(/\/login$/);
}
export async function login(page: Page, email: string, password = PASSWORD) {
  await page.getByLabel('Email').fill(email);
  await page.getByLabel(/^Password\*?$/).fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();
}
