import pytest

from validators import (
    validate_email_address,
    validate_graduation_year,
    validate_language,
    validate_mobile,
    validate_name,
    validate_password,
)


@pytest.mark.parametrize("value,ok", [
    ("2025", True), ("1999", True), ("2030", True),
    ("1234567890", False), ("abcd", False), ("", False), ("   ", False),
    ("20255", False), ("202", False), ("1850", False), ("2099", False),
    ("20.5", False), ("-202", False), ("\u0662\u0660\u0662\u0665", False),  # Arabic-Indic digits
])
def test_graduation_year(value, ok):
    assert (validate_graduation_year(value)[1] is None) is ok


@pytest.mark.parametrize("value,ok", [
    ("harish@example.com", True), ("  Harish@Example.com  ", True), ("jos\u00e9@ex\u00e4mple.org", True),
    ("1234567890", False), ("abc", False), ("user@", False), ("@example.com", False),
    ("a@b", False), ("", False), ("   ", False), ("two@@example.com", False), ("sp ace@example.com", False),
    ("a" * 250 + "@example.com", False),
])
def test_email(value, ok):
    assert (validate_email_address(value)[1] is None) is ok


def test_email_is_normalised_to_lowercase():
    assert validate_email_address("  Harish@Example.COM ")[0] == "harish@example.com"


@pytest.mark.parametrize("value,ok", [
    ("9876543210", True), ("6000000000", True), (" 9876543210 ", True),
    ("987654321", False), ("98765432101", False), ("abcdefghij", False), ("98765abc10", False),
    ("0123456789", False), ("1234567890", False), ("5876543210", False),
    ("+919876543210", False), ("98765 43210", False), ("98765-43210", False), ("", False),
    ("\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660", False),  # non-ASCII digits
])
def test_mobile(value, ok):
    assert (validate_mobile(value)[1] is None) is ok


@pytest.mark.parametrize("value,ok", [
    ("English", True), ("Telugu", True), ("Hindi", True),
    ("123", False), ("1", False), ("", False), ("French", False), ("english", False), ("en-US", False),
])
def test_language(value, ok):
    assert (validate_language(value)[1] is None) is ok


@pytest.mark.parametrize("value,ok", [
    ("Bhargavi Konda", True), ("O'Brien-Smith", True), ("Jos\u00e9 \u00c1lvarez", True), ("\u0c2d\u0c30\u0c4d\u0c17\u0c35\u0c3f", True),
    ("12345", False), ("   ", False), ("", False), ("A", False), ("<script>alert(1)</script>", False),
    ("John3", False), ("x" * 101, False), ("--", False),
])
def test_name(value, ok):
    assert (validate_name(value)[1] is None) is ok


def test_name_whitespace_is_collapsed():
    assert validate_name("  Harish    Kumar ")[0] == "Harish Kumar"


@pytest.mark.parametrize("value,ok", [("12345678", True), ("short", False), ("        ", False), ("x" * 129, False), (None, False)])
def test_password(value, ok):
    assert (validate_password(value) is None) is ok
