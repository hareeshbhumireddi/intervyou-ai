import io

import pytest

from tests.samples import GOOD_RESUME


def start(client, round_key, **extra):
    body = {"role": "Software Developer", "sector": "Private", "difficulty": "Intermediate", "numQuestions": 4, "round": round_key}
    body.update(extra)
    return client.post("/api/interviews", json=body)


def test_config_lists_rounds(client):
    keys = [r["key"] for r in client.get("/api/config").get_json()["rounds"]]
    assert keys == ["HR", "Technical", "Behavioral", "Coding", "Resume", "Mixed"]


@pytest.mark.parametrize("round_key,label,category", [
    ("HR", "HR Round", "HR"), ("Technical", "Technical Round", "Technical"),
    ("Behavioral", "Behavioral Round", "Behavioral"), ("Coding", "Coding Round", "Coding"),
])
def test_each_round_generates_matching_questions_and_is_persisted(signed_in, round_key, label, category):
    response = start(signed_in, round_key)
    assert response.status_code == 201, response.get_json()
    interview = response.get_json()["interview"]
    assert interview["round"] == round_key and interview["roundLabel"] == label and interview["interviewType"] == label
    assert len(interview["questions"]) == 4
    assert {q["category"] for q in interview["questions"]} <= {category, "Situational"}
    again = signed_in.get(f"/api/interviews/{interview['id']}").get_json()["interview"]
    assert again["round"] == round_key
    listed = signed_in.get("/api/interviews").get_json()["interviews"]
    assert listed[0]["round"] == round_key


def test_hr_round_has_no_technical_questions(signed_in):
    questions = start(signed_in, "HR", numQuestions=8).get_json()["interview"]["questions"]
    assert all(q["category"] == "HR" for q in questions)


def test_coding_questions_are_problems_with_examples(signed_in):
    questions = start(signed_in, "Coding", difficulty="Beginner", numQuestions=3).get_json()["interview"]["questions"]
    assert all(q["category"] == "Coding" for q in questions)
    assert all("Example" in q["question"] or "example" in q["question"].lower() for q in questions)


def test_invalid_round_is_rejected(signed_in):
    response = start(signed_in, "Marketing")
    assert response.status_code == 400 and response.get_json()["code"] == "invalid_round"


def test_no_round_keeps_previous_behaviour(signed_in):
    body = {"role": "Software Developer", "sector": "Private", "difficulty": "Beginner", "numQuestions": 2}
    interview = signed_in.post("/api/interviews", json=body).get_json()["interview"]
    assert interview["round"] is None and interview["interviewType"] == "Software Developer"


def test_resume_round_requires_a_readable_resume(signed_in):
    response = start(signed_in, "Resume")
    assert response.status_code == 400 and response.get_json()["code"] == "resume_required"


def test_resume_round_uses_resume_content(signed_in):
    signed_in.post("/api/resume", data={"resume": (io.BytesIO(GOOD_RESUME.encode()), "cv.txt")}, content_type="multipart/form-data")
    questions = start(signed_in, "Resume", numQuestions=6).get_json()["interview"]["questions"]
    text = " ".join(q["question"] for q in questions)
    assert all(q["category"] == "Resume" for q in questions)
    assert "Interview Preparation Platform" in text or "Flask" in text or "python" in text.lower()


GOOD_CODE = '''# language: Python
def two_sum(nums, target):
    """Hash map approach. Time O(n), Space O(n)."""
    if not nums:
        return []
    seen = {}
    for index, value in enumerate(nums):
        need = target - value
        if need in seen:
            return [seen[need], index]
        seen[value] = index
    return []
'''


def test_coding_answers_use_the_code_rubric_and_say_code_was_not_run(signed_in):
    interview = start(signed_in, "Coding", numQuestions=2).get_json()["interview"]
    q1, q2 = [q["id"] for q in interview["questions"]]
    good = signed_in.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": q1, "answer": GOOD_CODE}).get_json()["answer"]["evaluation"]
    weak = signed_in.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": q2, "answer": "I would loop over it"}).get_json()["answer"]["evaluation"]
    names = [c["name"] for c in good["scoring"]["criteria"]]
    assert names == ["Approach & completeness", "Complexity awareness", "Edge cases", "Code quality"]
    assert good["scoring"]["codeExecuted"] is False and "not executed" in good["feedback"]
    assert good["score"] >= 75 and weak["score"] < good["score"] - 30
    assert any("Edge cases" in w or "incomplete" in w for w in weak["weaknesses"])


def test_non_coding_rounds_keep_the_text_rubric(signed_in):
    interview = start(signed_in, "HR", numQuestions=1).get_json()["interview"]
    evaluation = signed_in.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": interview["questions"][0]["id"], "answer": "Because I enjoy solving problems, for example in my last project, and the result was good."}).get_json()["answer"]["evaluation"]
    assert evaluation["scoring"]["criteria"][0]["name"] == "Relevance to the question"


def test_oversized_answers_are_refused(signed_in):
    interview = start(signed_in, "Coding", numQuestions=1).get_json()["interview"]
    response = signed_in.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": interview["questions"][0]["id"], "answer": "x" * 20001})
    assert response.status_code == 400


def test_full_coding_round_completes_with_report(signed_in):
    interview = start(signed_in, "Coding", numQuestions=2).get_json()["interview"]
    iid = interview["id"]
    signed_in.post(f"/api/interviews/{iid}/answers", json={"questionId": interview["questions"][0]["id"], "answer": GOOD_CODE})
    signed_in.post(f"/api/interviews/{iid}/skip", json={"questionId": interview["questions"][1]["id"]})
    done = signed_in.post(f"/api/interviews/{iid}/complete").get_json()["interview"]
    assert done["status"] == "completed" and done["round"] == "Coding" and done["overallReport"]["simulated"] is True


def test_mock_reports_only_contain_measurable_categories(signed_in):
    interview = start(signed_in, "HR", numQuestions=1).get_json()["interview"]
    signed_in.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": interview["questions"][0]["id"], "answer": "Because I enjoy it, for example in my last project, and the result was good."})
    report = signed_in.post(f"/api/interviews/{interview['id']}/complete").get_json()["interview"]["overallReport"]
    metrics = report["detailedMetrics"]
    for unmeasurable in ("eyeContact", "timeManagement", "listeningSkills", "pronunciation"):
        assert unmeasurable not in metrics
        assert unmeasurable in report["notMeasured"]
    assert "grammar" in metrics and "fluency" in metrics


def test_coding_report_also_drops_spoken_language_metrics(signed_in):
    interview = start(signed_in, "Coding", numQuestions=1).get_json()["interview"]
    signed_in.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": interview["questions"][0]["id"], "answer": GOOD_CODE})
    report = signed_in.post(f"/api/interviews/{interview['id']}/complete").get_json()["interview"]["overallReport"]
    assert "grammar" not in report["detailedMetrics"] and "fluency" not in report["detailedMetrics"]
    assert {"grammar", "fluency"} <= set(report["notMeasured"])
    assert "technicalKnowledge" in report["detailedMetrics"]
