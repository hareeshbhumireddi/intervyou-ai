"""Test fixtures: an isolated temporary database, never the developer's real one."""
import os
import sys
import tempfile
from pathlib import Path

_TMP = tempfile.mkdtemp(prefix="intervyou-pytest-")
os.environ["DATABASE_URL"] = f"sqlite:///{Path(_TMP) / 'test.sqlite3'}"
os.environ["UPLOAD_FOLDER"] = str(Path(_TMP) / "uploads")
os.environ["SECRET_KEY"] = "pytest-secret-key-not-for-production-0123456789"
os.environ["AI_PROVIDER"] = "mock"
os.environ.pop("FLASK_ENV", None)
os.environ.pop("GEMINI_API_KEY", None)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from app import app as flask_app  # noqa: E402
from extensions import db  # noqa: E402


@pytest.fixture()
def app():
    uri = flask_app.config["SQLALCHEMY_DATABASE_URI"]
    assert _TMP in uri, "Refusing to reset a database that is not the temporary test database."
    flask_app.config.update(TESTING=True, AI_PROVIDER="mock", LOGIN_MAX_ATTEMPTS=8)
    with flask_app.app_context():
        db.drop_all()
        db.create_all()
    from auth import _failures
    _failures.clear()
    yield flask_app
    with flask_app.app_context():
        db.session.remove()


@pytest.fixture()
def client(app):
    return app.test_client()


def valid_profile(**overrides):
    profile = {
        "fullName": "Harish Kumar",
        "dob": "2001-05-17",
        "gender": "Male",
        "mobile": "9876543210",
        "address": "Visakhapatnam, Andhra Pradesh",
        "preferredLanguage": "English",
        "qualification": "Bachelor of Technology",
        "education": {"degree": "B.Tech", "college": "Example Institute of Technology", "specialization": "Computer Science", "graduationYear": "2025", "cgpa": "8.5"},
    }
    profile.update(overrides)
    return profile


def register_payload(email="harish@example.com", password="correct-horse-1", **profile_overrides):
    return {"email": email, "password": password, "profile": valid_profile(**profile_overrides)}


@pytest.fixture()
def make_user(client):
    def _make(email="harish@example.com", password="correct-horse-1"):
        response = client.post("/api/auth/register", json=register_payload(email, password))
        assert response.status_code == 201, response.get_json()
        return email, password
    return _make


@pytest.fixture()
def signed_in(client, make_user):
    email, password = make_user()
    response = client.post("/api/auth/login", json={"email": email, "password": password})
    assert response.status_code == 200
    return client
