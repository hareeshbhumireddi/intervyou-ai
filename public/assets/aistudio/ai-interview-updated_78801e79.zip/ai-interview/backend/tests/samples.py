GOOD_RESUME = """Harish Kumar
harish@example.com | +91 98765 43210 | github.com/harish | linkedin.com/in/harish

Summary
Computer Science graduate who builds full-stack web applications with Python, React and SQL.

Experience
Software Intern, Example Technologies
- Built a REST API with Flask and PostgreSQL serving 5000 daily requests
- Reduced report generation time by 40% by optimizing SQL queries and adding Redis caching
- Implemented unit testing with pytest, raising coverage from 35% to 82%
- Automated deployments with Docker and a CI/CD pipeline, cutting release time by 3 hours
- Collaborated with a team of 6 in an agile sprint process using Git and Jira

Projects
Interview Preparation Platform
- Developed a React and Node.js web application used by 200 students for mock interviews
- Designed data structures and algorithms practice module with 150 problems
Online Library System
- Created a Java and MySQL application with object-oriented design

Education
B.Tech in Computer Science, Example Institute of Technology, 2025, CGPA 8.5

Skills
Python, Java, JavaScript, TypeScript, React, Node.js, SQL, PostgreSQL, MongoDB, Docker, Git, REST API, Linux, Agile

Certifications
AWS Cloud Practitioner, 2024
""" + ("Additional detail about collaboration and delivery. " * 40)

POOR_RESUME = "I am a hard working person and i want a job. I know computers and i can learn quickly and i am good with people and teamwork and i am very honest and punctual and ready to work any time anywhere for the company with good salary and growth please consider my application thank you very much for your time"

JOB_DESCRIPTION = """We are hiring a Backend Engineer. You will build REST APIs with Python and Flask, work with PostgreSQL and Redis,
deploy services on AWS using Docker and Kubernetes, and write automated tests. Experience with microservices and GraphQL is a plus.
Strong Python, PostgreSQL and Kubernetes skills required. Kubernetes experience is essential."""
