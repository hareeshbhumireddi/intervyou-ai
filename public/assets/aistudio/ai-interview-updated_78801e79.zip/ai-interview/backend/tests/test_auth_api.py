from datetime import datetime, timedelta, timezone

import pytest

from tests.conftest import register_payload, valid_profile
from extensions import db
from models import AuthSession, User


def count_users(app):
    with app.app_context():
        return User.query.count()


# ---- registration -----------------------------------------------------------

def test_register_valid_creates_account_and_hashes_password(app, client):
    response = client.post("/api/auth/register", json=register_payload())
    assert response.status_code == 201
    body = response.get_json()
    assert body["user"]["email"] == "harish@example.com"
    assert "password" not in str(body).lower()
    with app.app_context():
        user = User.query.one()
        assert user.password_hash != "correct-horse-1"
        assert user.password_hash.startswith(("scrypt:", "pbkdf2:"))


@pytest.mark.parametrize("field,payload_kwargs,error_key", [
    ("email numeric", {"email": "1234567890"}, "email"),
    ("email no domain", {"email": "user@"}, "email"),
    ("email no local", {"email": "@example.com"}, "email"),
    ("email abc", {"email": "abc"}, "email"),
    ("short password", {"password": "short"}, "password"),
    ("mobile letters", {"mobile": "abcdefghij"}, "mobile"),
    ("mobile mixed", {"mobile": "98765abc10"}, "mobile"),
    ("mobile short", {"mobile": "987654321"}, "mobile"),
    ("mobile long", {"mobile": "98765432101"}, "mobile"),
    ("mobile leading zero", {"mobile": "0123456789"}, "mobile"),
    ("language numeric", {"preferredLanguage": "123"}, "preferredLanguage"),
    ("language unsupported", {"preferredLanguage": "Klingon"}, "preferredLanguage"),
    ("name numeric", {"fullName": "12345"}, "fullName"),
    ("name whitespace", {"fullName": "     "}, "fullName"),
])
def test_register_rejects_invalid_input_on_the_backend(app, client, field, payload_kwargs, error_key):
    kwargs = dict(payload_kwargs)
    email = kwargs.pop("email", "harish@example.com")
    password = kwargs.pop("password", "correct-horse-1")
    response = client.post("/api/auth/register", json=register_payload(email, password, **kwargs))
    assert response.status_code == 422, response.get_json()
    assert error_key in response.get_json()["fields"]
    assert count_users(app) == 0


@pytest.mark.parametrize("year", ["1234567890", "abcd", "", "20255", "1850"])
def test_register_rejects_invalid_graduation_year(app, client, year):
    profile = valid_profile()
    profile["education"]["graduationYear"] = year
    response = client.post("/api/auth/register", json={"email": "harish@example.com", "password": "correct-horse-1", "profile": profile})
    assert response.status_code == 422
    assert "education.graduationYear" in response.get_json()["fields"]
    assert count_users(app) == 0


def test_register_reports_all_field_errors_at_once(client):
    response = client.post("/api/auth/register", json=register_payload("1234567890", "x", mobile="abc", preferredLanguage="9", fullName="1"))
    fields = response.get_json()["fields"]
    assert {"email", "password", "mobile", "preferredLanguage", "fullName"} <= set(fields)


def test_register_ignores_unknown_profile_keys(app, client):
    payload = register_payload()
    payload["profile"]["isAdmin"] = True
    payload["profile"]["bio"] = "x" * 100000
    client.post("/api/auth/register", json=payload)
    with app.app_context():
        assert "isAdmin" not in User.query.one().profile_data
        assert "bio" not in User.query.one().profile_data


def test_register_rejects_non_object_bodies(client):
    assert client.post("/api/auth/register", data="not json", content_type="application/json").status_code == 422
    assert client.post("/api/auth/register", json=["a"]).status_code == 422


def test_duplicate_registration_does_not_create_second_account(app, client, make_user):
    make_user()
    for email in ("harish@example.com", "HARISH@EXAMPLE.COM", "  Harish@Example.com "):
        response = client.post("/api/auth/register", json=register_payload(email))
        assert response.status_code == 409
        assert response.get_json()["code"] == "account_exists"
    assert count_users(app) == 1


# ---- login / session --------------------------------------------------------

def test_login_valid_then_me_returns_user(client, make_user):
    email, password = make_user()
    assert client.get("/api/auth/me").status_code == 401
    login = client.post("/api/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200
    cookie = login.headers.get("Set-Cookie", "")
    assert "HttpOnly" in cookie and "SameSite=Lax" in cookie
    me = client.get("/api/auth/me")
    assert me.status_code == 200 and me.get_json()["user"]["email"] == email


def test_login_errors_do_not_reveal_whether_account_exists(client, make_user):
    email, _ = make_user()
    wrong_password = client.post("/api/auth/login", json={"email": email, "password": "wrong-password-1"})
    unknown_email = client.post("/api/auth/login", json={"email": "nobody@example.com", "password": "wrong-password-1"})
    assert wrong_password.status_code == unknown_email.status_code == 401
    assert wrong_password.get_json() == unknown_email.get_json()


def test_login_rejects_missing_or_non_string_credentials(client, make_user):
    make_user()
    for body in ({}, {"email": "harish@example.com"}, {"email": "harish@example.com", "password": ["x"]}, {"email": None, "password": None}):
        assert client.post("/api/auth/login", json=body).status_code == 401


def test_login_is_throttled_after_repeated_failures(client, make_user):
    email, password = make_user()
    for _ in range(8):
        assert client.post("/api/auth/login", json={"email": email, "password": "bad-password-1"}).status_code == 401
    blocked = client.post("/api/auth/login", json={"email": email, "password": password})
    assert blocked.status_code == 429 and blocked.get_json()["code"] == "too_many_attempts"


def test_logout_revokes_session_on_the_server_even_if_cookie_is_replayed(app, make_user):
    email, password = make_user()
    browser = app.test_client()
    assert browser.post("/api/auth/login", json={"email": email, "password": password}).status_code == 200
    stolen_cookie = browser.get_cookie("intervyou_session")
    assert stolen_cookie is not None

    assert browser.post("/api/auth/logout").status_code == 200
    assert browser.get("/api/auth/me").status_code == 401

    attacker = app.test_client()
    attacker.set_cookie("intervyou_session", stolen_cookie.value)
    assert attacker.get("/api/auth/me").status_code == 401, "copied cookie must not survive logout"


def test_expired_session_is_rejected_with_specific_code(app, signed_in):
    assert signed_in.get("/api/auth/me").status_code == 200
    with app.app_context():
        record = AuthSession.query.one()
        record.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.session.commit()
    response = signed_in.get("/api/auth/me")
    assert response.status_code == 401 and response.get_json()["code"] == "session_expired"
    assert signed_in.get("/api/interviews").status_code == 401


def test_login_issues_new_session_each_time(app, make_user):
    email, password = make_user()
    first, second = app.test_client(), app.test_client()
    first.post("/api/auth/login", json={"email": email, "password": password})
    second.post("/api/auth/login", json={"email": email, "password": password})
    with app.app_context():
        assert AuthSession.query.count() == 2


def test_accounts_persist_beyond_a_single_database_session(app, make_user):
    make_user()
    with app.app_context():
        db.session.remove()
        assert User.query.filter_by(email="harish@example.com").count() == 1


# ---- protected API ----------------------------------------------------------

@pytest.mark.parametrize("method,path", [
    ("get", "/api/interviews"), ("get", "/api/performance"), ("get", "/api/resumes"),
    ("get", "/api/resumes/file"), ("get", "/api/saved-jobs"), ("put", "/api/auth/profile"),
    ("post", "/api/interviews"), ("delete", "/api/resumes"),
    ("post", "/api/interviews/abc/answers"), ("post", "/api/interviews/abc/complete"), ("get", "/api/interviews/abc"),
])
def test_protected_endpoints_require_authentication(client, method, path):
    response = getattr(client, method)(path)
    assert response.status_code == 401, f"{method.upper()} {path} -> {response.status_code}"


def test_cross_site_writes_are_refused(client, make_user):
    email, password = make_user()
    response = client.post("/api/auth/login", json={"email": email, "password": password}, headers={"Origin": "https://evil.example"})
    assert response.status_code == 403
    response = client.post("/api/auth/login", json={"email": email, "password": password}, headers={"Sec-Fetch-Site": "cross-site"})
    assert response.status_code == 403


def test_api_responses_are_not_cacheable(signed_in):
    assert signed_in.get("/api/auth/me").headers["Cache-Control"] == "no-store"


def test_profile_update_applies_same_validation(signed_in):
    bad = signed_in.put("/api/auth/profile", json={"email": "harish@example.com", "profile": valid_profile(mobile="98765abc10")})
    assert bad.status_code == 422 and "mobile" in bad.get_json()["fields"]
    good = signed_in.put("/api/auth/profile", json={"email": "harish@example.com", "profile": valid_profile(mobile="9123456780")})
    assert good.status_code == 200 and good.get_json()["user"]["mobile"] == "9123456780"


def test_profile_update_cannot_take_another_users_email(app, client, make_user):
    make_user("other@example.com")
    make_user("harish@example.com")
    client.post("/api/auth/login", json={"email": "harish@example.com", "password": "correct-horse-1"})
    response = client.put("/api/auth/profile", json={"email": "other@example.com", "profile": valid_profile()})
    assert response.status_code == 409


def test_public_config_exposes_supported_options(client):
    body = client.get("/api/config").get_json()
    assert body["languages"] == ["English", "Telugu", "Hindi"]
    assert body["aiMode"] == "mock"
    assert body["graduationYear"]["min"] == 1970


def test_profile_update_preserves_certificates_avatar_and_resume_text(signed_in):
    profile = valid_profile(
        certificates=[{"title": "AWS Cloud Practitioner", "provider": "Amazon", "date": "2025-01-10"}, "junk"],
        avatarUrl="data:image/png;base64,iVBORw0KGgo=",
        resumeText="Built things.",
        skills=["Python", "React"],
    )
    body = signed_in.put("/api/auth/profile", json={"email": "harish@example.com", "profile": profile}).get_json()["user"]
    assert body["certificates"] == [{"title": "AWS Cloud Practitioner", "provider": "Amazon", "date": "2025-01-10"}]
    assert body["avatarUrl"].startswith("data:image/png") and body["resumeText"] == "Built things."
    bad = valid_profile(avatarUrl="javascript:alert(1)")
    assert signed_in.put("/api/auth/profile", json={"email": "harish@example.com", "profile": bad}).get_json()["user"]["avatarUrl"] == ""
