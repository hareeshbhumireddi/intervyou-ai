import io

import pytest

from ats import analyze_resume
from tests.samples import GOOD_RESUME, JOB_DESCRIPTION, POOR_RESUME


def test_good_resume_scores_well_and_breakdown_adds_up():
    result = analyze_resume(GOOD_RESUME, role="Software Developer")
    assert result["score"] >= 75, result
    assert sum(c["earned"] for c in result["breakdown"]) == result["score"]
    assert sum(c["weight"] for c in result["breakdown"]) == 100
    assert all(0 <= c["earned"] <= c["weight"] for c in result["breakdown"])
    assert {"experience", "education", "skills", "projects"} <= set(result["sectionsFound"])
    assert "python" in result["matchedKeywords"]
    assert "estimate" in result["disclaimer"]


def test_poor_resume_scores_much_lower_with_actionable_advice():
    good = analyze_resume(GOOD_RESUME, role="Software Developer")["score"]
    poor = analyze_resume(POOR_RESUME, role="Software Developer")
    assert poor["score"] < good - 30
    assert poor["grade"] == "Needs work"
    joined = " ".join(poor["suggestions"])
    assert "email" in joined and "Experience" in joined


def test_job_description_changes_keyword_matching_and_lists_gaps():
    result = analyze_resume(GOOD_RESUME, job_description=JOB_DESCRIPTION)
    assert "job description" in result["keywordSource"]
    assert "kubernetes" in result["missingKeywords"]
    assert "python" in result["matchedKeywords"]
    no_jd = analyze_resume(GOOD_RESUME, role="Software Developer")
    assert "job description" not in no_jd["keywordSource"]


def test_keyword_matching_handles_symbols_and_whole_words():
    text = "Skills: C++, Node.js, CI/CD, and java. " + "filler words here " * 10
    result = analyze_resume(text, role="software developer")
    assert "java" in result["matchedKeywords"] and "ci/cd" in result["matchedKeywords"]
    # "javascript" must not be matched just because "java" appears
    assert "javascript" not in result["matchedKeywords"]


def test_unreadable_text_is_rejected():
    for text in ("", "   ", "short"):
        with pytest.raises(ValueError):
            analyze_resume(text)


def upload(client, content: bytes, name="resume.txt"):
    return client.post("/api/resume", data={"resume": (io.BytesIO(content), name)}, content_type="multipart/form-data")


def test_ats_api_requires_login(client):
    assert client.post("/api/resumes/ats", json={}).status_code == 401


def test_ats_api_without_resume_is_404_with_guidance(signed_in):
    response = signed_in.post("/api/resumes/ats", json={})
    assert response.status_code == 404 and response.get_json()["code"] == "resume_required"


def test_ats_api_scores_uploaded_resume_with_job_description(signed_in):
    assert upload(signed_in, GOOD_RESUME.encode()).status_code == 201
    response = signed_in.post("/api/resumes/ats", json={"jobDescription": JOB_DESCRIPTION, "role": "Backend Engineer"})
    assert response.status_code == 200
    ats = response.get_json()["ats"]
    assert 0 <= ats["score"] <= 100 and "kubernetes" in ats["missingKeywords"]


def test_ats_api_unreadable_resume_is_422_not_a_crash(signed_in):
    assert upload(signed_in, b"\x00\x01\x02 tiny").status_code == 201
    response = signed_in.post("/api/resumes/ats", json={})
    assert response.status_code == 422 and response.get_json()["code"] == "resume_unreadable"


def test_ats_api_accepts_pasted_text_and_caps_input(signed_in):
    response = signed_in.post("/api/resumes/ats", json={"text": GOOD_RESUME * 5, "jobDescription": "x" * 50000})
    assert response.status_code == 200


def test_users_only_get_their_own_resume_scored(app, client, make_user):
    make_user("a@example.com"); make_user("b@example.com")
    client.post("/api/auth/login", json={"email": "a@example.com", "password": "correct-horse-1"})
    upload(client, GOOD_RESUME.encode())
    client.post("/api/auth/logout")
    client.post("/api/auth/login", json={"email": "b@example.com", "password": "correct-horse-1"})
    assert client.post("/api/resumes/ats", json={}).status_code == 404
