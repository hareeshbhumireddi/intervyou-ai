import pytest

from tests.conftest import register_payload


def start(client, **overrides):
    body = {"role": "Software Engineer", "sector": "Private", "difficulty": "Intermediate", "numQuestions": 3, "preferredLanguage": "English"}
    body.update(overrides)
    return client.post("/api/interviews", json=body)


def test_full_mock_interview_flow(signed_in):
    response = start(signed_in)
    assert response.status_code == 201
    interview = response.get_json()["interview"]
    assert len(interview["questions"]) == 3
    interview_id = interview["id"]
    q1, q2, q3 = [q["id"] for q in interview["questions"]]

    strong = ("Because reliability matters, I designed a retry strategy for the payment service. For example, I implemented exponential backoff "
              "and idempotency keys, which reduced duplicate charges by 90%. The result was fewer support tickets, and I learned to test failure modes early.")
    ok = signed_in.post(f"/api/interviews/{interview_id}/answers", json={"questionId": q1, "answer": strong})
    assert ok.status_code == 200
    evaluation = ok.get_json()["answer"]["evaluation"]
    assert evaluation["simulated"] is True and "Simulated" in evaluation["feedback"]
    assert evaluation["scoring"]["method"] == "rubric"
    assert sum(c["weight"] for c in evaluation["scoring"]["criteria"]) == 100
    strong_score = evaluation["score"]

    weak = signed_in.post(f"/api/interviews/{interview_id}/answers", json={"questionId": q2, "answer": "yes"})
    assert weak.get_json()["answer"]["evaluation"]["score"] < strong_score

    assert signed_in.post(f"/api/interviews/{interview_id}/skip", json={"questionId": q3}).status_code == 200

    done = signed_in.post(f"/api/interviews/{interview_id}/complete")
    assert done.status_code == 200
    completed = done.get_json()["interview"]
    assert completed["status"] == "completed"
    assert completed["isSimulated"] is True
    assert completed["overallReport"]["simulated"] is True
    assert 0 <= completed["overallReport"]["overallScore"] <= 100

    history = signed_in.get("/api/interviews").get_json()["interviews"]
    assert [i["id"] for i in history] == [interview_id]
    performance = signed_in.get("/api/performance").get_json()["performance"]
    assert performance["totalInterviews"] == 1
    assert performance["history"][0]["totalQuestions"] == 3


def test_new_user_has_empty_history_and_zero_performance(signed_in):
    assert signed_in.get("/api/interviews").get_json()["interviews"] == []
    performance = signed_in.get("/api/performance").get_json()["performance"]
    assert performance["totalInterviews"] == 0 and performance["averageScore"] == 0


def test_empty_answer_is_rejected(signed_in):
    interview = start(signed_in).get_json()["interview"]
    response = signed_in.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": interview["questions"][0]["id"], "answer": "   "})
    assert response.status_code == 400


def test_start_validation(signed_in):
    assert start(signed_in, role="").status_code == 400
    assert start(signed_in, sector="Nonsense").status_code == 400


def test_users_cannot_access_each_others_interviews(app, client, make_user):
    make_user("owner@example.com")
    client.post("/api/auth/login", json={"email": "owner@example.com", "password": "correct-horse-1"})
    interview = start(client).get_json()["interview"]
    qid = interview["questions"][0]["id"]
    client.post("/api/auth/logout")

    make_user("intruder@example.com")
    client.post("/api/auth/login", json={"email": "intruder@example.com", "password": "correct-horse-1"})
    assert client.get(f"/api/interviews/{interview['id']}").status_code == 404
    assert client.post(f"/api/interviews/{interview['id']}/answers", json={"questionId": qid, "answer": "hello there friend"}).status_code == 404
    assert client.post(f"/api/interviews/{interview['id']}/complete").status_code == 404
    assert client.get("/api/interviews").get_json()["interviews"] == []


def test_real_provider_without_key_fails_cleanly_not_with_a_crash(app, signed_in):
    app.config["AI_PROVIDER"] = "gemini"
    response = start(signed_in)
    assert response.status_code == 503
    assert "GEMINI_API_KEY" in response.get_json()["error"]
    # unrelated parts keep working
    assert signed_in.get("/api/auth/me").status_code == 200
    assert signed_in.get("/api/config").get_json()["aiMode"] == "unconfigured"


def test_mock_provider_is_refused_in_production(monkeypatch):
    import importlib

    import config
    monkeypatch.setenv("FLASK_ENV", "production")
    monkeypatch.setenv("AI_PROVIDER", "mock")
    monkeypatch.setenv("SECRET_KEY", "x" * 40)
    monkeypatch.setenv("DATABASE_URL", "sqlite:///x.db")
    with pytest.raises(RuntimeError, match="development only"):
        importlib.reload(config)
    monkeypatch.setenv("FLASK_ENV", "")
    monkeypatch.setenv("AI_PROVIDER", "mock")
    importlib.reload(config)  # restore for other tests


def test_production_requires_explicit_secret_key(monkeypatch):
    import importlib

    import config
    monkeypatch.setenv("FLASK_ENV", "production")
    monkeypatch.setenv("AI_PROVIDER", "gemini")
    monkeypatch.setenv("DATABASE_URL", "sqlite:///x.db")
    monkeypatch.delenv("SECRET_KEY", raising=False)
    with pytest.raises(RuntimeError, match="SECRET_KEY"):
        importlib.reload(config)
    monkeypatch.setenv("FLASK_ENV", "")
    monkeypatch.setenv("SECRET_KEY", "pytest-secret-key-not-for-production-0123456789")
    importlib.reload(config)
