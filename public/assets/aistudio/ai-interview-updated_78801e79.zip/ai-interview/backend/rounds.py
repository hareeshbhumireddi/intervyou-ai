"""Interview rounds: HR, Technical, Behavioral, Coding, Resume-based, Mixed.

The round is stored in the existing ``interviews.interview_type`` column as its
label (for example "Coding Round"), so no database migration is needed.
"""

from __future__ import annotations

ROUND_LABELS = {
    "HR": "HR Round",
    "Technical": "Technical Round",
    "Behavioral": "Behavioral Round",
    "Coding": "Coding Round",
    "Resume": "Resume-based Round",
    "Mixed": "Mixed Round",
}
LABEL_TO_ROUND = {label: key for key, label in ROUND_LABELS.items()}

MAX_ANSWER_CHARS = 20_000


def normalise_round(value) -> str | None:
    """Return a canonical round key, ``None`` if absent, or raise ValueError if unknown."""
    if value is None or str(value).strip() == "":
        return None
    candidate = str(value).strip()
    lookup = {key.lower(): key for key in ROUND_LABELS}
    lookup.update({"behavioural": "Behavioral", "resume-based": "Resume", "resume based": "Resume"})
    key = lookup.get(candidate.lower())
    if key is None:
        raise ValueError("Choose a valid interview round: " + ", ".join(ROUND_LABELS) + ".")
    return key


def round_from_type(interview_type: str | None) -> str | None:
    return LABEL_TO_ROUND.get(interview_type or "")


def question_guidance(round_key: str | None) -> str:
    """Round-specific instructions appended to the question-generation prompt."""
    return {
        "HR": "Ask only HR-round questions: motivation, strengths and weaknesses, career goals, salary and notice-period expectations, relocation, work culture fit.",
        "Technical": "Ask only technical-round questions: core concepts, debugging, design trade-offs and hands-on knowledge for the role. No coding problems that need an editor.",
        "Behavioral": "Ask only behavioral questions answerable with the STAR method: conflict, failure, leadership, deadlines, teamwork.",
        "Coding": "Ask only coding problems. Each question must contain a clear problem statement, one input/output example and constraints, solvable in any common language. Set category to 'Coding'.",
        "Resume": "Ask only questions drawn from the candidate's resume: specific projects, technologies and claims listed there. Quote the project or skill by name.",
        "Mixed": "Use a varied mix of role-specific, behavioral, and situational questions.",
    }.get(round_key or "Mixed", "Use a varied mix of role-specific, behavioral, and situational questions.")


def evaluation_guidance(round_key: str | None) -> str:
    if round_key == "Coding":
        return ("The answer is source code (possibly with notes). The code was NOT executed, so judge it by reading it. "
                "Score correctness of the approach, time and space complexity, edge-case handling and code quality. "
                "Mention complexity in feedback and list missing edge cases in missingPoints.")
    if round_key == "HR":
        return "Judge honesty, clarity, professionalism, motivation and culture fit."
    if round_key == "Behavioral":
        return "Judge use of the STAR structure (Situation, Task, Action, Result) and concrete, measurable outcomes."
    if round_key == "Resume":
        return "Judge whether the candidate can explain and defend what they claim on their resume with specific, credible detail."
    return ""
