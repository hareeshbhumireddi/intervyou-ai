from functools import wraps

from flask import Blueprint, g, jsonify, request
from sqlalchemy.exc import SQLAlchemyError

from auth import resolve_session, unauthorized
from extensions import db
from models import SavedJob

saved_jobs_bp = Blueprint("saved_jobs", __name__, url_prefix="/api")


@saved_jobs_bp.before_request
def load_signed_in_user():
    user, reason = resolve_session()
    if user is None:
        return unauthorized(reason)
    g.current_user = user
    return None


def serialize_saved_job(saved_job):
    return {
        "id": saved_job.id,
        "jobId": saved_job.source_job_id,
        "title": saved_job.job_title,
        "company": saved_job.company,
        "location": saved_job.location,
        "applyLink": saved_job.job_url,
        "savedAt": saved_job.saved_at.isoformat(),
    }


@saved_jobs_bp.get("/saved-jobs")
def list_saved_jobs():
    jobs = SavedJob.query.filter_by(user_id=g.current_user.id).order_by(SavedJob.saved_at.desc()).all()
    return jsonify(savedJobs=[serialize_saved_job(job) for job in jobs])


@saved_jobs_bp.post("/saved-jobs")
def create_saved_job():
    payload = request.get_json(silent=True) or {}
    title = str(payload.get("jobTitle") or payload.get("title") or "").strip()
    company = str(payload.get("company") or "").strip()
    if not title or not company:
        return jsonify(error="Job title and company are required."), 400

    source_job_id = str(payload.get("jobId") or "").strip() or None
    saved_job = None
    if source_job_id:
        saved_job = SavedJob.query.filter_by(user_id=g.current_user.id, source_job_id=source_job_id).first()
    if not saved_job:
        saved_job = SavedJob.query.filter_by(user_id=g.current_user.id, job_title=title, company=company).first()
    if saved_job:
        return jsonify(savedJob=serialize_saved_job(saved_job)), 200

    saved_job = SavedJob(
        user_id=g.current_user.id,
        source_job_id=source_job_id,
        job_title=title[:200],
        company=company[:200],
        location=str(payload.get("location") or "")[:200],
        job_url=str(payload.get("applyLink") or payload.get("jobUrl") or "")[:2048],
    )
    db.session.add(saved_job)
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(error="Job could not be saved. Please try again."), 500
    return jsonify(savedJob=serialize_saved_job(saved_job)), 201


@saved_jobs_bp.delete("/saved-jobs/<int:saved_job_id>")
def remove_saved_job(saved_job_id):
    saved_job = SavedJob.query.filter_by(id=saved_job_id, user_id=g.current_user.id).first()
    if not saved_job:
        return jsonify(error="Saved job was not found."), 404
    db.session.delete(saved_job)
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(error="Saved job could not be removed. Please try again."), 500
    return jsonify(message="Saved job removed.")
