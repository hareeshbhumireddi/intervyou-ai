"""Session handling shared by every protected endpoint.

The browser holds a signed, HttpOnly cookie containing only a random session
token. The server stores the SHA-256 hash of that token in ``auth_sessions``
with an absolute expiry and a revocation timestamp, so:

* logout really invalidates the session server-side,
* an expired session is rejected even if the cookie is still presented,
* the cookie never contains a user id or any profile data.
"""

import hashlib
import secrets
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from functools import wraps

from flask import current_app, g, jsonify, session
from sqlalchemy import or_

from extensions import db
from models import AuthSession, User

SESSION_KEY = "sid"


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _aware(moment: datetime) -> datetime:
    # SQLite returns naive datetimes even for timezone=True columns; we always store UTC.
    return moment if moment.tzinfo else moment.replace(tzinfo=timezone.utc)


def start_session(user: User) -> None:
    """Create a fresh server-side session and put its token in the cookie."""
    session.clear()  # drop any previous identity (prevents session fixation)
    now = datetime.now(timezone.utc)
    AuthSession.query.filter(
        AuthSession.user_id == user.id,
        or_(AuthSession.expires_at < now, AuthSession.revoked_at.isnot(None)),
    ).delete(synchronize_session=False)
    token = secrets.token_urlsafe(32)
    db.session.add(AuthSession(
        user_id=user.id,
        token_hash=_hash(token),
        expires_at=now + current_app.config["PERMANENT_SESSION_LIFETIME"],
    ))
    db.session.commit()
    session.permanent = True
    session[SESSION_KEY] = token


def resolve_session():
    """Return ``(user, reason)``. ``reason`` is None, 'missing', 'expired' or 'invalid'."""
    token = session.get(SESSION_KEY)
    if not token or not isinstance(token, str):
        return None, "missing"
    record = AuthSession.query.filter_by(token_hash=_hash(token)).first()
    if record is None or record.revoked_at is not None:
        session.clear()
        return None, "invalid"
    if _aware(record.expires_at) <= datetime.now(timezone.utc):
        session.clear()
        return None, "expired"
    user = db.session.get(User, record.user_id)
    if user is None:
        session.clear()
        return None, "invalid"
    return user, None


def end_session() -> None:
    """Revoke the current session on the server and clear the cookie."""
    token = session.get(SESSION_KEY)
    if token and isinstance(token, str):
        record = AuthSession.query.filter_by(token_hash=_hash(token)).first()
        if record and record.revoked_at is None:
            record.revoked_at = datetime.now(timezone.utc)
            db.session.commit()
    session.clear()


def unauthorized(reason):
    if reason == "expired":
        return jsonify(error="Your session has expired. Please sign in again.", code="session_expired"), 401
    return jsonify(error="Please sign in to continue.", code="unauthenticated"), 401


def authenticated(handler):
    @wraps(handler)
    def wrapped(*args, **kwargs):
        user, reason = resolve_session()
        if user is None:
            return unauthorized(reason)
        g.current_user = user
        return handler(*args, **kwargs)

    return wrapped


# --- Login throttling (in-memory, per process) ---------------------------------
# Protects against password guessing. For multi-process deployments use a
# shared store (e.g. Redis) instead; documented in the README.
_failures: dict[str, deque] = defaultdict(deque)


def _prune(key: str, window: int) -> deque:
    bucket = _failures[key]
    cutoff = time.monotonic() - window
    while bucket and bucket[0] < cutoff:
        bucket.popleft()
    return bucket


def login_blocked(key: str) -> int:
    """Return seconds until another attempt is allowed (0 if not blocked)."""
    window = current_app.config["LOGIN_WINDOW_SECONDS"]
    bucket = _prune(key, window)
    if len(bucket) >= current_app.config["LOGIN_MAX_ATTEMPTS"]:
        return max(1, int(window - (time.monotonic() - bucket[0])))
    return 0


def record_login_failure(key: str) -> None:
    _prune(key, current_app.config["LOGIN_WINDOW_SECONDS"]).append(time.monotonic())


def clear_login_failures(key: str) -> None:
    _failures.pop(key, None)
