"""ATS-style resume analysis.

This is a transparent, rule-based *estimate* of how well a resume would survive
automated screening. It is not the score any particular employer's applicant
tracking system would give (those are proprietary and differ per company), and
it says so in its output. Every point is explained so it can be improved.

Scoring (100 points)
  Contact details ........ 10   email, phone, profile/portfolio link
  Section structure ...... 20   experience, education, skills, projects, ...
  Keyword match .......... 30   against the pasted job description, or role keywords
  Impact & achievements .. 15   bullets, action verbs, quantified results
  Length & readability ... 15   word count, bullet length
  Parsing safety ......... 10   readable text, odd symbols, shouting caps
"""

from __future__ import annotations

import re
from collections import Counter

# --------------------------------------------------------------------------- #
# Vocabulary                                                                   #
# --------------------------------------------------------------------------- #

SKILL_BANK = [
    "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust", "php", "ruby", "kotlin", "swift", "sql",
    "html", "css", "react", "angular", "vue", "node.js", "express", "next.js", "django", "flask", "fastapi", "spring boot",
    "spring", ".net", "rest api", "graphql", "microservices", "docker", "kubernetes", "aws", "azure", "gcp", "linux",
    "git", "github", "ci/cd", "jenkins", "terraform", "mysql", "postgresql", "mongodb", "redis", "firebase",
    "data structures", "algorithms", "object-oriented", "system design", "unit testing", "junit", "pytest", "selenium",
    "agile", "scrum", "jira", "machine learning", "deep learning", "tensorflow", "pytorch", "pandas", "numpy",
    "scikit-learn", "nlp", "computer vision", "data analysis", "data visualization", "excel", "power bi", "tableau",
    "statistics", "etl", "spark", "hadoop", "airflow", "a/b testing", "figma", "ui/ux", "tailwind", "bootstrap",
    "android", "ios", "flutter", "react native", "cybersecurity", "networking", "devops", "api",
]

ROLE_KEYWORDS = {
    "software": ["python", "java", "javascript", "sql", "git", "rest api", "data structures", "algorithms", "docker", "agile", "unit testing", "linux", "api", "object-oriented", "ci/cd"],
    "frontend": ["javascript", "typescript", "react", "html", "css", "git", "rest api", "responsive", "unit testing", "tailwind", "figma", "api"],
    "backend": ["python", "java", "node.js", "sql", "rest api", "docker", "microservices", "postgresql", "redis", "git", "unit testing", "api", "ci/cd"],
    "full stack": ["javascript", "typescript", "react", "node.js", "sql", "mongodb", "rest api", "git", "docker", "html", "css", "api"],
    "data": ["sql", "python", "excel", "pandas", "data analysis", "data visualization", "power bi", "tableau", "statistics", "etl", "numpy"],
    "machine learning": ["python", "machine learning", "deep learning", "tensorflow", "pytorch", "pandas", "numpy", "scikit-learn", "statistics", "nlp"],
    "devops": ["docker", "kubernetes", "aws", "linux", "ci/cd", "jenkins", "terraform", "git", "devops", "azure"],
    "test": ["selenium", "pytest", "junit", "unit testing", "agile", "jira", "api", "sql", "git"],
}
GENERIC_KEYWORDS = ["communication", "teamwork", "leadership", "problem solving", "project management", "analysis", "planning", "collaboration"]

ACTION_VERBS = {
    "built", "developed", "designed", "implemented", "created", "led", "managed", "improved", "reduced", "increased", "optimized",
    "optimised", "automated", "delivered", "launched", "analyzed", "analysed", "deployed", "integrated", "migrated", "architected",
    "collaborated", "mentored", "streamlined", "tested", "debugged", "refactored", "engineered", "established", "achieved",
    "organized", "organised", "coordinated", "maintained", "researched", "presented", "trained", "won", "published", "wrote",
}

STOPWORDS = {
    "the", "and", "for", "with", "you", "your", "our", "are", "will", "have", "has", "that", "this", "from", "their", "they",
    "who", "can", "all", "any", "not", "but", "per", "use", "using", "used", "work", "working", "team", "role", "years", "year",
    "experience", "ability", "strong", "good", "knowledge", "required", "preferred", "responsibilities", "skills", "candidate",
    "looking", "join", "company", "job", "about", "must", "should", "etc", "including", "such", "other", "more", "also", "well",
    "new", "able", "across", "within", "who", "what", "when", "where", "how", "has", "been", "being", "were", "was", "into",
    "may", "need", "needs", "plus", "bonus", "apply", "position", "opportunity", "build", "help", "make", "ensure", "very",
    "excellent", "based", "high", "level", "related", "relevant", "field", "degree", "bachelor", "master",
}

SECTION_PATTERNS = {
    "experience": (5, r"^(work\s+)?(experience|history)|^(professional\s+)?experience|^internships?|^employment"),
    "education": (5, r"^education|^academic"),
    "skills": (5, r"^(technical\s+|key\s+|core\s+)?skills|^technologies|^competenc"),
    "projects": (3, r"^(academic\s+|personal\s+)?projects?"),
    "summary": (1, r"^(professional\s+)?(summary|objective|profile)|^about\s+me|^career\s+objective"),
    "certifications": (1, r"^certifications?|^achievements?|^awards?|^courses?"),
}

BULLET_RE = re.compile(r"^\s*([\-\u2022\u2023\u25cf\u25aa\u2013\u00b7*]|\d+[.)])\s+(.*\S)")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?<!\d)(\+?\d[\d\s\-()]{8,}\d)(?!\d)")
LINK_RE = re.compile(r"(linkedin\.com|github\.com|gitlab\.com|portfolio|behance\.net|leetcode\.com|https?://)", re.I)
NUMBER_RE = re.compile(r"\d")


def _contains_term(text_lower: str, term: str) -> bool:
    """Whole-word match that also works for terms such as c++, node.js and ci/cd."""
    pattern = r"(?<![a-z0-9])" + re.escape(term.lower()) + r"(?![a-z0-9])"
    return re.search(pattern, text_lower) is not None


def extract_skills(text: str) -> list[str]:
    lowered = text.lower()
    return [skill for skill in SKILL_BANK if _contains_term(lowered, skill)]


def extract_projects(text: str, limit: int = 4) -> list[str]:
    """Project titles/lines from a 'Projects' section, for resume-based questions."""
    lines = [line.strip() for line in text.splitlines()]
    projects: list[str] = []
    in_projects = False
    for line in lines:
        if not line:
            continue
        lowered = line.lower().strip(": ")
        if re.match(SECTION_PATTERNS["projects"][1], lowered) and len(line) < 40:
            in_projects = True
            continue
        if in_projects and any(re.match(p, lowered) for key, (_, p) in SECTION_PATTERNS.items() if key != "projects") and len(line) < 40:
            break
        if in_projects:
            cleaned = BULLET_RE.sub(r"\2", line).strip()
            if 8 <= len(cleaned) <= 160 and not cleaned.lower().startswith(("http", "github")):
                projects.append(cleaned)
        if len(projects) >= limit:
            break
    return projects


def _role_keywords(role: str) -> tuple[list[str], str]:
    lowered = (role or "").lower()
    for key, words in ROLE_KEYWORDS.items():
        if key in lowered:
            return words, f"typical keywords for a “{role.strip()}” role"
    if any(token in lowered for token in ("developer", "engineer", "programmer", "it ")):
        return ROLE_KEYWORDS["software"], f"typical keywords for a “{role.strip()}” role"
    return GENERIC_KEYWORDS + ["python", "sql", "excel"], "general professional keywords (add a job description for a precise match)"


def _jd_keywords(job_description: str) -> list[str]:
    jd = job_description.lower()
    found = [skill for skill in SKILL_BANK if _contains_term(jd, skill)]
    words = re.findall(r"[a-z][a-z+#.\-/]{2,}", jd)
    counts = Counter(w.strip(".-/") for w in words if w.strip(".-/") not in STOPWORDS and len(w.strip(".-/")) >= 4)
    frequent = [w for w, c in counts.most_common(40) if c >= 2 and w not in found and not any(w in f for f in found)]
    return (found + frequent)[:30]


def _criterion(name: str, weight: int, earned: float, note: str) -> dict:
    return {"name": name, "weight": weight, "earned": int(round(max(0, min(weight, earned)))), "note": note}


def analyze_resume(text: str, *, job_description: str = "", role: str = "") -> dict:
    text = (text or "").replace("\r", "")
    words = re.findall(r"\b[\w'+#./-]+\b", text)
    word_count = len(words)
    if word_count < 15:
        raise ValueError("No readable text was found in the resume.")
    lines = [line for line in text.split("\n") if line.strip()]
    lowered = text.lower()
    suggestions: list[str] = []

    # 1. Contact details (10)
    has_email = bool(EMAIL_RE.search(text))
    has_phone = bool(PHONE_RE.search(text))
    has_link = bool(LINK_RE.search(text))
    contact = (4 if has_email else 0) + (3 if has_phone else 0) + (3 if has_link else 0)
    missing_contact = [label for ok, label in ((has_email, "email"), (has_phone, "phone number"), (has_link, "LinkedIn/GitHub/portfolio link")) if not ok]
    if missing_contact:
        suggestions.append("Add your " + ", ".join(missing_contact) + " near the top so recruiters and parsers can find it.")

    # 2. Section structure (20)
    found_sections, missing_sections, section_points = [], [], 0
    for name, (points, pattern) in SECTION_PATTERNS.items():
        hit = any(re.match(pattern, line.strip().lower().strip(": ")) and len(line.strip()) < 45 for line in lines)
        (found_sections if hit else missing_sections).append(name)
        section_points += points if hit else 0
    for name in missing_sections:
        if name in {"experience", "education", "skills"}:
            suggestions.append(f"Add a clearly labelled “{name.title()}” section heading — parsers rely on standard headings.")
    if "projects" in missing_sections:
        suggestions.append("Add a “Projects” section; it is the strongest evidence for students and early-career candidates.")

    # 3. Keyword match (30)
    if job_description.strip():
        keywords, source = _jd_keywords(job_description[:10000]), "the job description you pasted"
    else:
        keywords, source = _role_keywords(role)
    matched = [k for k in keywords if _contains_term(lowered, k)]
    missing_kw = [k for k in keywords if k not in matched]
    ratio = len(matched) / len(keywords) if keywords else 0
    keyword_points = 30 * ratio
    if missing_kw:
        suggestions.append("Work these keywords in where they are truthfully relevant: " + ", ".join(missing_kw[:10]) + ".")

    # 4. Impact & achievements (15)
    bullets = [m.group(2) for m in (BULLET_RE.match(line) for line in lines) if m]
    verb_hits = sum(1 for b in bullets if b.split()[0].lower().strip(",.") in ACTION_VERBS)
    quant_hits = sum(1 for b in bullets if NUMBER_RE.search(b))
    bullet_points = min(5, len(bullets) / 6 * 5)
    verb_points = 5 * (verb_hits / len(bullets)) if bullets else 0
    quant_points = min(5, 5 * (quant_hits / len(bullets)) / 0.35) if bullets else 0
    impact = bullet_points + verb_points + quant_points
    if len(bullets) < 6:
        suggestions.append("Use bullet points for experience and projects (aim for at least 6) instead of dense paragraphs.")
    if bullets and verb_hits / len(bullets) < 0.6:
        suggestions.append("Start each bullet with a strong action verb such as Built, Led, Reduced or Implemented.")
    if bullets and quant_hits / len(bullets) < 0.3:
        suggestions.append("Quantify results (percentages, users, time saved, scale) in at least a third of your bullets.")

    # 5. Length & readability (15)
    if 300 <= word_count <= 800:
        length_points = 10
    elif 200 <= word_count < 300 or 800 < word_count <= 1000:
        length_points = 6
    elif word_count >= 100:
        length_points = 3
    else:
        length_points = 0
    avg_bullet = (sum(len(b.split()) for b in bullets) / len(bullets)) if bullets else 0
    bullet_len_points = 5 if 8 <= avg_bullet <= 30 else (2 if bullets else 0)
    readability = length_points + bullet_len_points
    if word_count < 300:
        suggestions.append(f"Your resume is short ({word_count} words). Add detail on projects, responsibilities and results (300–800 words works best).")
    elif word_count > 1000:
        suggestions.append(f"Your resume is long ({word_count} words). Trim it to one or two pages of the most relevant content.")

    # 6. Parsing safety (10)
    extractable = 4 if word_count >= 100 else 1
    odd = sum(1 for ch in text if ord(ch) > 127 and ch not in "\u2022\u2013\u2014\u2019\u2018\u201c\u201d\u00b7\u2023\u25cf\u25aa\u20b9")
    symbol_points = 3 if odd / max(1, len(text)) < 0.03 else 0
    shouting = sum(1 for line in lines if len(line) > 6 and line.upper() == line and re.search(r"[A-Z]", line))
    caps_points = 3 if shouting / max(1, len(lines)) < 0.25 else 0
    if symbol_points == 0:
        suggestions.append("Remove decorative symbols, icons or unusual characters; they often turn into garbage when parsed.")
    if caps_points == 0:
        suggestions.append("Avoid writing long sections in ALL CAPS; use normal capitalisation except for headings.")
    parsing = extractable + symbol_points + caps_points

    breakdown = [
        _criterion("Contact details", 10, contact, "Found: " + (", ".join(l for ok, l in ((has_email, "email"), (has_phone, "phone"), (has_link, "profile link")) if ok) or "nothing")),
        _criterion("Section structure", 20, section_points, f"Found sections: {', '.join(found_sections) or 'none'}."),
        _criterion("Keyword match", 30, keyword_points, f"{len(matched)} of {len(keywords)} keywords from {source} were found."),
        _criterion("Impact & achievements", 15, impact, f"{len(bullets)} bullets; {verb_hits} start with action verbs; {quant_hits} include numbers."),
        _criterion("Length & readability", 15, readability, f"{word_count} words; average bullet is {avg_bullet:.0f} words."),
        _criterion("Parsing safety", 10, parsing, "Readable text, symbol and capitalisation checks."),
    ]
    score = sum(item["earned"] for item in breakdown)
    grade = "Excellent" if score >= 80 else "Good" if score >= 65 else "Fair" if score >= 50 else "Needs work"
    return {
        "score": score,
        "grade": grade,
        "breakdown": breakdown,
        "keywordSource": source,
        "matchedKeywords": matched,
        "missingKeywords": missing_kw,
        "sectionsFound": found_sections,
        "sectionsMissing": missing_sections,
        "suggestions": suggestions[:10],
        "stats": {"words": word_count, "bullets": len(bullets), "lines": len(lines)},
        "disclaimer": "This is an estimate from transparent rules, not the score a specific employer's ATS would give.",
    }
