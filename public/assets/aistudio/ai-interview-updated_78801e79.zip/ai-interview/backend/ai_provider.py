"""Development-only mock AI provider.

Enabled with ``AI_PROVIDER=mock``. It lets the whole interview flow be
exercised locally without paid API credentials. Everything it returns is
labelled: every object has ``"simulated": true`` and the human-readable text
says so. The mock is refused in production by ``config.py``.

Scoring is a transparent rubric (not random numbers) so a demo user can see
*why* an answer scored what it did.
"""

from __future__ import annotations

import re
import uuid

from ats import SKILL_BANK, extract_projects, extract_skills

PROVIDER_LABEL = "Simulated (development mock mode)"
SIM_PREFIX = "Simulated feedback (development mock mode): "

_STOPWORDS = {
    "about", "above", "after", "again", "also", "and", "are", "because", "been", "being", "between", "both",
    "can", "could", "did", "does", "doing", "each", "for", "from", "had", "has", "have", "how", "into",
    "its", "more", "most", "not", "now", "off", "once", "only", "other", "our", "out", "over", "same",
    "should", "some", "such", "than", "that", "the", "their", "them", "then", "there", "these", "they",
    "this", "those", "through", "under", "until", "very", "was", "were", "what", "when", "where", "which",
    "while", "who", "why", "will", "with", "would", "you", "your", "describe", "explain", "tell", "give",
}

_TECHNICAL = [
    "Explain a core concept every {role} must understand, and how you apply it in practice.",
    "Walk me through how you would diagnose and fix a hard-to-reproduce problem as a {role}.",
    "How do you decide between two competing technical approaches when working as a {role}?",
    "Describe how you ensure quality and correctness in your work as a {role}.",
]
_BEHAVIORAL = [
    "Tell me about a time you faced a significant challenge in a {role} position and how you handled it.",
    "Describe a situation where you disagreed with a teammate. How did you resolve it?",
    "Give an example of a deadline you were at risk of missing and what you did.",
    "Tell me about a mistake you made at work and what you learned from it.",
]
_HR = [
    "Why are you interested in this {role} role, and why now?",
    "Where do you see your career in the next three to five years?",
    "What are your key strengths and one area you are actively improving?",
    "How do you handle pressure and competing priorities?",
]
_SITUATIONAL = [
    "Imagine you are given an unclear task with no guidance on day one as a {role}. What do you do?",
    "A stakeholder asks for a change that you believe is a bad idea. How do you respond?",
]
_STRUCTURE_MARKERS = ("for example", "for instance", "such as", "i built", "i led", "i designed", "i implemented", "when i ", "in my project")
_RESULT_MARKERS = ("result", "improved", "reduced", "increased", "achieved", "learned", "outcome", "%", "saved")
_REASONING_MARKERS = ("because", "therefore", "so that", "trade-off", "tradeoff", "however", "instead", "which means")


def _keywords(text: str) -> set[str]:
    words = re.findall(r"[a-zA-Z][a-zA-Z+#.\-]{3,}", text.lower())
    return {w.strip(".-") for w in words if w not in _STOPWORDS}


CODING_PROBLEMS = {
    "beginner": [
        "Write a function that returns the reverse of a string.\nExample: \"interview\" -> \"weivretni\".\nConstraints: 0 <= length <= 10^5.",
        "Given a list of integers, return the largest value (return None for an empty list).\nExample: [3, 9, 2] -> 9.",
        "Write a function that checks whether a string is a palindrome, ignoring case and spaces.\nExample: \"Never odd or even\" -> true.",
        "Given a list of integers and a target, return the indices of two numbers that add up to the target.\nExample: nums=[2,7,11,15], target=9 -> [0,1].",
        "Count the vowels in a string.\nExample: \"Hello World\" -> 3.",
    ],
    "intermediate": [
        "Given a string of brackets ()[]{}, determine whether it is valid (every bracket closed in the correct order).\nExample: \"([]){}\" -> true, \"(]\" -> false.",
        "Merge overlapping intervals.\nExample: [[1,3],[2,6],[8,10]] -> [[1,6],[8,10]].",
        "Find the length of the longest substring without repeating characters.\nExample: \"abcabcbb\" -> 3.",
        "Group a list of words into anagram groups.\nExample: [\"eat\",\"tea\",\"tan\",\"ate\",\"nat\"] -> [[\"eat\",\"tea\",\"ate\"],[\"tan\",\"nat\"]].",
        "Implement binary search on a sorted array and return the index of the target or -1.\nExample: [1,3,5,7], 5 -> 2.",
    ],
    "advanced": [
        "Design and implement an LRU cache with O(1) get and put operations.\nExample: capacity 2; put(1,1), put(2,2), get(1) -> 1, put(3,3), get(2) -> -1.",
        "Return the k most frequent elements of an integer array in better than O(n log n) time.\nExample: [1,1,1,2,2,3], k=2 -> [1,2].",
        "Detect whether a singly linked list has a cycle, using O(1) extra space.",
        "Count the number of islands in a 2D grid of '1' (land) and '0' (water).\nExample: a grid with three separate groups of 1s -> 3.",
        "Given an array of non-negative integers where each element is your max jump length, decide if you can reach the last index.\nExample: [2,3,1,1,4] -> true.",
    ],
}


def _coding_questions(payload: dict, count: int) -> list[dict]:
    difficulty = str(payload.get("difficulty") or "Intermediate").lower()
    key = "beginner" if difficulty.startswith("beg") else "advanced" if difficulty.startswith("adv") else "intermediate"
    pool = CODING_PROBLEMS[key] + [p for k, v in CODING_PROBLEMS.items() if k != key for p in v]
    return [{"id": str(uuid.uuid4()), "question": pool[i % len(pool)], "category": "Coding", "simulated": True} for i in range(count)]


def _resume_questions(payload: dict, count: int, resume_text: str) -> list[dict]:
    skills = extract_skills(resume_text)
    projects = extract_projects(resume_text)
    templates: list[str] = []
    for project in projects:
        templates.append(f"Your resume mentions: \"{project}\". Walk me through what you built, your role, and the hardest problem you solved.")
    for skill in skills[:6]:
        templates.append(f"You list {skill} on your resume. Describe a concrete situation where you used it and one thing you would do differently.")
    templates += [
        "Which achievement on your resume are you most proud of, and what was the measurable result?",
        "Is there anything on your resume you would not feel confident being questioned about? How are you improving it?",
        "Choose the project on your resume that best matches this role and explain why.",
    ]
    return [{"id": str(uuid.uuid4()), "question": templates[i % len(templates)], "category": "Resume", "simulated": True} for i in range(count)]


def mock_questions(payload: dict, count: int, resume_text: str = "") -> list[dict]:
    """Return ``count`` varied questions for the requested role/difficulty/round."""
    round_key = str(payload.get("round") or "").strip()
    if round_key == "Coding":
        return _coding_questions(payload, count)
    if round_key == "Resume":
        return _resume_questions(payload, count, resume_text)
    role = str(payload.get("role") or "this").strip() or "this"
    difficulty = str(payload.get("difficulty") or "Intermediate")
    interview_type = f"{payload.get('interviewType') or ''} {payload.get('category') or ''}".lower()
    pools: list[tuple[str, list[str]]] = [("Technical", _TECHNICAL), ("Behavioral", _BEHAVIORAL), ("HR", _HR), ("Situational", _SITUATIONAL)]
    if round_key == "HR":
        pools = [pools[2]]
    elif round_key == "Technical":
        pools = [pools[0]]
    elif round_key == "Behavioral":
        pools = [pools[1], pools[3]]
    elif "hr" in interview_type and "technical" not in interview_type:
        pools = [pools[2], pools[1], pools[3]]
    elif "technical" in interview_type and "hr" not in interview_type:
        pools = [pools[0], pools[3], pools[1]]

    ordered: list[tuple[str, str]] = []
    depth = max(len(pool) for _, pool in pools)
    for index in range(depth):
        for category, pool in pools:
            if index < len(pool):
                ordered.append((category, pool[index]))
    questions = []
    for position in range(count):
        category, template = ordered[position % len(ordered)]
        text = template.format(role=role)
        if difficulty.lower().startswith("adv") and category == "Technical":
            text += " Include trade-offs and edge cases."
        questions.append({"id": str(uuid.uuid4()), "question": text, "category": category, "simulated": True})
    return questions


_CODE_STRUCTURE = re.compile(r"\b(def|function|class|public|static|void|int|fn|func|const|let|var|return)\b")
_CODE_LOOP = re.compile(r"\b(for|while|forEach|map|reduce)\b|=>|recurs")
_CODE_EDGE = re.compile(r"(\bif\b[^\n]*(not|==|!=|<=|>=|<|>|is none|null|len\(|\.length|empty))|(\bempty\b|\bedge\b|\bnull\b|\bnone\b|\binvalid\b)", re.I)
_CODE_COMPLEXITY = re.compile(r"O\(\s*[^)]{1,20}\)", re.I)


def mock_code_evaluation(question: str, answer: str, role: str = "") -> dict:
    """Rubric for coding answers. The code is read, never executed."""
    code = re.sub(r"^\s*(#|//)?\s*language:.*\n", "", answer.strip(), flags=re.I)
    lines = [ln for ln in code.splitlines() if ln.strip()]
    has_structure = bool(_CODE_STRUCTURE.search(code))
    has_return = bool(re.search(r"\breturn\b|=>|print|console\.log|System\.out", code))
    has_loop = bool(_CODE_LOOP.search(code))
    has_edge = bool(_CODE_EDGE.search(code))
    complexity = _CODE_COMPLEXITY.findall(code)
    comments = sum(1 for ln in lines if ln.strip().startswith(("#", "//", "/*", "*")))
    names_ok = bool(re.search(r"\b[a-z]+_[a-z_]+\b|\b[a-z]+[A-Z][a-zA-Z]+\b", code)) or len(lines) >= 4

    approach = (0.4 * has_structure + 0.3 * has_return + 0.3 * min(1.0, len(lines) / 6)) if lines else 0.0
    if has_loop:
        approach = min(1.0, approach + 0.15)
    criteria = [
        {"name": "Approach & completeness", "weight": 35, "earned": round(35 * min(1.0, approach)),
         "note": f"{len(lines)} non-empty lines; function/structure: {'yes' if has_structure else 'no'}; returns a result: {'yes' if has_return else 'no'}; iteration/recursion: {'yes' if has_loop else 'no'}."},
        {"name": "Complexity awareness", "weight": 20, "earned": 20 if complexity else (8 if has_loop else 4),
         "note": ("Stated complexity: " + ", ".join(complexity[:2])) if complexity else "No time/space complexity stated (for example a comment such as # O(n))."},
        {"name": "Edge cases", "weight": 20, "earned": 20 if has_edge else 4,
         "note": "Edge-case handling detected." if has_edge else "No checks for empty, null or boundary inputs were found."},
        {"name": "Code quality", "weight": 25, "earned": round(25 * (0.5 * names_ok + 0.3 * min(1.0, comments / 2) + 0.2 * (1 if len(lines) <= 60 else 0.5))),
         "note": f"{comments} comment line(s); readable structure: {'yes' if names_ok else 'no'}."},
    ]
    score = sum(c["earned"] for c in criteria)
    weaknesses, suggestions, missing, strengths = [], [], [], []
    if not has_structure or not has_return:
        weaknesses.append("The solution is incomplete: wrap the logic in a function and return the result.")
    else:
        strengths.append("Complete function structure with a returned result.")
    if complexity:
        strengths.append("You stated the time/space complexity.")
    else:
        suggestions.append("State the time and space complexity, for example: # Time O(n), Space O(1).")
    if has_edge:
        strengths.append("You handle edge cases.")
    else:
        weaknesses.append("Edge cases are not handled.")
        missing.append("Empty input, single element, duplicates and very large input.")
    if comments == 0:
        suggestions.append("Add one or two comments explaining the approach before the code.")
    metrics = {"technicalAccuracy": round(100 * min(1.0, approach)), "communication": round(100 * min(1.0, comments / 2)),
               "confidence": round(100 * (0.6 * has_return + 0.4 * has_structure)), "relevance": round(100 * min(1.0, approach)),
               "grammar": 0, "pronunciation": 0, "fluency": 0}
    return {
        "simulated": True, "provider": "mock", "score": score,
        "feedback": f"{SIM_PREFIX}code scored {score}/100 by a static rubric. The code was read, not executed, so correctness is not verified.",
        "strengths": strengths, "weaknesses": weaknesses,
        "improvedAnswer": "Explain your approach in a comment, implement it in a function, handle empty and boundary inputs explicitly, and state the time and space complexity.",
        "idealAnswer": "A strong answer picks a suitable data structure, reaches the optimal complexity, handles edge cases, and is clearly named and commented.",
        "isRelevant": bool(lines), "missingPoints": missing, "suggestions": suggestions,
        "metrics": metrics, "scoring": {"method": "rubric", "criteria": criteria, "codeExecuted": False},
    }


def mock_evaluation(question: str, answer: str, role: str = "", round_key: str | None = None) -> dict:
    """Score one answer with a transparent four-criterion rubric (0-100)."""
    if round_key == "Coding":
        return mock_code_evaluation(question, answer, role)
    text = answer.strip()
    lowered = text.lower()
    words = re.findall(r"\b[\w'+#.-]+\b", text)
    word_count = len(words)
    sentences = [s for s in re.split(r"[.!?]+\s", text) if s.strip()]

    q_keys = _keywords(question) | _keywords(role)
    a_keys = _keywords(text)
    overlap = len(q_keys & a_keys) / len(q_keys) if q_keys else 0.5
    relevance = min(1.0, overlap * 2.2)  # hitting ~45% of question keywords earns full marks

    depth = max(0.0, min(1.0, (word_count - 10) / 70))

    markers = sum(any(m in lowered for m in group) for group in (_STRUCTURE_MARKERS, _RESULT_MARKERS, _REASONING_MARKERS))
    structure = markers / 3

    avg_len = word_count / len(sentences) if sentences else 0
    clarity = 0.0
    if len(sentences) >= 2:
        clarity = 1.0 if 8 <= avg_len <= 28 else 0.6
    elif sentences:
        clarity = 0.35

    criteria = [
        {"name": "Relevance to the question", "weight": 35, "earned": round(35 * relevance),
         "note": f"{len(q_keys & a_keys)} of {len(q_keys)} key terms from the question were addressed."},
        {"name": "Depth and detail", "weight": 25, "earned": round(25 * depth),
         "note": f"{word_count} words; roughly 80 words earns full marks."},
        {"name": "Structure (example, result, reasoning)", "weight": 20, "earned": round(20 * structure),
         "note": f"{markers} of 3 structure signals found: a concrete example, a result, and reasoning."},
        {"name": "Clarity", "weight": 20, "earned": round(20 * clarity),
         "note": f"{len(sentences)} sentence(s), about {avg_len:.0f} words each; 2+ sentences of 8-28 words is clearest."},
    ]
    score = sum(item["earned"] for item in criteria)

    strengths, weaknesses, suggestions, missing = [], [], [], []
    if relevance >= 0.6:
        strengths.append("Your answer stays on the topic of the question.")
    else:
        weaknesses.append("The answer does not directly address the main terms in the question.")
        missing.append("Restate the question's key terms and answer them directly.")
    if depth >= 0.6:
        strengths.append("You gave enough detail to be convincing.")
    else:
        weaknesses.append("The answer is brief; add more detail.")
        suggestions.append("Aim for 60-90 words: context, your action, and the outcome.")
    if structure >= 0.66:
        strengths.append("Good structure: example, result and reasoning are present.")
    else:
        weaknesses.append("The answer lacks a concrete example, a measurable result, or explicit reasoning.")
        suggestions.append("Use the STAR pattern: Situation, Task, Action, Result.")
        missing.append("A specific example with a measurable result.")
    if clarity < 0.6:
        suggestions.append("Break the answer into 2-4 clear sentences.")

    def scaled(value: float) -> int:
        return int(max(0, min(100, round(value * 100))))

    metrics = {
        "technicalAccuracy": scaled(0.5 * relevance + 0.5 * depth),
        "communication": scaled(clarity),
        "confidence": scaled(0.5 * depth + 0.5 * structure),
        "relevance": scaled(relevance),
        "grammar": scaled(min(1.0, clarity + 0.2)),
        "pronunciation": 0,  # cannot be measured from text in mock mode
        "fluency": scaled(0.6 * clarity + 0.4 * depth),
    }
    summary = "strong" if score >= 75 else "reasonable" if score >= 50 else "needs more work"
    return {
        "simulated": True,
        "provider": "mock",
        "score": score,
        "feedback": f"{SIM_PREFIX}this answer is {summary} (score {score}/100) based on a fixed rubric, not a real AI review.",
        "strengths": strengths,
        "weaknesses": weaknesses,
        "improvedAnswer": "Open with a one-sentence direct answer, give one concrete example from your experience, then state the measurable result and what you would repeat or change.",
        "idealAnswer": "A strong answer addresses the question directly, backs it with a specific example, explains the reasoning, and ends with the outcome.",
        "isRelevant": relevance >= 0.35,
        "missingPoints": missing,
        "suggestions": suggestions,
        "metrics": metrics,
        "scoring": {"method": "rubric", "criteria": criteria},
    }


def mock_report(response_data: list[dict], average_score: int, role: str = "", round_key: str | None = None) -> dict:
    """Build an overall report from the per-answer evaluations."""
    evaluations = [item.get("evaluation") or {} for item in response_data]
    answered = [e for e in evaluations if e.get("score") and not str(e.get("feedback", "")).startswith(("Question was skipped", "No answer"))]
    skipped = len(evaluations) - len(answered)

    def mean_metric(name: str) -> int:
        values = [e.get("metrics", {}).get(name) for e in answered if isinstance(e.get("metrics", {}).get(name), (int, float))]
        return int(round(sum(values) / len(values))) if values else 0

    # Only report what can actually be measured. Camera and voice qualities cannot be
    # derived from typed text, and spoken-language metrics do not apply to code.
    unmeasured = {"eyeContact", "timeManagement", "listeningSkills", "pronunciation"}
    if round_key == "Coding":
        unmeasured |= {"grammar", "fluency"}
    detailed = {
        "problemSolving": mean_metric("technicalAccuracy"), "logicalThinking": mean_metric("relevance"),
        "professionalism": mean_metric("communication"), "grammar": mean_metric("grammar"),
        "fluency": mean_metric("fluency"), "accuracy": mean_metric("technicalAccuracy"),
        "relevance": mean_metric("relevance"), "technicalKnowledge": mean_metric("technicalAccuracy"),
        "communication": mean_metric("communication"), "confidence": mean_metric("confidence"),
    }
    detailed = {key: value for key, value in detailed.items() if key not in unmeasured}
    result = "Excellent" if average_score >= 80 else "Good" if average_score >= 65 else "Average" if average_score >= 45 else "Needs Improvement"
    weakest = sorted(
        ((name, mean_metric(name)) for name in ("relevance", "communication", "confidence", "technicalAccuracy")),
        key=lambda pair: pair[1],
    )[0][0]
    return {
        "simulated": True,
        "provider": "mock",
        "overallScore": average_score,
        "result": result,
        "summary": f"{SIM_PREFIX}you answered {len(answered)} of {len(evaluations)} questions for the {role or 'selected'} role with an average rubric score of {average_score}/100.",
        "keyTakeaways": [
            f"{len(answered)} question(s) answered, {skipped} skipped or unanswered.",
            f"Your weakest rubric area was {weakest}.",
            "Scores come from a fixed development rubric, not a real AI model.",
        ],
        "careerAdvice": "Practise with the STAR pattern and add one measurable result to every answer. (Simulated advice.)",
        "skillGapAnalysis": {
            "Relevance": mean_metric("relevance"),
            "Communication": mean_metric("communication"),
            "Confidence": mean_metric("confidence"),
            "Technical depth": mean_metric("technicalAccuracy"),
        },
        "nextSteps": [
            "Re-answer your lowest-scoring question using the STAR pattern.",
            "Aim for 60-90 words per answer with one concrete example.",
            "Run another practice interview and compare your average score.",
        ],
        "detailedMetrics": detailed,
        "notMeasured": sorted(unmeasured),
    }
