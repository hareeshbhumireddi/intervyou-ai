import uuid
from datetime import datetime, timezone

from sqlalchemy.orm import synonym

from extensions import db


def utcnow():
    return datetime.now(timezone.utc)


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False, default="")
    email = db.Column(db.String(254), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    profile_data = db.Column(db.JSON, nullable=False, default=dict)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)


class AuthSession(db.Model):
    """Server-side record of a sign-in.

    The browser cookie only carries a random session id; its SHA-256 hash is
    stored here with an expiry and a revocation timestamp. That makes logout
    and expiry enforceable on the server rather than trusting the cookie.
    """

    __tablename__ = "auth_sessions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash = db.Column(db.String(64), unique=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    expires_at = db.Column(db.DateTime(timezone=True), nullable=False)
    revoked_at = db.Column(db.DateTime(timezone=True))


class Resume(db.Model):
    __tablename__ = "resumes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    file_name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(1024), nullable=False)
    mime_type = db.Column(db.String(150), nullable=False)
    size = db.Column(db.Integer, nullable=False)
    uploaded_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    original_name = synonym("file_name")
    storage_path = synonym("file_path")


class Interview(db.Model):
    __tablename__ = "interviews"

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    interview_type = db.Column(db.String(200), nullable=False, default="Mock Interview")
    role = db.Column(db.String(200), nullable=False)
    sector = db.Column(db.String(40), nullable=False)
    difficulty = db.Column(db.String(40), nullable=False)
    exam_name = db.Column(db.String(200))
    department = db.Column(db.String(200))
    preferred_language = db.Column(db.String(80))
    company_name = db.Column(db.String(200))
    category = db.Column(db.String(120))
    experience = db.Column(db.String(80))
    qualification = db.Column(db.String(200))
    job_id = db.Column(db.String(100))
    score = db.Column(db.Float, nullable=False, default=0)
    status = db.Column(db.String(24), nullable=False, default="active")
    report_json = db.Column(db.JSON)
    date = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    completed_at = db.Column(db.DateTime(timezone=True))
    started_at = synonym("date")

    questions = db.relationship("InterviewQuestion", backref="interview", cascade="all, delete-orphan", order_by="InterviewQuestion.position")
    answers = db.relationship("Answer", backref="interview", cascade="all, delete-orphan")


class InterviewQuestion(db.Model):
    __tablename__ = "questions"

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    interview_id = db.Column(db.String(36), db.ForeignKey("interviews.id", ondelete="CASCADE"), nullable=False, index=True)
    position = db.Column(db.Integer, nullable=False)
    question = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=False, default="General")
    repeat_count = db.Column(db.Integer, nullable=False, default=0)
    prompt = synonym("question")


class Answer(db.Model):
    __tablename__ = "answers"

    id = db.Column(db.Integer, primary_key=True)
    interview_id = db.Column(db.String(36), db.ForeignKey("interviews.id", ondelete="CASCADE"), nullable=False, index=True)
    question_id = db.Column(db.String(36), db.ForeignKey("questions.id", ondelete="CASCADE"), nullable=False, index=True)
    answer_text = db.Column(db.Text, nullable=False, default="")
    is_skipped = db.Column(db.Boolean, nullable=False, default=False)
    score = db.Column(db.Float)
    evaluation_json = db.Column(db.JSON)
    submitted_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)


class Performance(db.Model):
    __tablename__ = "performance"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    interview_id = db.Column(db.String(36), db.ForeignKey("interviews.id", ondelete="CASCADE"), unique=True, nullable=False)
    score = db.Column(db.Float, nullable=False, default=0)
    correct_count = db.Column(db.Integer, nullable=False, default=0)
    incorrect_count = db.Column(db.Integer, nullable=False, default=0)
    total_questions = db.Column(db.Integer, nullable=False, default=0)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    created_at = synonym("updated_at")


class InterviewHistory(db.Model):
    __tablename__ = "interview_history"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    interview_id = db.Column(db.String(36), db.ForeignKey("interviews.id", ondelete="CASCADE"), unique=True, nullable=False)
    role = db.Column(db.String(200), nullable=False)
    sector = db.Column(db.String(40), nullable=False)
    difficulty = db.Column(db.String(40), nullable=False)
    score = db.Column(db.Float, nullable=False, default=0)
    completed_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)


class SavedJob(db.Model):
    __tablename__ = "saved_jobs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    job_title = db.Column(db.String(200), nullable=False)
    company = db.Column(db.String(200), nullable=False)
    location = db.Column(db.String(200), nullable=False, default="")
    job_url = db.Column(db.String(2048), nullable=False, default="")
    source_job_id = db.Column(db.String(100))
    saved_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
