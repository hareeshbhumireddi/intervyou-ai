import os
import secrets
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy.engine import URL

BACKEND_DIR = Path(__file__).resolve().parent
load_dotenv(BACKEND_DIR / ".env")

IS_PRODUCTION = os.getenv("FLASK_ENV", "").lower() == "production"


def _load_or_create_dev_secret() -> str:
    """Persist a random development secret so sessions survive backend restarts.

    Without this, Flask signs session cookies with a new random key on every
    start, which silently logs everyone out whenever the backend restarts.
    Production must configure SECRET_KEY explicitly instead (enforced below).
    """
    secret_file = BACKEND_DIR / "instance" / ".dev_secret_key"
    try:
        if secret_file.is_file():
            stored = secret_file.read_text(encoding="utf-8").strip()
            if len(stored) >= 32:
                return stored
        secret_file.parent.mkdir(parents=True, exist_ok=True)
        generated = secrets.token_hex(32)
        secret_file.write_text(generated, encoding="utf-8")
        try:
            secret_file.chmod(0o600)
        except OSError:
            pass  # best effort (e.g. Windows)
        return generated
    except OSError:
        return secrets.token_hex(32)  # read-only filesystem: sessions will not persist


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    return default if value is None or value == "" else value.lower() in {"1", "true", "yes", "on"}


class Config:
    configured_secret = os.getenv("SECRET_KEY")
    if configured_secret and configured_secret.startswith("replace-with"):
        configured_secret = None  # the .env.example placeholder is not a real secret
    if IS_PRODUCTION and not configured_secret:
        raise RuntimeError("SECRET_KEY must be configured before running Flask in production.")

    SECRET_KEY = configured_secret or _load_or_create_dev_secret()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True, "pool_recycle": 280}

    database_url = os.getenv("DATABASE_URL")
    if not database_url and os.getenv("MYSQL_USER"):
        database_url = URL.create(
            drivername="mysql+pymysql",
            username=os.environ["MYSQL_USER"],
            password=os.getenv("MYSQL_PASSWORD", ""),
            host=os.getenv("MYSQL_HOST", "127.0.0.1"),
            port=int(os.getenv("MYSQL_PORT", "3306")),
            database=os.getenv("MYSQL_DATABASE", "ai_interview_db"),
            query={"charset": "utf8mb4"},
        ).render_as_string(hide_password=False)

    if IS_PRODUCTION and not database_url:
        raise RuntimeError("Configure DATABASE_URL or MYSQL_USER before running Flask in production.")
    SQLALCHEMY_DATABASE_URI = database_url or "sqlite:///intervyou.sqlite3"
    if SQLALCHEMY_DATABASE_URI.startswith("sqlite"):
        SQLALCHEMY_ENGINE_OPTIONS = {"connect_args": {"check_same_thread": False}}

    MAX_CONTENT_LENGTH = 10 * 1024 * 1024

    # --- Sessions -----------------------------------------------------------
    SESSION_COOKIE_NAME = "intervyou_session"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = os.getenv("SESSION_COOKIE_SAMESITE", "Lax")
    # Secure cookies by default in production; opt out only via explicit env.
    SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE", IS_PRODUCTION)
    # How long a sign-in lasts (absolute, measured from sign-in). Server-side
    # AuthSession rows enforce the same limit, so a stolen/old cookie expires.
    SESSION_LIFETIME_HOURS = int(os.getenv("SESSION_LIFETIME_HOURS", "168"))
    PERMANENT_SESSION_LIFETIME = timedelta(hours=SESSION_LIFETIME_HOURS)

    FRONTEND_ORIGINS = [
        origin.strip().rstrip("/")
        for origin in os.getenv(
            "FRONTEND_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000",
        ).split(",")
        if origin.strip()
    ]
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "instance/uploads")

    # --- AI provider --------------------------------------------------------
    # "gemini" (default) calls Google Gemini and needs GEMINI_API_KEY.
    # "mock" returns clearly-labelled simulated output for local development
    # and is refused in production.
    AI_PROVIDER = os.getenv("AI_PROVIDER", "gemini").strip().lower()
    if AI_PROVIDER not in {"gemini", "mock"}:
        raise RuntimeError("AI_PROVIDER must be 'gemini' or 'mock'.")
    if IS_PRODUCTION and AI_PROVIDER == "mock":
        raise RuntimeError("AI_PROVIDER=mock is for development only and cannot be used in production.")

    # --- Login throttling (per process) ---------------------------------------
    LOGIN_MAX_ATTEMPTS = int(os.getenv("LOGIN_MAX_ATTEMPTS", "8"))
    LOGIN_WINDOW_SECONDS = int(os.getenv("LOGIN_WINDOW_SECONDS", "900"))
