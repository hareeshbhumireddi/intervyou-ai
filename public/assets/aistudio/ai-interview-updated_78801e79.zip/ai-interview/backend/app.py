import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, g, jsonify, request, send_file
from flask_cors import CORS
from google import genai
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from ai_provider import mock_evaluation, mock_questions, mock_report
from ats import analyze_resume
from auth import (
    authenticated,
    clear_login_failures,
    end_session,
    login_blocked,
    record_login_failure,
    resolve_session,
    start_session,
    unauthorized,
)
from config import Config
from extensions import db
from models import Answer, Interview, InterviewHistory, InterviewQuestion, Performance, Resume, SavedJob, User
from rounds import MAX_ANSWER_CHARS, ROUND_LABELS, evaluation_guidance, normalise_round, question_guidance, round_from_type
from routes import saved_jobs_bp
from validators import (
    DEGREES,
    GENDERS,
    LANGUAGES,
    MIN_GRADUATION_YEAR,
    max_graduation_year,
    validate_profile,
    validate_registration,
)

BACKEND_DIR = Path(__file__).resolve().parent

app = Flask(__name__, instance_relative_config=True)
app.config.from_object(Config)
Path(app.instance_path).mkdir(parents=True, exist_ok=True)
upload_folder = Path(app.config["UPLOAD_FOLDER"])
UPLOAD_ROOT = (upload_folder if upload_folder.is_absolute() else BACKEND_DIR / upload_folder).resolve()
UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)

db.init_app(app)
CORS(
    app,
    resources={r"/api/*": {"origins": Config.FRONTEND_ORIGINS}},
    supports_credentials=True,
    allow_headers=["Content-Type"],
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
)
app.register_blueprint(saved_jobs_bp)

with app.app_context():
    db.create_all()


@app.before_request
def validate_origin():
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        origin = request.headers.get("Origin")
        if origin and origin.rstrip("/") not in Config.FRONTEND_ORIGINS:
            return jsonify(error="Request origin is not allowed."), 403
        if request.headers.get("Sec-Fetch-Site") == "cross-site":
            return jsonify(error="Cross-site requests are not allowed."), 403
    return None


@app.after_request
def add_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"  # never cache user data or auth state
    return response


def ai_mode():
    """'mock' (dev), 'gemini' (configured) or 'unconfigured'."""
    if app.config["AI_PROVIDER"] == "mock":
        return "mock"
    return "gemini" if os.getenv("GEMINI_API_KEY") else "unconfigured"


def public_user(user):
    profile = dict(user.profile_data or {})
    profile.setdefault("fullName", user.name)
    profile.update({"id": user.id, "name": user.name, "email": user.email, "isCompleted": True})
    return profile


def get_payload():
    return request.get_json(silent=True) or {}


def find_owned_interview(interview_id):
    return Interview.query.filter_by(id=interview_id, user_id=g.current_user.id).first()


def generate_json(prompt):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("AI interview services are not configured. Set GEMINI_API_KEY in backend/.env.")

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        contents=prompt,
        config={"response_mime_type": "application/json"},
    )
    if not response.text:
        raise ValueError("The AI service returned an empty response.")
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", response.text.strip(), flags=re.IGNORECASE)
    return json.loads(text)


def generate_questions(payload, resume_text=""):
    count = max(1, min(int(payload.get("numQuestions") or 5), 20))
    prompt = f"""Return a JSON array containing exactly {count} interview question objects.
Each object must have string fields id, question, and category.
Candidate role: {payload.get('role', 'General')}
Sector: {payload.get('sector', 'Private')}
Difficulty: {payload.get('difficulty', 'Intermediate')}
Exam/post: {payload.get('examName', '')}
Department: {payload.get('department', '')}
Language: {payload.get('preferredLanguage', 'English')}
Experience: {payload.get('experience', '')}
Resume content, if available: {resume_text[:12000]}
{question_guidance(payload.get('round'))} Return JSON only."""
    questions = mock_questions(payload, count, resume_text) if ai_mode() == "mock" else generate_json(prompt)
    if not isinstance(questions, list) or not questions:
        raise ValueError("The AI service did not return interview questions.")
    result = []
    for item in questions[:count]:
        result.append({
            "id": str(item.get("id") or uuid.uuid4()),
            "question": str(item.get("question") or "").strip(),
            "category": str(item.get("category") or "General").strip(),
        })
    if any(not question["question"] for question in result):
        raise ValueError("The AI service returned an invalid question.")
    return result


def read_resume_text(user_id):
    resume = Resume.query.filter_by(user_id=user_id).first()
    if not resume:
        return ""
    path = Path(resume.storage_path)
    if not path.exists():
        return ""
    suffix = Path(resume.original_name).suffix.lower()
    try:
        if suffix == ".txt":
            return path.read_text(encoding="utf-8", errors="ignore")[:12000]
        if suffix == ".pdf":
            from pypdf import PdfReader

            reader = PdfReader(str(path))
            return "\n".join(page.extract_text() or "" for page in reader.pages)[:12000]
        if suffix == ".docx":
            from docx import Document

            document = Document(str(path))
            return "\n".join(paragraph.text for paragraph in document.paragraphs)[:12000]
    except Exception:
        app.logger.exception("Could not extract text from stored resume")
    return ""


def serialize_interview(interview):
    questions = [
        {"id": question.id, "question": question.prompt, "category": question.category}
        for question in interview.questions
    ]
    answers = {}
    evaluations = {}
    latest_answers = {}
    for answer in sorted(interview.answers, key=lambda item: item.submitted_at):
        latest_answers[answer.question_id] = answer
    for question_id, answer in latest_answers.items():
        answers[question_id] = "SKIPPED" if answer.is_skipped else answer.answer_text
        if answer.evaluation_json:
            evaluations[question_id] = answer.evaluation_json
    return {
        "id": interview.id,
        "role": interview.role,
        "interviewType": interview.interview_type,
        "round": round_from_type(interview.interview_type),
        "roundLabel": interview.interview_type if round_from_type(interview.interview_type) else None,
        "sector": interview.sector,
        "difficulty": interview.difficulty,
        "date": interview.started_at.isoformat(),
        "questions": questions,
        "answers": answers,
        "evaluations": evaluations,
        "overallReport": interview.report_json,
        "examName": interview.exam_name,
        "department": interview.department,
        "preferredLanguage": interview.preferred_language,
        "duration": None,
        "jobId": interview.job_id,
        "jobTitle": interview.role,
        "companyName": interview.company_name,
        "category": interview.category,
        "experience": interview.experience,
        "qualification": interview.qualification,
        "status": interview.status,
        "isSimulated": bool((interview.report_json or {}).get("simulated"))
        or any(isinstance(item, dict) and item.get("simulated") for item in evaluations.values()),
    }


def latest_answer(interview_id, question_id):
    return Answer.query.filter_by(interview_id=interview_id, question_id=question_id).order_by(Answer.submitted_at.desc()).first()


@app.get("/api/health")
def health():
    try:
        db.session.execute(text("SELECT 1"))
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(status="error", database="unavailable"), 503
    return jsonify(status="ok", database="ok")


DUMMY_PASSWORD_HASH = generate_password_hash("not-a-real-password")  # equalises timing for unknown emails


def validation_error(errors):
    return jsonify(error="Please correct the highlighted fields.", code="validation_failed", fields=errors), 422


@app.get("/api/config")
def public_config():
    """Rules and capabilities the frontend needs; keeps one source of truth."""
    return jsonify(
        aiMode=ai_mode(),
        languages=list(LANGUAGES),
        degrees=list(DEGREES),
        genders=list(GENDERS),
        graduationYear={"min": MIN_GRADUATION_YEAR, "max": max_graduation_year()},
        rounds=[{"key": key, "label": label} for key, label in ROUND_LABELS.items()],
    )


@app.post("/api/auth/register")
@app.post("/api/register")
def register():
    payload = get_payload()
    clean, errors = validate_registration(payload)
    if errors:
        return validation_error(errors)
    email = clean["email"]
    if User.query.filter_by(email=email).first():
        message = "An account with this email already exists. Please sign in."
        return jsonify(error=message, code="account_exists", fields={"email": message}), 409

    profile_data = {key: value for key, value in clean.items() if key != "email"}
    profile_data["isCompleted"] = True
    user = User(
        name=clean["fullName"],
        email=email,
        password_hash=generate_password_hash(payload["password"]),
        profile_data=profile_data,
    )
    try:
        db.session.add(user)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        message = "An account with this email already exists. Please sign in."
        return jsonify(error=message, code="account_exists", fields={"email": message}), 409
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("User registration database error")
        return jsonify(error="Registration could not be completed. Please try again."), 500
    return jsonify(message="Registration successful. Sign in to continue.", user=public_user(user)), 201


@app.post("/api/auth/login")
@app.post("/api/login")
def login():
    payload = get_payload()
    email = str(payload.get("email", "")).strip().lower()
    password = payload.get("password")
    password = password if isinstance(password, str) else ""
    throttle_key = f"{request.remote_addr}|{email}"
    wait = login_blocked(throttle_key)
    if wait:
        return jsonify(error="Too many failed sign-in attempts. Please try again later.", code="too_many_attempts", retryAfter=wait), 429

    user = User.query.filter_by(email=email).first() if email else None
    password_ok = check_password_hash(user.password_hash if user else DUMMY_PASSWORD_HASH, password)
    if user is None or not password_ok:
        record_login_failure(throttle_key)
        # One message for "no such account" and "wrong password" so the endpoint
        # cannot be used to discover which emails are registered.
        return jsonify(error="Invalid email or password.", code="invalid_credentials"), 401
    clear_login_failures(throttle_key)
    try:
        start_session(user)
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Could not create session")
        return jsonify(error="Sign in could not be completed. Please try again."), 500
    return jsonify(message="Signed in successfully.", user=public_user(user))


@app.get("/api/auth/me")
def auth_me():
    user, reason = resolve_session()
    if user is None:
        return unauthorized(reason)
    return jsonify(user=public_user(user))


@app.post("/api/auth/logout")
def logout():
    try:
        end_session()
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Could not revoke session")
    return jsonify(message="Signed out successfully.")


@app.put("/api/auth/profile")
@authenticated
def update_profile():
    payload = get_payload()
    incoming = payload.get("profile") if isinstance(payload.get("profile"), dict) else {}
    incoming = dict(incoming)
    incoming["email"] = payload.get("email", incoming.get("email") or g.current_user.email)
    clean, errors = validate_profile(incoming)
    if errors:
        return validation_error(errors)
    email = clean["email"]
    if User.query.filter(User.email == email, User.id != g.current_user.id).first():
        message = "That email is already in use."
        return jsonify(error=message, code="account_exists", fields={"email": message}), 409
    g.current_user.email = email
    g.current_user.name = clean["fullName"]
    g.current_user.profile_data = {**{k: v for k, v in clean.items() if k != "email"}, "isCompleted": True}
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify(error="That email is already in use.", code="account_exists", fields={"email": "That email is already in use."}), 409
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Profile update database error")
        return jsonify(error="Profile could not be updated."), 500
    return jsonify(user=public_user(g.current_user))


def resume_metadata(resume):
    return {
        "name": resume.original_name,
        "type": resume.mime_type,
        "size": resume.size,
        "uploadedAt": resume.uploaded_at.isoformat(),
    }


@app.get("/api/resumes")
@app.get("/api/resume")
@authenticated
def get_resume():
    resume = Resume.query.filter_by(user_id=g.current_user.id).first()
    if not resume:
        return jsonify(error="No resume uploaded yet."), 404
    return jsonify(resume=resume_metadata(resume))


@app.post("/api/resumes")
@app.post("/api/resume")
@app.put("/api/resume")
@authenticated
def upload_resume():
    uploaded = request.files.get("resume")
    if uploaded is None or not uploaded.filename:
        return jsonify(error="Choose a resume file to upload."), 400
    original_name = secure_filename(uploaded.filename)
    extension = Path(original_name).suffix.lower()
    if extension not in {".pdf", ".doc", ".docx", ".txt"}:
        return jsonify(error="Choose a PDF, DOC, DOCX, or TXT resume."), 400
    content = uploaded.read()
    if not content:
        return jsonify(error="The selected resume file is empty."), 400
    if len(content) > app.config["MAX_CONTENT_LENGTH"]:
        return jsonify(error="Resume files must be 10 MB or smaller."), 413

    user_folder = UPLOAD_ROOT / str(g.current_user.id)
    user_folder.mkdir(parents=True, exist_ok=True)
    stored_path = user_folder / f"{uuid.uuid4().hex}{extension}"
    old_resume = Resume.query.filter_by(user_id=g.current_user.id).first()
    old_path = Path(old_resume.storage_path) if old_resume else None
    try:
        stored_path.write_bytes(content)
        resume = old_resume or Resume(user_id=g.current_user.id, original_name=original_name, mime_type="", size=0, storage_path="")
        resume.original_name = original_name
        resume.mime_type = uploaded.mimetype or "application/octet-stream"
        resume.size = len(content)
        resume.storage_path = str(stored_path)
        resume.uploaded_at = datetime.now(timezone.utc)
        db.session.add(resume)
        db.session.commit()
    except (OSError, SQLAlchemyError):
        db.session.rollback()
        stored_path.unlink(missing_ok=True)
        app.logger.exception("Resume upload failed")
        return jsonify(error="Resume could not be uploaded. Please try again."), 500

    if old_path and old_path != stored_path:
        old_path.unlink(missing_ok=True)
    return jsonify(message="Resume uploaded successfully.", resume=resume_metadata(resume)), 201


@app.get("/api/resumes/file")
@app.get("/api/resume/file")
@authenticated
def download_resume():
    resume = Resume.query.filter_by(user_id=g.current_user.id).first()
    if not resume:
        return jsonify(error="No resume uploaded yet."), 404
    path = Path(resume.storage_path)
    if not path.is_file():
        return jsonify(error="The stored resume file is missing."), 404
    return send_file(path, mimetype=resume.mime_type, as_attachment=False, download_name=resume.original_name)


@app.delete("/api/resumes")
@app.delete("/api/resume")
@authenticated
def delete_resume():
    resume = Resume.query.filter_by(user_id=g.current_user.id).first()
    if not resume:
        return jsonify(error="No resume uploaded yet."), 404
    path = Path(resume.storage_path)
    try:
        db.session.delete(resume)
        db.session.commit()
        path.unlink(missing_ok=True)
    except (OSError, SQLAlchemyError):
        db.session.rollback()
        app.logger.exception("Resume deletion failed")
        return jsonify(error="Resume could not be deleted."), 500
    return jsonify(message="Resume deleted successfully.")


@app.post("/api/resumes/ats")
@authenticated
def resume_ats_score():
    """ATS-style score for the stored resume (or pasted text), optionally against a job description."""
    payload = get_payload()
    job_description = str(payload.get("jobDescription") or "")[:10000]
    role = str(payload.get("role") or "")[:200]
    pasted = payload.get("text")
    if pasted is not None:
        text = str(pasted)[:30000]
    else:
        if not Resume.query.filter_by(user_id=g.current_user.id).first():
            return jsonify(error="Upload your resume first to get an ATS score.", code="resume_required"), 404
        text = read_resume_text(g.current_user.id)
    try:
        result = analyze_resume(text, job_description=job_description, role=role)
    except ValueError:
        return jsonify(
            error="We could not read any text from your resume. Scanned or image-only PDFs cannot be analysed; upload a text-based PDF, DOCX or TXT.",
            code="resume_unreadable",
        ), 422
    return jsonify(ats=result)


@app.post("/api/interviews")
@app.post("/api/interview/start")
@authenticated
def start_interview():
    payload = get_payload()
    role = str(payload.get("role", "")).strip()
    sector = str(payload.get("sector", "")).strip()
    difficulty = str(payload.get("difficulty", "Intermediate")).strip()
    if not role or sector not in {"Government", "Private"}:
        return jsonify(error="Select a valid role and sector before starting."), 400
    try:
        round_key = normalise_round(payload.get("round"))
    except ValueError as error:
        return jsonify(error=str(error), code="invalid_round"), 400
    resume_text = read_resume_text(g.current_user.id)
    if round_key == "Resume" and len(resume_text.strip()) < 50:
        return jsonify(error="Upload a readable resume before choosing the Resume-based round.", code="resume_required"), 400
    payload["round"] = round_key

    try:
        questions = generate_questions(payload, resume_text)
    except (RuntimeError, ValueError, json.JSONDecodeError) as error:
        return jsonify(error=str(error)), 503
    except Exception:
        app.logger.exception("Question generation failed")
        return jsonify(error="Interview questions could not be generated. Please try again."), 502

    interview = Interview(
        user_id=g.current_user.id,
        interview_type=ROUND_LABELS[round_key] if round_key else str(payload.get("interviewType") or role)[:200],
        role=role,
        sector=sector,
        difficulty=difficulty,
        exam_name=payload.get("examName"),
        department=payload.get("department"),
        preferred_language=payload.get("preferredLanguage"),
        company_name=payload.get("companyName"),
        category=payload.get("category"),
        experience=payload.get("experience"),
        qualification=payload.get("qualification"),
        job_id=payload.get("jobId"),
    )
    for position, question in enumerate(questions):
        interview.questions.append(InterviewQuestion(position=position, prompt=question["question"], category=question["category"]))
    try:
        db.session.add(interview)
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Interview creation database error")
        return jsonify(error="Interview could not be saved."), 500

    serialized = serialize_interview(interview)
    return jsonify(interview=serialized), 201


@app.get("/api/interviews")
@app.get("/api/interviews/history")
@authenticated
def list_interviews():
    interviews = Interview.query.filter_by(user_id=g.current_user.id).order_by(Interview.started_at.desc()).all()
    return jsonify(interviews=[serialize_interview(interview) for interview in interviews])


@app.get("/api/interviews/<interview_id>")
@authenticated
def get_interview(interview_id):
    interview = find_owned_interview(interview_id)
    if not interview:
        return jsonify(error="Interview was not found."), 404
    return jsonify(interview=serialize_interview(interview))


@app.get("/api/interview/questions")
@authenticated
def get_interview_questions():
    interview_id = str(request.args.get("interview_id", "")).strip()
    if not interview_id:
        return jsonify(error="interview_id is required."), 400
    interview = find_owned_interview(interview_id)
    if not interview:
        return jsonify(error="Interview was not found."), 404
    return jsonify(questions=[
        {"id": question.id, "question": question.question, "category": question.category}
        for question in interview.questions
    ])


@app.post("/api/interviews/<interview_id>/questions/<question_id>/repeat")
@app.post("/api/interview/<interview_id>/questions/<question_id>/repeat")
@authenticated
def repeat_question(interview_id, question_id):
    interview = find_owned_interview(interview_id)
    if not interview:
        return jsonify(error="Interview was not found."), 404
    question = InterviewQuestion.query.filter_by(id=question_id, interview_id=interview.id).first()
    if not question:
        return jsonify(error="Question was not found."), 404
    question.repeat_count += 1
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(error="Question repeat could not be recorded."), 500
    return jsonify(question={"id": question.id, "question": question.prompt, "category": question.category, "repeatCount": question.repeat_count})


@app.post("/api/interviews/<interview_id>/skip")
@app.post("/api/interview/<interview_id>/skip")
@authenticated
def skip_question(interview_id):
    interview = find_owned_interview(interview_id)
    if not interview:
        return jsonify(error="Interview was not found."), 404
    question_id = str(get_payload().get("questionId", ""))
    question = InterviewQuestion.query.filter_by(id=question_id, interview_id=interview.id).first()
    if not question:
        return jsonify(error="Question was not found."), 404
    evaluation = {
        "score": 0,
        "feedback": "Question was skipped by the candidate.",
        "strengths": [],
        "weaknesses": ["Candidate chose to skip this question."],
        "improvedAnswer": "N/A",
        "metrics": {"technicalAccuracy": 0, "communication": 0, "confidence": 0, "relevance": 0},
    }
    answer = Answer(interview_id=interview.id, question_id=question.id, answer_text="", is_skipped=True, score=0, evaluation_json=evaluation)
    db.session.add(answer)
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(error="Skipped question could not be saved."), 500
    return jsonify(answer={"questionId": question.id, "answer": "SKIPPED", "evaluation": evaluation})


@app.post("/api/interviews/<interview_id>/answers")
@app.post("/api/interview/<interview_id>/answer")
@authenticated
def submit_answer(interview_id):
    interview = find_owned_interview(interview_id)
    if not interview:
        return jsonify(error="Interview was not found."), 404
    payload = get_payload()
    question_id = str(payload.get("questionId", ""))
    answer_text = str(payload.get("answer", "")).strip()
    question = InterviewQuestion.query.filter_by(id=question_id, interview_id=interview.id).first()
    if not question:
        return jsonify(error="Question was not found."), 404
    if not answer_text:
        return jsonify(error="Enter an answer before submitting."), 400
    if len(answer_text) > MAX_ANSWER_CHARS:
        return jsonify(error=f"Answers are limited to {MAX_ANSWER_CHARS:,} characters."), 400
    round_key = round_from_type(interview.interview_type)

    prompt = f"""Evaluate this interview response and return JSON with score (0-100), feedback, strengths (array), weaknesses (array), improvedAnswer, idealAnswer, isRelevant (boolean), missingPoints (array), suggestions (array), and metrics (object containing technicalAccuracy, communication, confidence, relevance, grammar, pronunciation, fluency as 0-100 numbers).
Role: {interview.role}; sector: {interview.sector}; exam: {interview.exam_name or ''}; department: {interview.department or ''}
Round: {ROUND_LABELS.get(round_key, 'Mixed Round')}. {evaluation_guidance(round_key)}
Question: {question.prompt}
Answer: {answer_text}
Return JSON only."""
    try:
        evaluation = mock_evaluation(question.prompt, answer_text, interview.role, round_key) if ai_mode() == "mock" else generate_json(prompt)
        score = float(evaluation.get("score", 0))
        if not 0 <= score <= 100:
            raise ValueError("The AI evaluation score is invalid.")
    except (RuntimeError, ValueError, json.JSONDecodeError) as error:
        return jsonify(error=str(error)), 503
    except Exception:
        app.logger.exception("Answer evaluation failed")
        return jsonify(error="Answer evaluation failed. Please retry."), 502

    answer = Answer(interview_id=interview.id, question_id=question.id, answer_text=answer_text, score=score, evaluation_json=evaluation)
    db.session.add(answer)
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(error="Answer could not be saved."), 500
    return jsonify(answer={"questionId": question.id, "answer": answer_text, "evaluation": evaluation})


@app.post("/api/interviews/<interview_id>/complete")
@app.post("/api/interview/<interview_id>/submit")
@authenticated
def complete_interview(interview_id):
    interview = find_owned_interview(interview_id)
    if not interview:
        return jsonify(error="Interview was not found."), 404
    if not interview.questions:
        return jsonify(error="This interview has no questions."), 400

    response_data = []
    scores = []
    correct_count = 0
    incorrect_count = 0
    for question in interview.questions:
        answer = latest_answer(interview.id, question.id)
        if not answer:
            answer = Answer(interview_id=interview.id, question_id=question.id, answer_text="", is_skipped=True, score=0, evaluation_json={"score": 0, "feedback": "No answer submitted.", "strengths": [], "weaknesses": ["No response was submitted."], "improvedAnswer": "N/A", "metrics": {"technicalAccuracy": 0, "communication": 0, "confidence": 0, "relevance": 0}})
            db.session.add(answer)
        if not answer.is_skipped and answer.score is not None:
            scores.append(answer.score)
            if answer.score >= 60:
                correct_count += 1
            else:
                incorrect_count += 1
        response_data.append({"question": question.prompt, "answer": "SKIPPED" if answer.is_skipped else answer.answer_text, "evaluation": answer.evaluation_json})

    if interview.report_json:
        return jsonify(interview=serialize_interview(interview))
    average_score = round(sum(scores) / len(scores)) if scores else 0
    try:
        if ai_mode() == "mock":
            report = mock_report(response_data, average_score, interview.role, round_from_type(interview.interview_type))
        else:
            report = generate_json(f"""Create a candidate performance report as JSON with overallScore (0-100), result (Excellent, Good, Average, or Needs Improvement), summary, keyTakeaways (array), careerAdvice, skillGapAnalysis (object of skill to 0-100 number), nextSteps (array), and detailedMetrics (object with eyeContact, timeManagement, problemSolving, logicalThinking, professionalism, listeningSkills, grammar, pronunciation, fluency, accuracy, relevance, technicalKnowledge, communication, confidence, all 0-100).
Candidate role: {interview.role}. Sector: {interview.sector}. Average answer score: {average_score}.
Interview question/answer/evaluation data: {json.dumps(response_data)}
Return JSON only.""")
        report["overallScore"] = max(0, min(100, float(report.get("overallScore", average_score))))
    except (RuntimeError, ValueError, json.JSONDecodeError) as error:
        return jsonify(error=str(error)), 503
    except Exception:
        app.logger.exception("Performance report generation failed")
        return jsonify(error="Performance report generation failed. Please retry."), 502

    interview.report_json = report
    interview.score = average_score
    interview.status = "completed"
    interview.completed_at = datetime.now(timezone.utc)
    performance = Performance.query.filter_by(interview_id=interview.id).first()
    if not performance:
        performance = Performance(user_id=g.current_user.id, interview_id=interview.id)
        db.session.add(performance)
    performance.score = average_score
    performance.correct_count = correct_count
    performance.incorrect_count = incorrect_count
    performance.total_questions = len(interview.questions)
    if not InterviewHistory.query.filter_by(interview_id=interview.id).first():
        db.session.add(InterviewHistory(user_id=g.current_user.id, interview_id=interview.id, role=interview.role, sector=interview.sector, difficulty=interview.difficulty, score=average_score, completed_at=interview.completed_at))
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Interview result could not be saved")
        return jsonify(error="Interview results could not be saved."), 500
    return jsonify(interview=serialize_interview(interview))


@app.get("/api/performance")
@authenticated
def get_performance():
    records = Performance.query.filter_by(user_id=g.current_user.id).order_by(Performance.created_at.asc()).all()
    total = len(records)
    return jsonify(performance={
        "totalInterviews": total,
        "averageScore": round(sum(record.score for record in records) / total) if total else 0,
        "bestScore": max((record.score for record in records), default=0),
        "correctAnswers": sum(record.correct_count for record in records),
        "incorrectAnswers": sum(record.incorrect_count for record in records),
        "history": [{"interviewId": record.interview_id, "score": record.score, "correct": record.correct_count, "incorrect": record.incorrect_count, "totalQuestions": record.total_questions, "date": record.created_at.isoformat()} for record in records],
    })


@app.errorhandler(413)
def request_too_large(_error):
    return jsonify(error="The uploaded file is too large. Maximum size is 10 MB."), 413


@app.errorhandler(SQLAlchemyError)
def database_error(error):
    db.session.rollback()
    app.logger.exception("Unhandled database error: %s", error)
    return jsonify(error="A database error occurred. Please try again."), 500


if __name__ == "__main__":
    app.run(host=os.getenv("FLASK_HOST", "127.0.0.1"), port=int(os.getenv("FLASK_PORT", "5000")), debug=(os.getenv("FLASK_DEBUG", "false").lower() == "true") and not os.getenv("FLASK_ENV", "").lower() == "production")
