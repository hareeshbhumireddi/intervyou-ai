"""Server-side validation for registration and profile data.

The frontend mirrors these rules in ``src/utils/validation.ts`` for instant
feedback, but the backend never trusts the client: every rule here is
enforced again on registration and on profile update.

Policy summary
--------------
* Full name       : 2-100 chars, Unicode letters/marks, spaces, ' ’ - .  (no digits)
* Date of birth   : real ISO date, 4-digit year, age 13-100, not in the future
* Gender          : optional; one of GENDERS
* Email           : parsed by ``email-validator`` (no DNS lookup), max 254 chars
* Mobile          : exactly 10 digits, Indian mobile policy (first digit 6-9)
* Language        : one of LANGUAGES (the languages the interview engine supports)
* Degree          : one of DEGREES
* Graduation year : exactly 4 digits within [MIN_GRADUATION_YEAR, current year + 8]
* CGPA/percentage : optional number 0-100 with at most 2 decimals
* Password        : 8-128 chars, not whitespace-only
"""

from __future__ import annotations

import re
import unicodedata
from datetime import date

from email_validator import EmailNotValidError, validate_email

LANGUAGES = ("English", "Telugu", "Hindi")
GENDERS = ("Male", "Female", "Other")
DEGREES = ("B.Tech", "B.Sc", "MBA", "Other")

MIN_GRADUATION_YEAR = 1970
FUTURE_GRADUATION_YEARS = 8  # students may register before they graduate

NAME_MIN, NAME_MAX = 2, 100
PASSWORD_MIN, PASSWORD_MAX = 8, 128
EMAIL_MAX = 254
ADDRESS_MAX = 500
FREE_TEXT_MAX = 150
MIN_AGE, MAX_AGE = 13, 100

MOBILE_RE = re.compile(r"^[6-9][0-9]{9}$")  # ASCII digits only
YEAR_RE = re.compile(r"^[0-9]{4}$")
CGPA_RE = re.compile(r"^[0-9]{1,3}(\.[0-9]{1,2})?$")
ISO_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")

_NAME_PUNCTUATION = {" ", "'", "\u2019", "-", "."}
_FREE_TEXT_PUNCTUATION = set(" .,&()'\u2019-/+#:")


def max_graduation_year(today: date | None = None) -> int:
    return (today or date.today()).year + FUTURE_GRADUATION_YEARS


def _collapse(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def _as_text(value) -> str:
    """Coerce to str without letting non-strings (lists, dicts, None) slip through."""
    return value if isinstance(value, str) else ("" if value is None else str(value))


# --------------------------------------------------------------------------- #
# Individual field validators. Each returns (clean_value, error_message|None). #
# --------------------------------------------------------------------------- #

def validate_name(value) -> tuple[str, str | None]:
    name = _collapse(_as_text(value))
    if not name:
        return "", "Enter your full name."
    if len(name) < NAME_MIN:
        return name, f"Name must be at least {NAME_MIN} characters."
    if len(name) > NAME_MAX:
        return name, f"Name must be {NAME_MAX} characters or fewer."
    letters = 0
    for char in name:
        category = unicodedata.category(char)
        if category.startswith("L"):
            letters += 1
        elif category.startswith("M") or char in _NAME_PUNCTUATION:
            continue
        else:
            return name, "Name can only contain letters, spaces, apostrophes, hyphens and periods."
    if letters < NAME_MIN:
        return name, "Name must contain at least two letters."
    return name, None


def validate_email_address(value) -> tuple[str, str | None]:
    raw = _as_text(value).strip()
    if not raw:
        return "", "Enter your email address."
    if len(raw) > EMAIL_MAX:
        return raw, "Email address is too long."
    try:
        result = validate_email(raw, check_deliverability=False, allow_smtputf8=True)
    except EmailNotValidError:
        return raw, "Enter a valid email address, for example name@example.com."
    # Domains are case-insensitive and users type addresses inconsistently, so
    # store one canonical lowercase form to make the unique constraint reliable.
    return result.normalized.lower(), None


def validate_mobile(value) -> tuple[str, str | None]:
    mobile = _as_text(value).strip()
    if not mobile:
        return "", "Enter your 10-digit mobile number."
    if not mobile.isascii() or not mobile.isdigit():
        return mobile, "Mobile number must contain digits only (no spaces, +91 or symbols)."
    if len(mobile) != 10:
        return mobile, "Mobile number must be exactly 10 digits."
    if not MOBILE_RE.match(mobile):
        return mobile, "Enter a valid Indian mobile number starting with 6, 7, 8 or 9."
    return mobile, None


def validate_language(value) -> tuple[str, str | None]:
    language = _as_text(value).strip()
    if not language:
        return "", "Select your preferred language."
    if language not in LANGUAGES:
        return language, f"Select one of the supported languages: {', '.join(LANGUAGES)}."
    return language, None


def validate_dob(value, today: date | None = None) -> tuple[str, str | None]:
    raw = _as_text(value).strip()
    today = today or date.today()
    if not raw:
        return "", "Enter your date of birth."
    if not ISO_DATE_RE.match(raw):
        return raw, "Enter a valid date using a 4-digit year."
    try:
        born = date.fromisoformat(raw)
    except ValueError:
        return raw, "Enter a valid date of birth."
    if born > today:
        return raw, "Date of birth cannot be in the future."
    age = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
    if age < MIN_AGE:
        return raw, f"You must be at least {MIN_AGE} years old to register."
    if age > MAX_AGE:
        return raw, "Enter a valid date of birth."
    return raw, None


def validate_gender(value) -> tuple[str, str | None]:
    gender = _as_text(value).strip()
    if gender and gender not in GENDERS:
        return gender, "Select a valid option."
    return gender, None


def validate_degree(value) -> tuple[str, str | None]:
    degree = _as_text(value).strip()
    if not degree:
        return "", "Select your degree."
    if degree not in DEGREES:
        return degree, "Select a valid degree."
    return degree, None


def validate_graduation_year(value, today: date | None = None) -> tuple[str, str | None]:
    year = _as_text(value).strip()
    upper = max_graduation_year(today)
    if not year:
        return "", "Enter your graduation (passing) year."
    if not year.isascii() or not YEAR_RE.match(year):
        return year, "Enter a 4-digit year, for example 2025."
    if not MIN_GRADUATION_YEAR <= int(year) <= upper:
        return year, f"Year must be between {MIN_GRADUATION_YEAR} and {upper}."
    return year, None


def validate_cgpa(value) -> tuple[str, str | None]:
    cgpa = _as_text(value).strip()
    if not cgpa:
        return "", None  # optional
    if not CGPA_RE.match(cgpa) or float(cgpa) > 100:
        return cgpa, "Enter a number between 0 and 100, for example 8.5."
    return cgpa, None


def validate_free_text(value, *, label: str, required: bool = False, max_len: int = FREE_TEXT_MAX) -> tuple[str, str | None]:
    text = _collapse(_as_text(value))
    if not text:
        return "", (f"Enter your {label}." if required else None)
    if len(text) > max_len:
        return text, f"{label[0].upper() + label[1:]} must be {max_len} characters or fewer."
    if not any(unicodedata.category(c).startswith("L") for c in text):
        return text, f"Enter a valid {label}."
    for char in text:
        category = unicodedata.category(char)
        if not (category[0] in "LMN" or char in _FREE_TEXT_PUNCTUATION):
            return text, f"{label[0].upper() + label[1:]} contains characters that are not allowed."
    return text, None


def validate_address(value) -> tuple[str, str | None]:
    address = _as_text(value).strip()
    if len(address) > ADDRESS_MAX:
        return address, f"Address must be {ADDRESS_MAX} characters or fewer."
    if any(unicodedata.category(c) == "Cc" and c not in "\n\r\t" for c in address):
        return address, "Address contains invalid characters."
    return address, None


def validate_password(value, *, email: str = "") -> str | None:
    password = value if isinstance(value, str) else ""
    if len(password) < PASSWORD_MIN:
        return f"Password must be at least {PASSWORD_MIN} characters."
    if len(password) > PASSWORD_MAX:
        return f"Password must be {PASSWORD_MAX} characters or fewer."
    if not password.strip():
        return "Password cannot be only spaces."
    if email and password.lower() == email.lower():
        return "Password must not be the same as your email address."
    return None


def _clean_string_list(value, *, max_items: int = 30, max_len: int = 80) -> list[str]:
    if not isinstance(value, list):
        return []
    cleaned = []
    for item in value[:max_items]:
        text = _collapse(_as_text(item))
        if text and len(text) <= max_len:
            cleaned.append(text)
    return cleaned


def _clean_certificates(value, *, max_items: int = 30) -> list[dict]:
    if not isinstance(value, list):
        return []
    cleaned = []
    for item in value[:max_items]:
        if not isinstance(item, dict):
            continue
        entry = {key: _collapse(_as_text(item.get(key)))[:FREE_TEXT_MAX] for key in ("title", "provider", "date")}
        if entry["title"]:
            cleaned.append(entry)
    return cleaned


AVATAR_RE = re.compile(r"^data:image/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$")
AVATAR_MAX = 400_000
RESUME_TEXT_MAX = 20_000


def _clean_avatar(value) -> str:
    avatar = _as_text(value).strip()
    return avatar if len(avatar) <= AVATAR_MAX and AVATAR_RE.match(avatar) else ""


# --------------------------------------------------------------------------- #
# Whole-payload validation                                                     #
# --------------------------------------------------------------------------- #

def validate_profile(profile, *, today: date | None = None) -> tuple[dict, dict[str, str]]:
    """Validate a registration/profile payload.

    Returns ``(clean_profile, errors)``. ``errors`` maps field paths (using the
    frontend's names, e.g. ``education.graduationYear``) to messages. Only
    whitelisted keys are copied into ``clean_profile`` so arbitrary client JSON
    is never persisted.
    """
    profile = profile if isinstance(profile, dict) else {}
    education_in = profile.get("education") if isinstance(profile.get("education"), dict) else {}
    errors: dict[str, str] = {}

    def run(key: str, result: tuple[str, str | None]) -> str:
        value, error = result
        if error:
            errors[key] = error
        return value

    clean = {
        "fullName": run("fullName", validate_name(profile.get("fullName"))),
        "dob": run("dob", validate_dob(profile.get("dob"), today)),
        "gender": run("gender", validate_gender(profile.get("gender"))),
        "email": run("email", validate_email_address(profile.get("email"))),
        "mobile": run("mobile", validate_mobile(profile.get("mobile"))),
        "address": run("address", validate_address(profile.get("address"))),
        "preferredLanguage": run("preferredLanguage", validate_language(profile.get("preferredLanguage"))),
        "qualification": run("qualification", validate_free_text(profile.get("qualification"), label="highest qualification")),
        "education": {
            "degree": run("education.degree", validate_degree(education_in.get("degree"))),
            "college": run("education.college", validate_free_text(education_in.get("college"), label="college name", required=True)),
            "specialization": run("education.specialization", validate_free_text(education_in.get("specialization"), label="specialization")),
            "graduationYear": run("education.graduationYear", validate_graduation_year(education_in.get("graduationYear"), today)),
            "cgpa": run("education.cgpa", validate_cgpa(education_in.get("cgpa"))),
        },
        "skills": _clean_string_list(profile.get("skills")),
        "certificates": _clean_certificates(profile.get("certificates")),
        "avatarUrl": _clean_avatar(profile.get("avatarUrl")),
        "resumeText": _as_text(profile.get("resumeText")).strip()[:RESUME_TEXT_MAX],
    }
    return clean, errors


def validate_registration(payload, *, today: date | None = None) -> tuple[dict, dict[str, str]]:
    """Validate a full ``POST /api/auth/register`` body."""
    payload = payload if isinstance(payload, dict) else {}
    profile = dict(payload.get("profile") or {}) if isinstance(payload.get("profile"), dict) else {}
    # The API contract carries the email at the top level; accept it in the
    # profile too, but the top-level value wins.
    profile["email"] = payload.get("email", profile.get("email"))
    clean, errors = validate_profile(profile, today=today)
    password_error = validate_password(payload.get("password"), email=clean["email"])
    if password_error:
        errors["password"] = password_error
    return clean, errors
