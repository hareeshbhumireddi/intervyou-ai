import { BrowserRouter, Routes, Route, Link, useLocation, Navigate, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import {
  Activity,
  Bell,
  Bookmark,
  Briefcase,
  Dumbbell,
  FileText,
  History as HistoryIcon,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings as SettingsIcon,
  User as UserIcon,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { ThemeProvider } from './components/ThemeProvider';
import { AppStateProvider, useAppState } from './hooks/useAppState';
import { api } from './utils/api';

import Dashboard from './pages/Dashboard';
import InterviewSetup from './pages/interviewSetup';
import InterviewRoom from './pages/interview';
import HistoryPage from './pages/History';
import JobNotifications from './pages/JobNotifications';
import MyInterviews from './pages/MyInterviews';
import MyResume from './pages/MyResume';
import PerformanceOverview from './pages/PerformanceOverview';
import PerformanceReport from './pages/Performance';
import PracticePage from './pages/Practice';
import Profile from './pages/Profile';
import SavedJobs from './pages/SavedJobs';
import SettingsPage from './pages/Settings';
import Login from './pages/Login';
import Landing from './pages/Landing';
import { safeRedirect } from './utils/validation';
import Onboarding from './pages/Onboarding';
import ErrorBoundary from './components/ErrorBoundary';
import { Alert, FullPageStatus, LinkButton, SimulatedBanner } from './components/ui';

const sidebarLinks = [
  { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
  { label: 'My Interview', path: '/my-interview', icon: Briefcase },
  { label: 'My Resume', path: '/my-resume', icon: FileText },
  { label: 'Performance', path: '/performance', icon: Activity },
  { label: 'History', path: '/history', icon: HistoryIcon },
  { label: 'Practice', path: '/practice', icon: Dumbbell },
  { label: 'Job Alerts', path: '/jobs', icon: Bell },
  { label: 'Saved Jobs', path: '/saved-jobs', icon: Bookmark },
  { label: 'Profile', path: '/profile', icon: UserIcon },
  { label: 'Settings', path: '/settings', icon: SettingsIcon },
];

function SidebarLinks({ onNavigate }: { onNavigate: () => void }) {
  const location = useLocation();

  return (
    <nav className="space-y-1.5" aria-label="Main navigation">
      {sidebarLinks.map(({ label, path, icon: Icon }) => {
        const selected = location.pathname === path
          || (path === '/performance' && (location.pathname.startsWith('/performance/') || location.pathname.startsWith('/report/')))
          || (path === '/practice' && ['/setup', '/room'].includes(location.pathname))
          || (path === '/my-interview' && location.pathname.startsWith('/interview/'));

        return (
          <Link
            key={path}
            to={path}
            onClick={onNavigate}
            aria-current={selected ? 'page' : undefined}
            className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors ${selected
              ? 'bg-blue-50 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300'
              : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'}`}
          >
            <Icon className="h-5 w-5 shrink-0" />
            <span>{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

function SidebarFooter({ onLogout }: { onLogout: () => void }) {
  const { user } = useAppState();

  return (
    <div className="border-t border-slate-200 pt-4 dark:border-slate-800">
      <Link to="/profile" className="mb-3 block truncate rounded-lg px-3 py-1 hover:bg-slate-100 dark:hover:bg-slate-800">
        <span className="block truncate text-sm font-bold text-slate-900 dark:text-white">{user.fullName || 'Candidate'}</span>
        <span className="block truncate text-xs text-slate-500">{user.email}</span>
      </Link>
      <button
        onClick={onLogout}
        className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 transition-colors hover:bg-red-50 hover:text-red-600 dark:text-slate-300 dark:hover:bg-red-500/10 dark:hover:text-red-300"
      >
        <LogOut className="h-5 w-5" />
        Sign out
      </button>
    </div>
  );
}

function AuthenticatedLayout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { setAuthenticated, aiMode } = useAppState();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await api.logout();
    } finally {
      setAuthenticated(false);
      // Replace (not push) so the signed-in page does not stay in the history
      // for the Back button to return to.
      navigate('/login', { replace: true });
    }
  };

  const brand = (
    <Link to="/dashboard" className="flex items-center gap-3 px-2 py-2">
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 text-lg font-black text-white shadow-md shadow-blue-500/20">I</span>
      <span className="text-lg font-extrabold text-slate-900 dark:text-white">Intervyou</span>
    </Link>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-50">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-slate-200 bg-white px-4 py-5 dark:border-slate-800 dark:bg-slate-900 md:flex">
        {brand}
        <div className="my-5 h-px bg-slate-200 dark:bg-slate-800" />
        <div className="flex-1 overflow-y-auto">
          <SidebarLinks onNavigate={() => undefined} />
        </div>
        <SidebarFooter onLogout={handleLogout} />
      </aside>

      <header className="fixed inset-x-0 top-0 z-30 flex h-16 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur dark:border-slate-800 dark:bg-slate-900/95 md:hidden">
        {brand}
        <button
          onClick={() => setMobileOpen(true)}
          aria-label="Open navigation menu"
          aria-expanded={mobileOpen}
          className="rounded-lg p-2 text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <Menu className="h-6 w-6" />
        </button>
      </header>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div className="fixed inset-0 z-50 md:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <button aria-label="Close navigation menu" onClick={() => setMobileOpen(false)} className="absolute inset-0 bg-slate-950/50" />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.2 }}
              className="absolute inset-y-0 left-0 flex w-[min(19rem,85vw)] flex-col border-r border-slate-200 bg-white px-4 py-5 dark:border-slate-800 dark:bg-slate-900"
            >
              <div className="flex items-center justify-between">
                {brand}
                <button onClick={() => setMobileOpen(false)} aria-label="Close navigation menu" className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="my-5 h-px bg-slate-200 dark:bg-slate-800" />
              <div className="flex-1 overflow-y-auto">
                <SidebarLinks onNavigate={() => setMobileOpen(false)} />
              </div>
              <SidebarFooter onLogout={handleLogout} />
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="min-h-screen px-4 pb-8 pt-20 sm:px-6 md:ml-64 md:px-8 md:pt-8">
        <div className="mx-auto max-w-7xl">
          {aiMode === 'mock' && <SimulatedBanner className="mb-6" />}
          {aiMode === 'unconfigured' && (
            <div className="mb-6"><Alert tone="info">AI interview generation is not configured on this server (no Gemini API key). You can still browse your account, history and reports.</Alert></div>
          )}
          {children}
        </div>
      </main>
    </div>
  );
}

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, authReady } = useAppState();
  const location = useLocation();

  // Wait for the server to answer before deciding anything; otherwise a refresh
  // would briefly look "signed out" and bounce a valid user.
  if (!authReady) return <FullPageStatus>Checking your session…</FullPageStatus>;
  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: `${location.pathname}${location.search}` }} />;
  }
  return <>{children}</>;
}

/** Login/registration are for signed-out visitors; signed-in users go to the dashboard. */
function PublicOnlyRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, authReady } = useAppState();
  const location = useLocation();
  if (!authReady) return <FullPageStatus>Checking your session…</FullPageStatus>;
  if (isAuthenticated) {
    // Right after sign-in this guard re-renders first, so it must honour the
    // page the visitor originally asked for (validated against open redirects).
    const from = (location.state as { from?: string } | null)?.from;
    return <Navigate to={safeRedirect(from)} replace />;
  }
  return <>{children}</>;
}

function NotFound() {
  return (
    <div className="py-20 text-center">
      <h1 className="text-3xl font-bold">Page not found</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-300">The page you are looking for does not exist.</p>
      <div className="mt-6"><LinkButton to="/dashboard">Back to dashboard</LinkButton></div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppStateProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/onboarding" element={<PublicOnlyRoute><Onboarding /></PublicOnlyRoute>} />
            <Route path="/register" element={<Navigate to="/onboarding" replace />} />
            <Route path="/login" element={<PublicOnlyRoute><Login /></PublicOnlyRoute>} />
            <Route
              path="/*"
              element={
                <PrivateRoute>
                  <Routes>
                    <Route path="/*" element={
                      <AuthenticatedLayout>
                        <ErrorBoundary>
                          <Routes>
                            <Route path="/dashboard" element={<Dashboard />} />
                            <Route path="/my-interview" element={<MyInterviews />} />
                            <Route path="/my-resume" element={<MyResume />} />
                            <Route path="/performance" element={<PerformanceOverview />} />
                            <Route path="/performance/:id" element={<PerformanceReport />} />
                            <Route path="/report/:id" element={<PerformanceReport />} />
                            <Route path="/setup" element={<InterviewSetup />} />
                            <Route path="/practice" element={<PracticePage />} />
                            <Route path="/room" element={<InterviewRoom />} />
                            <Route path="/interview/:id" element={<InterviewRoom />} />
                            <Route path="/history" element={<HistoryPage />} />
                            <Route path="/jobs" element={<JobNotifications />} />
                            <Route path="/saved-jobs" element={<SavedJobs />} />
                            <Route path="/settings" element={<SettingsPage />} />
                            <Route path="/profile" element={<Profile />} />
                            <Route path="*" element={<NotFound />} />
                          </Routes>
                        </ErrorBoundary>
                      </AuthenticatedLayout>
                    } />
                  </Routes>
                </PrivateRoute>
              }
            />
          </Routes>
        </BrowserRouter>
      </AppStateProvider>
    </ThemeProvider>
  );
}
