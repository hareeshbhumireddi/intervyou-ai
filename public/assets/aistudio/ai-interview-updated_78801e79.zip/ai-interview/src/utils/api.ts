import { InterviewSession, JobNotification, SavedJob, UserProfile } from '../types';

const configuredBase = (import.meta as ImportMeta & { env?: { VITE_API_URL?: string } }).env?.VITE_API_URL;
const API_BASE = (configuredBase || '/api').replace(/\/$/, '');

export const AUTH_EXPIRED_EVENT = 'intervyou:auth-expired';

export class ApiError extends Error {
  status: number;
  code?: string;
  fields?: Record<string, string>;

  constructor(message: string, status: number, code?: string, fields?: Record<string, string>) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.fields = fields;
  }
}

async function requestJson<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.body && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers,
      credentials: 'include',
    });
  } catch {
    throw new ApiError('Could not connect to the application server. Check that the Flask backend is running.', 0);
  }

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    // A 401 from a protected endpoint means the session ended (expired, revoked or
    // signed out elsewhere); tell the app so it can return to the login screen.
    if (response.status === 401 && !path.startsWith('/auth/')) window.dispatchEvent(new Event(AUTH_EXPIRED_EVENT));
    throw new ApiError(payload.error || `Request failed (${response.status}).`, response.status, payload.code, payload.fields);
  }
  return payload as T;
}

async function requestBlob(path: string): Promise<Blob> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, { credentials: 'include' });
  } catch {
    throw new ApiError('Could not connect to the application server. Check that the Flask backend is running.', 0);
  }

  if (!response.ok) {
    const payload = await response.json().catch(() => ({}));
    throw new ApiError(payload.error || `Request failed (${response.status}).`, response.status);
  }
  return response.blob();
}

export type PublicConfig = {
  aiMode: 'mock' | 'gemini' | 'unconfigured';
  languages: string[];
  degrees: string[];
  genders: string[];
  graduationYear: { min: number; max: number };
};

export type AtsResult = {
  score: number;
  grade: string;
  breakdown: { name: string; weight: number; earned: number; note: string }[];
  keywordSource: string;
  matchedKeywords: string[];
  missingKeywords: string[];
  sectionsFound: string[];
  sectionsMissing: string[];
  suggestions: string[];
  stats: { words: number; bullets: number; lines: number };
  disclaimer: string;
};

export const api = {
  analyzeResume: (body: { jobDescription?: string; role?: string }) =>
    requestJson<{ ats: AtsResult }>('/resumes/ats', { method: 'POST', body: JSON.stringify(body) }),
  config: () => requestJson<PublicConfig>('/config'),
  register: (profile: UserProfile, password: string) => requestJson<{ user: UserProfile; message: string }>('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: profile.email, password, profile }),
  }),
  login: (email: string, password: string) => requestJson<{ user: UserProfile; message: string }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  }),
  me: () => requestJson<{ user: UserProfile }>('/auth/me'),
  logout: () => requestJson<{ message: string }>('/auth/logout', { method: 'POST' }),
  updateProfile: (profile: UserProfile) => requestJson<{ user: UserProfile }>('/auth/profile', {
    method: 'PUT',
    body: JSON.stringify({ email: profile.email, profile }),
  }),
  getResume: () => requestJson<{ resume: { name: string; type: string; size: number; uploadedAt: string } }>('/resumes'),
  uploadResume: (file: File) => {
    const formData = new FormData();
    formData.append('resume', file);
    return requestJson<{ resume: { name: string; type: string; size: number; uploadedAt: string }; message: string }>('/resumes', {
      method: 'POST',
      body: formData,
    });
  },
  downloadResume: () => requestBlob('/resumes/file'),
  deleteResume: () => requestJson<{ message: string }>('/resumes', { method: 'DELETE' }),
  startInterview: (details: Record<string, unknown>) => requestJson<{ interview: InterviewSession }>('/interviews', {
    method: 'POST',
    body: JSON.stringify(details),
  }),
  listInterviews: () => requestJson<{ interviews: InterviewSession[] }>('/interviews'),
  getInterview: (id: string) => requestJson<{ interview: InterviewSession }>(`/interviews/${encodeURIComponent(id)}`),
  interviewQuestions: (id: string) => requestJson<{ questions: InterviewSession['questions'] }>(`/interview/questions?interview_id=${encodeURIComponent(id)}`),
  repeatQuestion: (interviewId: string, questionId: string) => requestJson<{ question: { id: string; question: string; category: string; repeatCount: number } }>(
    `/interviews/${encodeURIComponent(interviewId)}/questions/${encodeURIComponent(questionId)}/repeat`,
    { method: 'POST' },
  ),
  skipQuestion: (interviewId: string, questionId: string) => requestJson<{ answer: { questionId: string; answer: string; evaluation: InterviewSession['evaluations'][string] } }>(
    `/interviews/${encodeURIComponent(interviewId)}/skip`,
    { method: 'POST', body: JSON.stringify({ questionId }) },
  ),
  submitAnswer: (interviewId: string, questionId: string, answer: string) => requestJson<{ answer: { questionId: string; answer: string; evaluation: InterviewSession['evaluations'][string] } }>(
    `/interviews/${encodeURIComponent(interviewId)}/answers`,
    { method: 'POST', body: JSON.stringify({ questionId, answer }) },
  ),
  completeInterview: (interviewId: string) => requestJson<{ interview: InterviewSession }>(`/interviews/${encodeURIComponent(interviewId)}/complete`, {
    method: 'POST',
  }),
  performance: () => requestJson<{ performance: { totalInterviews: number; averageScore: number; bestScore: number; correctAnswers: number; incorrectAnswers: number; history: Array<{ interviewId: string; score: number; correct: number; incorrect: number; totalQuestions: number; date: string }> } }>('/performance'),
  savedJobs: () => requestJson<{ savedJobs: SavedJob[] }>('/saved-jobs'),
  saveJob: (job: JobNotification) => requestJson<{ savedJob: SavedJob }>('/saved-jobs', {
    method: 'POST',
    body: JSON.stringify({
      jobId: job.id,
      jobTitle: job.title,
      company: job.company,
      location: job.location,
      applyLink: job.applyLink,
    }),
  }),
  deleteSavedJob: (id: number) => requestJson<{ message: string }>(`/saved-jobs/${id}`, { method: 'DELETE' }),
};
