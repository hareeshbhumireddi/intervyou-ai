import { Moon, Sun, UserRound, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTheme } from '../components/ThemeProvider';
import { useAppState } from '../hooks/useAppState';

export default function SettingsPage() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAppState();
  const ThemeIcon = theme === 'dark' ? Sun : Moon;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header>
        <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">Workspace preferences</p>
        <h1 className="mt-1 text-3xl font-bold">Settings</h1>
        <p className="mt-2 text-sm text-slate-500">Manage your appearance and candidate profile.</p>
      </header>

      <section className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-slate-800 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between gap-4 p-5">
          <div className="flex items-center gap-3">
            <span className="rounded-lg bg-blue-50 p-2.5 text-blue-600 dark:bg-blue-500/10 dark:text-blue-300"><ThemeIcon className="h-5 w-5" /></span>
            <div><h2 className="font-semibold">Appearance</h2><p className="mt-1 text-sm text-slate-500">Currently using {theme} mode.</p></div>
          </div>
          <button onClick={toggleTheme} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`} className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">Change</button>
        </div>
        <div className="flex items-center justify-between gap-4 p-5">
          <div className="flex items-center gap-3">
            <span className="rounded-lg bg-emerald-50 p-2.5 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300"><UserRound className="h-5 w-5" /></span>
            <div><h2 className="font-semibold">Candidate profile</h2><p className="mt-1 text-sm text-slate-500">{user.email || 'Update your contact and education details.'}</p></div>
          </div>
          <Link to="/profile" className="text-sm font-semibold text-blue-600 hover:underline dark:text-blue-400">Edit profile</Link>
        </div>
        <div className="flex items-start gap-3 p-5">
          <span className="rounded-lg bg-slate-100 p-2.5 text-slate-600 dark:bg-slate-800 dark:text-slate-300"><ShieldCheck className="h-5 w-5" /></span>
          <div><h2 className="font-semibold">Local data</h2><p className="mt-1 text-sm leading-6 text-slate-500">Your profile, interview history, saved jobs, and preferences are stored in this browser.</p></div>
        </div>
      </section>
    </div>
  );
}