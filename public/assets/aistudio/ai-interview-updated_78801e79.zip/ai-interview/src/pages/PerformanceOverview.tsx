import { useEffect, useState } from 'react';
import { Activity, Award, BarChart3, CheckCircle2, Target, XCircle } from 'lucide-react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useAppState } from '../hooks/useAppState';
import { api } from '../utils/api';

export default function PerformanceOverview() {
  const { sessions, user } = useAppState();
  const [performance, setPerformance] = useState<Awaited<ReturnType<typeof api.performance>>['performance'] | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let isActive = true;
    api.performance()
      .then(({ performance: result }) => { if (isActive) setPerformance(result); })
      .catch((loadError) => { if (isActive) setError(loadError instanceof Error ? loadError.message : 'Could not load performance data.'); });
    return () => { isActive = false; };
  }, []);

  const chartData = sessions.slice(0, 8).reverse().map((session, index) => ({
    name: `Session ${index + 1}`,
    score: session.overallReport?.overallScore ?? 0,
  }));
  const stats = [
    { label: 'Sessions completed', value: performance?.totalInterviews ?? 0, icon: Activity },
    { label: 'Average score', value: `${performance?.averageScore ?? 0}%`, icon: BarChart3 },
    { label: 'Personal best', value: `${performance?.bestScore ?? 0}%`, icon: Award },
    { label: 'Correct answers', value: performance?.correctAnswers ?? 0, icon: CheckCircle2 },
    { label: 'Incorrect answers', value: performance?.incorrectAnswers ?? 0, icon: XCircle },
    { label: 'Practice goal', value: `${Math.min(sessions.length, 5)}/5`, icon: Target },
  ];

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">Progress overview</p>
        <h1 className="mt-1 text-3xl font-bold">Performance</h1>
        <p className="mt-2 text-sm text-slate-500">Track your interview practice scores and improvement.</p>
      </header>

      {error && <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300">{error}</p>}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <article key={label} className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <Icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <p className="mt-4 text-sm text-slate-500">{label}</p>
            <p className="mt-1 text-2xl font-bold">{value}</p>
          </article>
        ))}
      </section>

      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 sm:p-6">
        <h2 className="font-semibold">Score trend</h2>
        <div className="mt-5 h-72">
          {chartData.length ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="performanceScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} axisLine={false} tickLine={false} />
                <Tooltip />
                <Area type="monotone" dataKey="score" stroke="#2563eb" strokeWidth={2} fill="url(#performanceScore)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-slate-500">Complete an interview to see your score trend.</div>
          )}
        </div>
      </section>

      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-4 dark:border-slate-800"><h2 className="font-semibold">Recent interview results</h2></div>
        {performance?.history.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500 dark:bg-slate-800/50">
                <tr><th className="px-5 py-3 font-semibold">Date</th><th className="px-5 py-3 font-semibold">Score</th><th className="px-5 py-3 font-semibold">Correct</th><th className="px-5 py-3 font-semibold">Incorrect</th><th className="px-5 py-3 font-semibold">Questions</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {[...performance.history].reverse().slice(0, 10).map((record) => (
                  <tr key={record.interviewId}>
                    <td className="px-5 py-3">{new Date(record.date).toLocaleDateString()}</td>
                    <td className="px-5 py-3 font-semibold">{record.score}%</td>
                    <td className="px-5 py-3">{record.correct}</td>
                    <td className="px-5 py-3">{record.incorrect}</td>
                    <td className="px-5 py-3">{record.totalQuestions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="px-5 py-8 text-sm text-slate-500">{performance ? 'No completed interviews yet.' : 'Loading performance history...'}</p>
        )}
      </section>
    </div>
  );
}