import { useEffect, useState } from 'react';
import { Bookmark, BookmarkX, ExternalLink, Loader2, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SavedJob } from '../types';
import { api } from '../utils/api';

export default function SavedJobs() {
  const [savedJobs, setSavedJobs] = useState<SavedJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [removingId, setRemovingId] = useState<number | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let isActive = true;
    api.savedJobs()
      .then(({ savedJobs: records }) => { if (isActive) setSavedJobs(records); })
      .catch((loadError) => { if (isActive) setError(loadError instanceof Error ? loadError.message : 'Could not load saved jobs.'); })
      .finally(() => { if (isActive) setIsLoading(false); });
    return () => { isActive = false; };
  }, []);

  const removeJob = async (job: SavedJob) => {
    if (!window.confirm(`Remove ${job.title} from saved jobs?`)) return;
    setRemovingId(job.id);
    setError('');
    try {
      await api.deleteSavedJob(job.id);
      setSavedJobs((current) => current.filter((saved) => saved.id !== job.id));
    } catch (removeError) {
      setError(removeError instanceof Error ? removeError.message : 'Could not remove this saved job.');
    } finally {
      setRemovingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">Your opportunities</p>
        <h1 className="mt-1 text-3xl font-bold">Saved Jobs</h1>
        <p className="mt-2 text-sm text-slate-500">Opportunities you bookmarked from Job Alerts.</p>
      </header>

      {error && <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300">{error}</p>}

      {isLoading ? (
        <div className="flex min-h-48 items-center justify-center text-sm text-slate-500"><Loader2 className="mr-2 h-4 w-4 animate-spin" />Loading saved jobs...</div>
      ) : savedJobs.length ? (
        <section className="grid gap-4 lg:grid-cols-2">
          {savedJobs.map((job) => (
            <article key={job.id} className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase text-blue-600 dark:text-blue-400">{job.company}</p>
                  <h2 className="mt-2 text-lg font-semibold">{job.title}</h2>
                  <p className="mt-2 flex items-center gap-1.5 text-sm text-slate-500"><MapPin className="h-4 w-4" />{job.location}</p>
                </div>
                <button onClick={() => void removeJob(job)} disabled={removingId === job.id} aria-label={`Remove ${job.title} from saved jobs`} className="rounded-lg p-2 text-slate-500 hover:bg-red-50 hover:text-red-600 disabled:opacity-60 dark:hover:bg-red-500/10">
                  {removingId === job.id ? <Loader2 className="h-5 w-5 animate-spin" /> : <BookmarkX className="h-5 w-5" />}
                </button>
              </div>
              <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
                <span className="text-sm text-slate-500">Saved {new Date(job.savedAt).toLocaleDateString()}</span>
                {job.applyLink && <a href={job.applyLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-blue-600 hover:underline dark:text-blue-400">Apply <ExternalLink className="h-4 w-4" /></a>}
              </div>
            </article>
          ))}
        </section>
      ) : (
        <section className="rounded-xl border border-dashed border-slate-300 bg-white px-6 py-14 text-center dark:border-slate-700 dark:bg-slate-900">
          <Bookmark className="mx-auto h-8 w-8 text-slate-400" />
          <h2 className="mt-3 font-semibold">No saved jobs</h2>
          <p className="mt-2 text-sm text-slate-500">Bookmark a job from Job Alerts and it will appear here.</p>
          <Link to="/jobs" className="mt-5 inline-flex rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700">Browse job alerts</Link>
        </section>
      )}
    </div>
  );
}