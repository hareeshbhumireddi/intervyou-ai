import { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Briefcase, 
  Search, 
  Filter, 
  MapPin, 
  Calendar, 
  ExternalLink, 
  Bookmark, 
  BookmarkCheck,
  Share2,
  Building2,
  GraduationCap,
  Clock,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Bell,
  CheckCircle2,
  Trophy,
  Zap,
  Globe,
  Star,
  PlayCircle,
  Loader2
} from 'lucide-react';
import { useAppState } from '../hooks/useAppState';
import { JobNotification, InterviewSession, SavedJob } from '../types';
import { api } from '../utils/api';

export default function JobNotifications() {
  const { notifications, bookmarkedIds, toggleBookmark, readIds, markAsRead, addSession } = useAppState();
  const navigate = useNavigate();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [sectorFilter, setSectorFilter] = useState<'All' | 'Private' | 'Government'>('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isPreparing, setIsPreparing] = useState(false);
  const [actionError, setActionError] = useState('');
  const [savedJobs, setSavedJobs] = useState<SavedJob[]>([]);

  useEffect(() => {
    let isActive = true;
    api.savedJobs()
      .then(({ savedJobs: records }) => { if (isActive) setSavedJobs(records); })
      .catch((error) => {
        if (isActive) setActionError(error instanceof Error ? error.message : 'Could not load saved jobs.');
      });
    return () => { isActive = false; };
  }, []);

  const categories = useMemo(() => {
    const all = notifications.map(n => n.category);
    return ['All', ...Array.from(new Set(all))];
  }, [notifications]);

  const filteredNotifications = useMemo(() => {
    return notifications.filter(n => {
      const matchesSearch = n.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           n.company.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesSector = sectorFilter === 'All' || n.sector === sectorFilter;
      const matchesCategory = categoryFilter === 'All' || n.category === categoryFilter;
      return matchesSearch && matchesSector && matchesCategory;
    });
  }, [notifications, searchQuery, sectorFilter, categoryFilter]);

  const handlePractice = async (job: JobNotification) => {
    setIsPreparing(true);
    setActionError('');
    markAsRead(job.id);
    try {
      const { interview } = await api.startInterview({
        role: job.title,
        sector: job.sector,
        difficulty: 'Intermediate',
        preferredLanguage: 'English',
        numQuestions: 5,
        jobId: job.id,
        companyName: job.company,
        category: job.category,
        experience: job.experience,
        qualification: job.qualification,
      });
      addSession(interview as InterviewSession);
      navigate(`/interview/${interview.id}`);
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Could not prepare this interview. Please try again.');
    } finally {
      setIsPreparing(false);
    }
  };

  const handleBookmark = async (job: JobNotification) => {
    setActionError('');
    const existing = savedJobs.find((saved) => saved.jobId === job.id || (saved.title === job.title && saved.company === job.company));
    try {
      if (existing) {
        await api.deleteSavedJob(existing.id);
        setSavedJobs((current) => current.filter((saved) => saved.id !== existing.id));
        if (bookmarkedIds.includes(job.id)) toggleBookmark(job.id);
      } else {
        const { savedJob } = await api.saveJob(job);
        setSavedJobs((current) => [savedJob, ...current]);
        if (!bookmarkedIds.includes(job.id)) toggleBookmark(job.id);
      }
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Could not update saved jobs.');
    }
  };

  const isJobSaved = (job: JobNotification) => savedJobs.some((saved) => saved.jobId === job.id || (saved.title === job.title && saved.company === job.company));

  const handleShare = (job: JobNotification) => {
    if (navigator.share) {
      navigator.share({
        title: `${job.title} at ${job.company}`,
        text: `Check out this job opportunity: ${job.title} at ${job.company}`,
        url: window.location.href,
      }).catch(console.error);
    } else {
      alert('Link copied to clipboard!');
      navigator.clipboard.writeText(window.location.href);
    }
  };

  if (isPreparing) {
    return (
      <div className="h-[80vh] flex flex-col items-center justify-center p-8 space-y-8">
        <div className="relative">
          <motion.div 
            className="w-32 h-32 rounded-[40px] bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center shadow-2xl shadow-blue-500/40"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Loader2 className="w-16 h-16 text-white animate-spin" />
          </motion.div>
          <div className="absolute inset-0 bg-blue-400 blur-3xl opacity-20 animate-pulse -z-10" />
        </div>
        <div className="text-center space-y-4 max-w-md">
          <h2 className="text-3xl font-black bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            Preparing your personalized interview...
          </h2>
          <p className="text-slate-500 font-bold">
            Our AI is analyzing the job description, company requirements, and industry standards to generate the most relevant questions for you.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-24">
      {actionError && <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300">{actionError}</p>}
      {/* Header Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 to-purple-600/5 blur-3xl rounded-full -z-10" />
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          <div className="flex items-center space-x-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-blue-500/30 relative">
              <Bell className="w-10 h-10 text-white" />
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center border-4 border-white dark:border-slate-900 shadow-lg">
                <span className="text-[10px] font-black text-white">{notifications.filter(n => !readIds.includes(n.id)).length}</span>
              </div>
            </div>
            <div>
              <h1 className="text-4xl font-black tracking-tight mb-2">Job Notifications</h1>
              <p className="text-slate-500 font-bold flex items-center space-x-2">
                <Briefcase className="w-4 h-4" />
                <span>Find your dream career in Private or Government sectors</span>
              </p>
            </div>
          </div>
          
          <div className="flex w-full md:w-auto gap-4">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text"
                placeholder="Search jobs, companies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold text-sm"
              />
            </div>
            <button 
              onClick={() => setIsFilterOpen(!isFilterOpen)}
              className={`p-3 rounded-2xl border transition-all ${isFilterOpen ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'}`}
            >
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filters Overlay */}
        <AnimatePresence>
          {isFilterOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-8 p-8 rounded-[32px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/20 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Sector</label>
                  <div className="flex gap-2">
                    {['All', 'Private', 'Government'].map(s => (
                      <button 
                        key={s}
                        onClick={() => setSectorFilter(s as any)}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${sectorFilter === s ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-slate-50 dark:bg-slate-800 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Job Category</label>
                  <select 
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border-none rounded-xl text-xs font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-3 flex flex-col justify-end">
                   <button 
                    onClick={() => {
                      setSearchQuery('');
                      setSectorFilter('All');
                      setCategoryFilter('All');
                    }}
                    className="w-full py-2 px-3 bg-red-50 dark:bg-red-900/10 text-red-600 rounded-xl text-xs font-bold hover:bg-red-100 transition-all"
                   >
                     Reset All Filters
                   </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredNotifications.map((job) => (
          <motion.div 
            layout
            key={job.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => markAsRead(job.id)}
            className="group p-8 rounded-[40px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 dark:hover:shadow-none transition-all relative overflow-hidden flex flex-col h-full"
          >
            {job.isFeatured && (
              <div className="absolute top-6 right-6">
                <Star className="w-5 h-5 text-yellow-400 fill-current" />
              </div>
            )}
            
            <div className="space-y-6 flex-1">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${job.sector === 'Private' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'} dark:bg-slate-800`}>
                      {job.sector} Sector
                    </span>
                    {job.status === 'New' && (
                      <span className="px-3 py-1 rounded-full bg-green-50 dark:bg-slate-800 text-green-600 text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
                        <Zap className="w-2.5 h-2.5" />
                        New
                      </span>
                    )}
                  </div>
                  <h3 className="text-xl font-black group-hover:text-blue-600 transition-colors pt-2">{job.title}</h3>
                  <p className="text-slate-500 font-bold flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-slate-400" />
                    {job.company}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 space-y-1">
                  <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Location</p>
                  <p className="text-xs font-bold flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-blue-500" />
                    {job.location}
                  </p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 space-y-1">
                  <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Salary</p>
                  <p className="text-xs font-bold flex items-center gap-1">
                    <Zap className="w-3 h-3 text-orange-500" />
                    {job.salary || 'Best in Industry'}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3 text-xs font-medium text-slate-600 dark:text-slate-400">
                  <GraduationCap className="w-4 h-4 text-blue-500" />
                  <span><span className="font-bold">Required:</span> {job.qualification}</span>
                </div>
                <div className="flex items-center space-x-3 text-xs font-medium text-slate-600 dark:text-slate-400">
                  <Clock className="w-4 h-4 text-purple-500" />
                  <span><span className="font-bold">Experience:</span> {job.experience}</span>
                </div>
                <div className="flex items-center space-x-3 text-xs font-medium text-slate-600 dark:text-slate-400">
                  <Calendar className="w-4 h-4 text-red-500" />
                  <span><span className="font-bold">Last Date:</span> {new Date(job.lastDate).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <div className="pt-8 flex flex-col gap-3">
              <div className="flex gap-3">
                <a 
                  href={job.applyLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-2xl font-black text-sm flex items-center justify-center space-x-2 shadow-sm hover:bg-slate-50 transition-all"
                >
                  <span>Apply Now</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    void handleBookmark(job);
                  }}
                  aria-label={isJobSaved(job) ? `Remove ${job.title} from saved jobs` : `Save ${job.title}`}
                  className={`p-4 rounded-2xl border transition-all ${isJobSaved(job) ? 'bg-blue-50 border-blue-100 text-blue-600' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400'}`}
                >
                  {isJobSaved(job) ? <BookmarkCheck className="w-5 h-5" /> : <Bookmark className="w-5 h-5" />}
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleShare(job);
                  }}
                  className="p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 hover:text-blue-600 transition-all"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  handlePractice(job);
                }}
                className="w-full py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-2xl font-black text-sm flex items-center justify-center space-x-2 shadow-lg shadow-blue-500/25 hover:scale-105 transition-all"
              >
                <PlayCircle className="w-5 h-5" />
                <span>Practice Interview</span>
              </button>
            </div>
          </motion.div>
        ))}

        {filteredNotifications.length === 0 && (
          <div className="col-span-full py-20 text-center space-y-6">
            <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-[32px] flex items-center justify-center mx-auto">
              <Search className="w-12 h-12 text-slate-300" />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-black">No jobs found</h3>
              <p className="text-slate-500 font-medium">Try adjusting your search or filters to find more opportunities.</p>
            </div>
            <button 
              onClick={() => {
                setSearchQuery('');
                setSectorFilter('All');
                setCategoryFilter('All');
              }}
              className="px-8 py-3 bg-blue-600 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>

      {/* Floating CTA */}
      <div className="fixed bottom-32 left-1/2 -translate-x-1/2 z-40 md:hidden">
        <button 
          onClick={() => setIsFilterOpen(true)}
          className="px-6 py-4 bg-slate-900 text-white rounded-full font-black flex items-center space-x-3 shadow-2xl"
        >
          <Filter className="w-5 h-5" />
          <span>Advanced Filters</span>
        </button>
      </div>
    </div>
  );
}
