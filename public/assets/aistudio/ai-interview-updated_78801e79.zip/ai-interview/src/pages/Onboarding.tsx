import { useMemo, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Check, ChevronLeft, ChevronRight } from 'lucide-react';
import { ApiError, api } from '../utils/api';
import type { UserProfile } from '../types';
import { Alert, AuthShell, Button, SelectField, TextAreaField, TextField } from '../components/ui';
import {
  DEGREES, GENDERS, LANGUAGES, STEP_FIELDS, validateField, validateFields,
} from '../utils/validation';
import type { FieldErrors, RegistrationValues } from '../utils/validation';

const EMPTY: RegistrationValues = {
  fullName: '', dob: '', gender: '', email: '', mobile: '', address: '', preferredLanguage: '',
  qualification: '', password: '', confirmPassword: '', degree: '', college: '', specialization: '',
  graduationYear: '', cgpa: '',
};

const STEPS = [
  { id: 1 as const, title: 'Personal details', blurb: 'Tell us who you are.' },
  { id: 2 as const, title: 'Contact & account', blurb: 'How we reach you and how you sign in.' },
  { id: 3 as const, title: 'Education', blurb: 'Your academic background.' },
];

// Server reports nested keys such as "education.graduationYear"; the form uses flat names.
const fromServerKey = (key: string) => (key.startsWith('education.') ? key.slice('education.'.length) : key);

function toProfile(v: RegistrationValues): UserProfile {
  return {
    fullName: v.fullName.trim(), dob: v.dob, gender: v.gender, email: v.email.trim(), mobile: v.mobile.trim(),
    address: v.address.trim(), qualification: v.qualification.trim(), preferredLanguage: v.preferredLanguage,
    education: { degree: v.degree, college: v.college.trim(), specialization: v.specialization.trim(), graduationYear: v.graduationYear.trim(), cgpa: v.cgpa.trim() },
    skills: [], certificates: [], stats: { totalInterviews: 0, avgScore: 0, bestScore: 0 }, isCompleted: true,
  };
}

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [values, setValues] = useState<RegistrationValues>(EMPTY);
  const [touched, setTouched] = useState<Set<string>>(new Set());
  const [serverErrors, setServerErrors] = useState<FieldErrors>({});
  const [submitError, setSubmitError] = useState('');
  const [duplicateEmail, setDuplicateEmail] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const inFlight = useRef(false);
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  const liveErrors = useMemo(() => validateFields(STEP_FIELDS[1].concat(STEP_FIELDS[2], STEP_FIELDS[3]), values), [values]);
  // Show an error once the field was visited/submitted; a server error shows until the user edits that field.
  const errorFor = (field: keyof RegistrationValues) => (touched.has(field) ? liveErrors[field] : '') || serverErrors[field] || '';

  const set = (field: keyof RegistrationValues) => (e: { target: { value: string } }) => {
    setValues((prev) => ({ ...prev, [field]: e.target.value }));
    if (serverErrors[field]) setServerErrors((prev) => { const next = { ...prev }; delete next[field]; return next; });
    if (field === 'email') setDuplicateEmail(false);
  };
  const blur = (field: keyof RegistrationValues) => () => setTouched((prev) => new Set(prev).add(field));
  const common = (field: keyof RegistrationValues) => ({ value: values[field], onChange: set(field), onBlur: blur(field), error: errorFor(field) });

  const touchStep = (s: 1 | 2 | 3) => setTouched((prev) => new Set([...prev, ...STEP_FIELDS[s]]));

  const goNext = (e?: FormEvent) => {
    e?.preventDefault();
    touchStep(step);
    // Re-validate the whole step; refuse to advance if anything is invalid.
    if (Object.keys(validateFields(STEP_FIELDS[step], values)).length > 0) {
      requestAnimationFrame(() => document.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus());
      return;
    }
    setStep((s) => (Math.min(3, s + 1) as 1 | 2 | 3));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (inFlight.current) return; // prevents accidental duplicate submissions
    setSubmitError('');
    setDuplicateEmail(false);
    // Revalidate everything, not just the current step.
    const all = validateFields([...STEP_FIELDS[1], ...STEP_FIELDS[2], ...STEP_FIELDS[3]], values);
    if (Object.keys(all).length > 0) {
      setTouched(new Set(Object.keys(values)));
      const firstBad = ([1, 2, 3] as const).find((s) => STEP_FIELDS[s].some((f) => all[f]))!;
      setStep(firstBad);
      setSubmitError('Some details need attention. Please fix the highlighted fields.');
      return;
    }
    inFlight.current = true;
    setSubmitting(true);
    try {
      await api.register(toProfile(values), values.password);
      navigate('/login', { state: { registered: true, email: values.email.trim() }, replace: true });
    } catch (error) {
      if (error instanceof ApiError && error.fields) {
        const mapped: FieldErrors = {};
        for (const [key, message] of Object.entries(error.fields)) mapped[fromServerKey(key)] = message;
        setServerErrors(mapped);
        setTouched(new Set(Object.keys(values)));
        const firstBad = ([1, 2, 3] as const).find((s) => STEP_FIELDS[s].some((f) => mapped[f]));
        if (firstBad) setStep(firstBad);
        setDuplicateEmail(error.status === 409);
      }
      setSubmitError(error instanceof Error ? error.message : 'Registration failed. Please try again.');
    } finally {
      inFlight.current = false;
      setSubmitting(false);
    }
  };

  const current = STEPS[step - 1];

  return (
    <AuthShell
      wide
      title="Create your account"
      subtitle={`Step ${step} of 3 — ${current.title}. ${current.blurb}`}
      footer={<>Already have an account? <Link to="/login" className="font-semibold text-brand-600 hover:underline">Sign in</Link></>}
    >
      <ol className="mb-6 flex items-center gap-2" aria-label="Registration progress">
        {STEPS.map((s) => (
          <li key={s.id} className="flex flex-1 items-center gap-2" aria-current={s.id === step ? 'step' : undefined}>
            <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${s.id < step ? 'bg-green-600 text-white' : s.id === step ? 'bg-brand-600 text-white' : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'}`}>
              {s.id < step ? <Check className="h-4 w-4" aria-label="completed" /> : s.id}
            </span>
            <span className={`hidden text-sm font-medium sm:block ${s.id === step ? 'text-slate-900 dark:text-white' : 'text-slate-500'}`}>{s.title}</span>
            {s.id < 3 && <span className="h-px flex-1 bg-slate-200 dark:bg-slate-700" aria-hidden />}
          </li>
        ))}
      </ol>

      <form onSubmit={step === 3 ? submit : goNext} noValidate className="space-y-5" aria-label={`Registration step ${step}`}>
        {step === 1 && (
          <>
            <TextField label="Full name" required autoComplete="name" placeholder="e.g. Bhargavi Konda" {...common('fullName')} />
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField label="Date of birth" required type="date" min="1900-01-01" max={today} autoComplete="bday" {...common('dob')} />
              <SelectField label="Gender" {...common('gender')}>
                <option value="">Prefer not to say</option>
                {GENDERS.map((g) => <option key={g} value={g}>{g}</option>)}
              </SelectField>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <TextField label="Email address" required type="email" inputMode="email" autoComplete="email" placeholder="name@example.com" {...common('email')} />
            {duplicateEmail && (
              <Alert tone="info" action={<Link to="/login" state={{ email: values.email.trim() }} className="font-semibold underline">Go to sign in</Link>}>
                This email already has an account.
              </Alert>
            )}
            <TextField label="Mobile number" required type="tel" inputMode="numeric" autoComplete="tel-national" prefix="+91" placeholder="10-digit number" hint="Digits only, starting with 6–9." {...common('mobile')} />
            <SelectField label="Preferred language" required {...common('preferredLanguage')}>
              <option value="">Select a language</option>
              {LANGUAGES.map((l) => <option key={l} value={l}>{l}</option>)}
            </SelectField>
            <TextAreaField label="Current address" placeholder="Optional" autoComplete="street-address" {...common('address')} />
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField label="Password" required type="password" autoComplete="new-password" hint="At least 8 characters." {...common('password')} />
              <TextField label="Confirm password" required type="password" autoComplete="new-password" {...common('confirmPassword')} />
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <div className="grid gap-5 sm:grid-cols-2">
              <SelectField label="Degree" required {...common('degree')}>
                <option value="">Select degree</option>
                {DEGREES.map((d) => <option key={d} value={d}>{d}</option>)}
              </SelectField>
              <TextField label="Specialization" placeholder="e.g. Computer Science" {...common('specialization')} />
            </div>
            <TextField label="College / university" required autoComplete="organization" placeholder="Your institution" {...common('college')} />
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField label="Graduation (passing) year" required inputMode="numeric" placeholder="YYYY" hint="Four digits, e.g. 2025." {...common('graduationYear')} />
              <TextField label="CGPA / percentage" inputMode="decimal" placeholder="e.g. 8.5" {...common('cgpa')} />
            </div>
            <TextField label="Highest qualification" placeholder="e.g. Bachelor of Technology" {...common('qualification')} />
          </>
        )}

        {submitError && (
          <Alert tone="error">{submitError}</Alert>
        )}

        <div className="flex gap-3 pt-2">
          {step > 1 && (
            <Button type="button" variant="secondary" onClick={() => setStep((s) => (s - 1) as 1 | 2 | 3)} disabled={submitting}>
              <ChevronLeft className="h-4 w-4" aria-hidden /> Back
            </Button>
          )}
          {step < 3 ? (
            <Button type="submit" full>Next <ChevronRight className="h-4 w-4" aria-hidden /></Button>
          ) : (
            <Button type="submit" full loading={submitting}>{submitting ? 'Creating account…' : 'Create account'}</Button>
          )}
        </div>
      </form>
    </AuthShell>
  );
}
