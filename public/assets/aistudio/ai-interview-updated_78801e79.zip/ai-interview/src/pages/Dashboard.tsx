import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  History, 
  TrendingUp, 
  Target, 
  Award, 
  AlertCircle, 
  ChevronRight,
  Clock,
  Briefcase,
  Bell,
  MapPin,
  ExternalLink,
  Zap
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useAppState } from '../hooks/useAppState';

export default function Dashboard() {
  const { user, sessions, notifications } = useAppState();

  const data = sessions.slice(0, 7).reverse().map((s, i) => ({
    name: `Session ${i + 1}`,
    score: s.overallReport?.overallScore || 0,
  }));

  const stats = [
    { label: 'Interviews Taken', value: user.stats.totalInterviews, icon: History, color: 'blue' },
    { label: 'Average Score', value: `${user.stats.avgScore}%`, icon: TrendingUp, color: 'purple' },
    { label: 'Best Score', value: `${user.stats.bestScore}%`, icon: Award, color: 'green' },
    { label: 'Practice Goal', value: `${Math.min(user.stats.totalInterviews, 5)}/5 interviews`, icon: Target, color: 'orange' },
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">Welcome back, {user.fullName || 'User'}! 👋</h1>
          <p className="text-slate-600 dark:text-slate-400">Ready to level up your interview skills today?</p>
        </div>
        <div className="flex items-center space-x-4">
          <Link
            to="/jobs"
            className="flex items-center space-x-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 px-6 py-3 rounded-2xl font-bold shadow-sm hover:bg-slate-50 transition-all"
          >
            <Bell className="w-5 h-5 text-blue-600" />
            <span>Job Alerts</span>
          </Link>
          <Link
            to="/setup"
            className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-2xl font-bold shadow-lg shadow-blue-500/20 hover:scale-105 transition-transform"
          >
            <Plus className="w-5 h-5" />
            <span>New Mock Interview</span>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm"
          >
            <div className={`w-12 h-12 rounded-2xl bg-${stat.color}-50 dark:bg-${stat.color}-900/20 flex items-center justify-center mb-4`}>
              <stat.icon className={`w-6 h-6 text-${stat.color}-600 dark:text-${stat.color}-400`} />
            </div>
            <p className="text-slate-600 dark:text-slate-400 text-sm font-medium">{stat.label}</p>
            <p className="text-2xl font-bold mt-1">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Performance Chart */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="lg:col-span-2 p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-xl font-bold">Performance Trend</h2>
            <div className="flex items-center space-x-2 text-sm text-slate-500">
              <div className="w-3 h-3 bg-blue-600 rounded-full" />
              <span>Interview Score</span>
            </div>
          </div>
          <div className="h-[300px] w-full">
            {data.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563EB" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#2563EB" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748B', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748B', fontSize: 12}} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    itemStyle={{ color: '#2563EB', fontWeight: 'bold' }}
                  />
                  <Area type="monotone" dataKey="score" stroke="#2563EB" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400">
                <TrendingUp className="w-12 h-12 mb-2 opacity-20" />
                <p>Start an interview to see your progress</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Quick Actions & Tips */}
        <div className="space-y-8">
          <div className="p-8 rounded-[32px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold flex items-center space-x-3">
                <Bell className="w-6 h-6 text-blue-600" />
                <span>Latest Jobs</span>
              </h2>
              <Link to="/jobs" className="text-xs font-black text-blue-600 hover:underline uppercase tracking-widest">View All</Link>
            </div>
            <div className="space-y-4">
              {notifications.slice(0, 3).map((job) => (
                <div key={job.id} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 group hover:border-blue-200 transition-all">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate pr-2">{job.title}</h4>
                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest ${job.sector === 'Private' ? 'bg-blue-100 text-blue-600' : 'bg-purple-100 text-purple-600'}`}>
                      {job.sector}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span className="flex items-center">
                      <MapPin className="w-3 h-3 mr-1" />
                      {job.location.split(',')[0]}
                    </span>
                    <a href={job.applyLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 font-bold flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span>Apply</span>
                      <ExternalLink className="w-2.5 h-2.5 ml-1" />
                    </a>
                  </div>
                </div>
              ))}
              {notifications.length === 0 && <p className="text-slate-500 text-sm italic text-center py-4">No job notifications yet</p>}
            </div>
          </div>

          <div className="p-8 rounded-3xl bg-blue-600 text-white shadow-xl shadow-blue-500/20">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xl font-bold mb-2">Ready to shine?</h3>
                <p className="text-blue-100 text-sm mb-6">Our AI suggests practicing Behavioral questions next based on your history.</p>
                <Link to="/setup" className="bg-white text-blue-600 px-6 py-2 rounded-xl font-bold text-sm inline-block shadow-lg">
                  Practice Now
                </Link>
              </div>
              <div className="p-3 bg-white/20 rounded-2xl">
                <AlertCircle className="w-6 h-6" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent History */}
      <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-xl font-bold">Recent Activity</h2>
          <Link to="/history" className="text-blue-600 font-semibold text-sm hover:underline">View All</Link>
        </div>
        <div className="space-y-4">
          {sessions.length > 0 ? (
            sessions.slice(0, 3).map((session, i) => (
              <div key={i} className="flex items-center justify-between p-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-center">
                    <Briefcase className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">{session.role}</h4>
                    <p className="text-sm text-slate-500 flex items-center space-x-3">
                      <span className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {new Date(session.date).toLocaleDateString()}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-bold uppercase tracking-wider ${
                        session.sector === 'Government' 
                          ? 'bg-orange-100 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400' 
                          : 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400'
                      }`}>
                        {session.sector}
                      </span>
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-6">
                  <div className="text-right">
                    <p className="text-lg font-bold text-blue-600">{session.overallReport?.overallScore || 'N/A'}%</p>
                    <p className="text-xs text-slate-500 uppercase tracking-wider">{session.difficulty}</p>
                  </div>
                  <Link to={`/report/${session.id}`} className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <ChevronRight className="w-5 h-5" />
                  </Link>
                </div>
              </div>
            ))
          ) : (
            <div className="py-12 text-center text-slate-400">
              <p>No interview activity yet. Take your first mock interview!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
