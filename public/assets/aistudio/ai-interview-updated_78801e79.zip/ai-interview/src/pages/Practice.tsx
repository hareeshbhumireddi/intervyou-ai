import { ArrowRight, Building2, Landmark, Mic } from 'lucide-react';
import { Link } from 'react-router-dom';

const practiceModes = [
  { title: 'Private sector', detail: 'Role-specific and technical interview practice.', icon: Building2 },
  { title: 'Government sector', detail: 'Exam, department, and public-service interview practice.', icon: Landmark },
  { title: 'Voice interview', detail: 'Use your microphone for spoken answers and transcription.', icon: Mic },
];

export default function PracticePage() {
  return (
    <div className="mx-auto max-w-4xl space-y-8">
      <header>
        <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">Build interview confidence</p>
        <h1 className="mt-1 text-3xl font-bold">Practice</h1>
        <p className="mt-2 text-sm text-slate-500">Choose a guided mock interview and practice at your own pace.</p>
      </header>

      <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 sm:p-8">
        <div className="grid gap-5 sm:grid-cols-3">
          {practiceModes.map(({ title, detail, icon: Icon }) => (
            <div key={title} className="border-l-2 border-blue-500 pl-4">
              <Icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              <h2 className="mt-3 font-semibold">{title}</h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">{detail}</p>
            </div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 pt-6 dark:border-slate-800">
          <p className="text-sm text-slate-500">Select your sector, role, and difficulty to begin.</p>
          <Link to="/setup" className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700">
            Configure interview <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}