import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import { useAppState } from '../hooks/useAppState';
import { ApiError, api } from '../utils/api';
import { safeRedirect } from '../utils/validation';
import { Alert, AuthShell, Button, TextField } from '../components/ui';

type LoginState = { registered?: boolean; email?: string; from?: string; reason?: 'expired' } | null;

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as LoginState;
  const { setAuthenticated, setUser, serverUnreachable } = useAppState();
  const [email, setEmail] = useState(state?.email || '');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError('');
    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }
    setLoading(true);
    try {
      const result = await api.login(email.trim(), password);
      // Merge with defaults: the server profile has no `stats`, which pages read.
      setUser((current) => ({ ...current, ...result.user }));
      setAuthenticated(true);
      navigate(safeRedirect(state?.from), { replace: true });
    } catch (err) {
      setError(err instanceof ApiError || err instanceof Error ? err.message : 'Sign in failed. Please try again.');
      setPassword('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell
      title="Welcome back"
      subtitle="Sign in to continue your interview practice."
      footer={<>New here? <Link to="/onboarding" className="font-semibold text-brand-600 hover:underline">Create an account</Link></>}
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-5" aria-label="Sign in">
        {state?.registered && <Alert tone="success">Account created. Sign in to get started.</Alert>}
        {state?.reason === 'expired' && <Alert tone="info">Your session expired. Please sign in again.</Alert>}
        {serverUnreachable && <Alert tone="error">Cannot reach the application server. Check that the backend is running.</Alert>}
        <TextField label="Email" type="email" inputMode="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <div className="space-y-1.5">
          <TextField label="Password" type={show ? 'text' : 'password'} autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          <button type="button" onClick={() => setShow((s) => !s)} aria-pressed={show} className="inline-flex items-center gap-1.5 rounded text-sm text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white">
            {show ? <EyeOff className="h-4 w-4" aria-hidden /> : <Eye className="h-4 w-4" aria-hidden />}
            {show ? 'Hide password' : 'Show password'}
          </button>
        </div>
        {error && <Alert tone="error">{error}</Alert>}
        <Button type="submit" full loading={loading}>{loading ? 'Signing in…' : 'Sign in'}</Button>
      </form>
    </AuthShell>
  );
}
