import { ArrowRight, Calendar, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAppState } from '../hooks/useAppState';

export default function MyInterviews() {
  const { sessions } = useAppState();

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">Your preparation</p>
          <h1 className="mt-1 text-3xl font-bold">My Interview</h1>
          <p className="mt-2 text-sm text-slate-500">Review sessions and continue practicing for your target roles.</p>
        </div>
        <Link to="/setup" className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700">
          <Plus className="h-4 w-4" /> New interview
        </Link>
      </header>

      {sessions.length ? (
        <section className="divide-y divide-slate-200 overflow-hidden rounded-xl border border-slate-200 bg-white dark:divide-slate-800 dark:border-slate-800 dark:bg-slate-900">
          {sessions.map((session) => (
            <Link key={session.id} to={`/performance/${session.id}`} className="flex flex-wrap items-center justify-between gap-4 p-5 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/60">
              <div className="min-w-0">
                <h2 className="truncate font-semibold">{session.role}</h2>
                <div className="mt-1 flex flex-wrap items-center gap-3 text-sm text-slate-500">
                  <span>{session.sector} sector</span>
                  <span>{session.difficulty}</span>
                  <span className="inline-flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />{new Date(session.date).toLocaleDateString()}</span>
                </div>
              </div>
              <span className="inline-flex items-center gap-2 text-sm font-semibold text-blue-600 dark:text-blue-400">
                {session.overallReport ? `${session.overallReport.overallScore}% score` : 'View session'}
                <ArrowRight className="h-4 w-4" />
              </span>
            </Link>
          ))}
        </section>
      ) : (
        <section className="rounded-xl border border-dashed border-slate-300 bg-white px-6 py-14 text-center dark:border-slate-700 dark:bg-slate-900">
          <h2 className="text-lg font-semibold">No interviews yet</h2>
          <p className="mt-2 text-sm text-slate-500">Your completed practice sessions will appear here.</p>
          <Link to="/setup" className="mt-5 inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700">
            Start an interview <ArrowRight className="h-4 w-4" />
          </Link>
        </section>
      )}
    </div>
  );
}