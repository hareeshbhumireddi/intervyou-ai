export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';
export type Sector = 'Government' | 'Private';

export type ResumeFileMetadata = {
  name: string;
  type: string;
  size: number;
  uploadedAt: string;
};

export type UserProfile = {
  fullName: string;
  dob: string;
  gender: string;
  email: string;
  mobile: string;
  address: string;
  qualification: string;
  preferredLanguage: string;
  education: {
    degree: string;
    college: string;
    specialization: string;
    graduationYear: string;
    cgpa: string;
  };
  skills: string[];
  certificates: { title: string; provider: string; date: string }[];
  resumeUrl?: string;
  resumeFile?: ResumeFileMetadata;
  avatarUrl?: string;
  resumeText?: string;
  stats: {
    totalInterviews: number;
    avgScore: number;
    bestScore: number;
  };
  isCompleted?: boolean;
};

export type JobRole = {
  id: string;
  title: string;
  description: string;
  icon: string;
};

export type Question = {
  id: string;
  question: string;
  category: string;
};

export type InterviewSession = {
  round?: string | null;
  roundLabel?: string | null;
  id: string;
  role: string;
  interviewType?: string;
  status?: 'active' | 'completed';
  sector: Sector;
  difficulty: Difficulty;
  date: string;
  questions: Question[];
  answers: Record<string, string>;
  evaluations: Record<string, EvaluationResult>;
  overallReport?: FinalReport;
  examName?: string;
  department?: string;
  preferredLanguage?: string;
  duration?: string;
  jobId?: string;
  jobTitle?: string;
  companyName?: string;
  category?: string;
  experience?: string;
  qualification?: string;
};

export type EvaluationResult = {
  score: number;
  feedback: string;
  strengths: string[];
  weaknesses: string[];
  improvedAnswer: string;
  metrics: {
    technicalAccuracy: number;
    communication: number;
    confidence: number;
    relevance: number;
    grammar?: number;
    pronunciation?: number;
    fluency?: number;
  };
  missingPoints?: string[];
  isRelevant?: boolean;
  idealAnswer?: string;
  suggestions?: string[];
};

export type FinalReport = {
  overallScore: number;
  result: 'Excellent' | 'Good' | 'Average' | 'Needs Improvement';
  summary: string;
  keyTakeaways: string[];
  careerAdvice: string;
  skillGapAnalysis: Record<string, number>;
  nextSteps: string[];
  detailedMetrics?: {
    eyeContact: number;
    timeManagement: number;
    problemSolving: number;
    logicalThinking: number;
    professionalism: number;
    listeningSkills: number;
    grammar: number;
    pronunciation: number;
    fluency: number;
    accuracy: number;
    relevance: number;
    technicalKnowledge: number;
    communication: number;
    confidence: number;
  };
};

export type JobNotification = {
  id: string;
  company: string;
  title: string;
  sector: 'Private' | 'Government';
  category: string;
  location: string;
  qualification: string;
  experience: string;
  salary?: string;
  lastDate: string;
  releaseDate: string;
  applyLink: string;
  officialWebsite: string;
  status: 'New' | 'Closing Soon' | 'Closed';
  isFeatured?: boolean;
  description?: string;
};

export type NotificationState = {
  notifications: JobNotification[];
  bookmarkedIds: string[];
  readIds: string[];
};

export type SavedJob = {
  id: number;
  jobId?: string;
  title: string;
  company: string;
  location: string;
  applyLink: string;
  savedAt: string;
};


