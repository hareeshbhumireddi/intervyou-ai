import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { UserProfile, InterviewSession, JobNotification } from '../types';
import { ApiError, AUTH_EXPIRED_EVENT, api } from '../utils/api';

const STORAGE_KEY_USER = 'intervyou_user';
const STORAGE_KEY_SESSIONS = 'intervyou_sessions';
const STORAGE_KEY_NOTIFICATIONS = 'intervyou_notifications';
const STORAGE_KEY_BOOKMARKS = 'intervyou_bookmarks';
const STORAGE_KEY_READ = 'intervyou_read';

const defaultUser: UserProfile = {
  fullName: '',
  dob: '',
  gender: '',
  email: '',
  mobile: '',
  address: '',
  qualification: '',
  preferredLanguage: '',
  education: {
    degree: '',
    college: '',
    specialization: '',
    graduationYear: '',
    cgpa: '',
  },
  skills: [],
  certificates: [],
  stats: {
    totalInterviews: 0,
    avgScore: 0,
    bestScore: 0,
  },
  isCompleted: false
};

interface AppContextType {
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  isAuthenticated: boolean;
  authReady: boolean;
  serverUnreachable: boolean;
  aiMode: 'mock' | 'gemini' | 'unconfigured' | null;
  setAuthenticated: (authenticated: boolean) => void;
  refreshSessions: () => Promise<void>;
  sessions: InterviewSession[];
  addSession: (session: InterviewSession) => void;
  updateSession: (session: InterviewSession) => void;
  notifications: JobNotification[];
  bookmarkedIds: string[];
  readIds: string[];
  addNotification: (notification: JobNotification) => void;
  updateNotification: (notification: JobNotification) => void;
  deleteNotification: (id: string) => void;
  toggleBookmark: (id: string) => void;
  markAsRead: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setAuthenticatedState] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const [serverUnreachable, setServerUnreachable] = useState(false);
  const [aiMode, setAiMode] = useState<'mock' | 'gemini' | 'unconfigured' | null>(null);
  // The server session is the only proof of identity. Profile data and interview
  // history are loaded from the API after sign-in and are never read back from
  // localStorage, so a stale browser copy can neither fake a login nor leak
  // one person's data to the next person on a shared computer.
  const [user, setUser] = useState<UserProfile>(defaultUser);
  const [sessions, setSessions] = useState<InterviewSession[]>([]);

  const [notifications, setNotifications] = useState<JobNotification[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_NOTIFICATIONS);
    return saved ? JSON.parse(saved) : [
      {
        id: '1',
        company: 'Google',
        title: 'Software Engineer III',
        sector: 'Private',
        category: 'Software',
        location: 'Hyderabad, India',
        qualification: 'B.Tech/M.Tech',
        experience: '2-4 Years',
        salary: '25-45 LPA',
        lastDate: '2026-08-15',
        releaseDate: '2026-07-25',
        applyLink: 'https://careers.google.com',
        officialWebsite: 'https://google.com',
        status: 'New',
        isFeatured: true,
        description: 'Design, develop, test, deploy, maintain and improve software.'
      },
      {
        id: '2',
        company: 'UPSC',
        title: 'Civil Services Examination 2026',
        sector: 'Government',
        category: 'UPSC',
        location: 'All India',
        qualification: 'Any Degree',
        experience: 'Freshers',
        salary: '7th Pay Commission',
        lastDate: '2026-08-10',
        releaseDate: '2026-07-20',
        applyLink: 'https://upsc.gov.in',
        officialWebsite: 'https://upsc.gov.in',
        status: 'Closing Soon',
        isFeatured: true,
        description: 'Recruitment for IAS, IPS, IFS and other central services.'
      },
      {
        id: '3',
        company: 'Microsoft',
        title: 'Data Analyst Intern',
        sector: 'Private',
        category: 'Internship',
        location: 'Bangalore, India',
        qualification: 'Final Year Student',
        experience: 'Freshers',
        salary: '1.2 Lakhs/Month',
        lastDate: '2026-08-05',
        releaseDate: '2026-07-28',
        applyLink: 'https://careers.microsoft.com',
        officialWebsite: 'https://microsoft.com',
        status: 'New',
        isFeatured: false,
        description: 'Work with data scientists to analyze large data sets.'
      },
      {
        id: '4',
        company: 'SBI',
        title: 'Probationary Officers (PO) 2026',
        sector: 'Government',
        category: 'Banking',
        location: 'All India',
        qualification: 'Graduation in any discipline',
        experience: 'Freshers',
        salary: '8.5 - 13 LPA',
        lastDate: '2026-08-20',
        releaseDate: '2026-07-29',
        applyLink: 'https://sbi.co.in/careers',
        officialWebsite: 'https://sbi.co.in',
        status: 'New',
        isFeatured: true,
        description: 'Recruitment of Probationary Officers in State Bank of India.'
      },
      {
        id: '5',
        company: 'Amazon',
        title: 'SDE-1 (New Grad)',
        sector: 'Private',
        category: 'Software',
        location: 'Bangalore/Hyderabad',
        qualification: 'B.E/B.Tech/CS',
        experience: 'Freshers',
        salary: '18-32 LPA',
        lastDate: '2026-08-12',
        releaseDate: '2026-07-29',
        applyLink: 'https://amazon.jobs',
        officialWebsite: 'https://amazon.com',
        status: 'New',
        isFeatured: true,
        description: 'Solve complex problems and build scalable systems at Amazon.'
      },
      {
        id: '6',
        company: 'SSC',
        title: 'Combined Graduate Level (CGL)',
        sector: 'Government',
        category: 'SSC',
        location: 'All India',
        qualification: 'Bachelor\'s Degree',
        experience: 'Freshers',
        salary: 'Level 4 to Level 8',
        lastDate: '2026-08-25',
        releaseDate: '2026-07-27',
        applyLink: 'https://ssc.nic.in',
        officialWebsite: 'https://ssc.nic.in',
        status: 'New',
        isFeatured: false,
        description: 'Group B and C posts in various Ministries and Departments.'
      },
      {
        id: '7',
        company: 'TCS',
        title: 'Ninja Recruitment 2026',
        sector: 'Private',
        category: 'Software',
        location: 'Pan India',
        qualification: 'B.E/B.Tech/M.E/M.Tech/MCA/M.Sc',
        experience: 'Freshers (2026 Batch)',
        salary: '3.36 - 3.96 LPA',
        lastDate: '2026-08-18',
        releaseDate: '2026-07-28',
        applyLink: 'https://nextstep.tcs.com',
        officialWebsite: 'https://tcs.com',
        status: 'New',
        isFeatured: false,
        description: 'Off-campus hiring for the 2026 batch of engineering graduates.'
      },
      {
        id: '8',
        company: 'ISRO',
        title: 'Scientist/Engineer \'SC\'',
        sector: 'Government',
        category: 'Scientific',
        location: 'Bangalore/Sriharikota',
        qualification: 'B.E/B.Tech in First Class',
        experience: 'Freshers',
        salary: 'Level 10 Pay Matrix',
        lastDate: '2026-08-22',
        releaseDate: '2026-07-26',
        applyLink: 'https://isro.gov.in',
        officialWebsite: 'https://isro.gov.in',
        status: 'New',
        isFeatured: true,
        description: 'Join the Indian Space Research Organisation as a Scientist.'
      }
    ];
  });

  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_BOOKMARKS);
    return saved ? JSON.parse(saved) : [];
  });

  const [readIds, setReadIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_READ);
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    let isActive = true;

    api.me()
      .then(({ user: authenticatedUser }) => {
        if (isActive) {
          setUser((current) => ({ ...current, ...authenticatedUser }));
          setAuthenticatedState(true);
        }
      })
      .catch((error) => {
        if (isActive) {
          setAuthenticatedState(false);
          setServerUnreachable(error instanceof ApiError && error.status === 0);
        }
      })
      .finally(() => {
        if (isActive) setAuthReady(true);
      });

    api.config().then((config) => { if (isActive) setAiMode(config.aiMode); }).catch(() => undefined);

    return () => { isActive = false; };
  }, []);

  const refreshSessions = async () => {
    const [{ interviews }, { performance }] = await Promise.all([api.listInterviews(), api.performance()]);
    setSessions(interviews);
    setUser((current) => ({
      ...current,
      stats: {
        totalInterviews: performance.totalInterviews,
        avgScore: performance.averageScore,
        bestScore: performance.bestScore,
      },
    }));
  };

  useEffect(() => {
    if (!authReady || !isAuthenticated) return;
    refreshSessions().catch((error) => console.error('Could not load interview history:', error));
  }, [authReady, isAuthenticated]);

  useEffect(() => {
    const onExpired = () => setAuthenticated(false);
    window.addEventListener(AUTH_EXPIRED_EVENT, onExpired);
    return () => window.removeEventListener(AUTH_EXPIRED_EVENT, onExpired);
  }, []);

  const setAuthenticated = (authenticated: boolean) => {
    setAuthenticatedState(authenticated);
    if (!authenticated) {
      setSessions([]);
      setUser(defaultUser);
      // Remove data written by older versions of the app.
      localStorage.removeItem(STORAGE_KEY_USER);
      localStorage.removeItem(STORAGE_KEY_SESSIONS);
    }
  };

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_BOOKMARKS, JSON.stringify(bookmarkedIds));
  }, [bookmarkedIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_READ, JSON.stringify(readIds));
  }, [readIds]);

  const addSession = (session: InterviewSession) => {
    setSessions(prev => [session, ...prev]);
    
    const total = sessions.length + 1;
    const scores = sessions.map(s => s.overallReport?.overallScore || 0);
    const currentScore = session.overallReport?.overallScore || 0;
    const avg = ([...scores, currentScore].reduce((a, b) => a + b, 0)) / total;
    const best = Math.max(...scores, currentScore);

    setUser(prev => ({
      ...prev,
      stats: {
        totalInterviews: total,
        avgScore: Math.round(avg),
        bestScore: best,
      }
    }));
  };

  const updateSession = (updatedSession: InterviewSession) => {
    setSessions(prev => prev.map(s => s.id === updatedSession.id ? updatedSession : s));
    
    const reportScore = updatedSession.overallReport?.overallScore;
    if (reportScore !== undefined) {
      const allSessions = sessions.map(s => s.id === updatedSession.id ? updatedSession : s);
      const total = allSessions.length;
      const scores = allSessions.map(s => s.overallReport?.overallScore || 0);
      const avg = scores.reduce((a, b) => a + b, 0) / total;
      const best = Math.max(...scores);

      setUser(prev => ({
        ...prev,
        stats: {
          totalInterviews: total,
          avgScore: Math.round(avg),
          bestScore: best,
        }
      }));
    }
  };

  const addNotification = (notification: JobNotification) => {
    setNotifications(prev => [notification, ...prev]);
  };

  const updateNotification = (updated: JobNotification) => {
    setNotifications(prev => prev.map(n => n.id === updated.id ? updated : n));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const toggleBookmark = (id: string) => {
    setBookmarkedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const markAsRead = (id: string) => {
    if (!readIds.includes(id)) {
      setReadIds(prev => [...prev, id]);
    }
  };

  return (
    <AppContext.Provider value={{ 
      user, 
      setUser, 
      isAuthenticated,
      authReady,
      serverUnreachable,
      aiMode,
      setAuthenticated,
      refreshSessions,
      sessions, 
      addSession, 
      updateSession,
      notifications,
      bookmarkedIds,
      readIds,
      addNotification,
      updateNotification,
      deleteNotification,
      toggleBookmark,
      markAsRead
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppState() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppState must be used within an AppStateProvider');
  }
  return context;
}
