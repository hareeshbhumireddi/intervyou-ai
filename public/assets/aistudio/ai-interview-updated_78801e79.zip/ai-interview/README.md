# Intervyou AI

Intervyou is a React/TypeScript interview-practice application with a Flask API backend. The frontend uses Vite, React Router, and Tailwind CSS. Flask provides authenticated APIs and persists users, resumes, interviews, questions, answers, performance, history, and saved jobs in MySQL through SQLAlchemy.

## Requirements

- Node.js 20+ and npm.
- Python 3.10+.
- MySQL 8+ (or a compatible MySQL server).
- A Gemini API key for generating questions, evaluating answers, and producing reports.
- A modern browser. Camera/microphone features require browser permission; speech-recognition support varies by browser.

## Install

From the repository root, install frontend dependencies:

```powershell
npm.cmd ci
```

Create and activate a Python virtual environment, then install the Flask requirements:

```powershell
py -3 -m venv backend/.venv
backend/.venv/Scripts/Activate.ps1
python -m pip install -r backend/requirements.txt
Copy-Item backend/.env.example backend/.env
```

Create the requested MySQL database. From a shell with the MySQL client installed:

```powershell
mysql -u root -p < backend/init_db.sql
```

Create a dedicated application account and grant it access (replace the example password locally in your MySQL client):

```sql
CREATE USER 'ai_interview_app'@'localhost' IDENTIFIED BY 'choose-a-strong-password';
GRANT ALL PRIVILEGES ON ai_interview_db.* TO 'ai_interview_app'@'localhost';
FLUSH PRIVILEGES;
```

Edit `backend/.env` and set `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_HOST`, `MYSQL_PORT`, and `MYSQL_DATABASE=ai_interview_db`. Also set a long random `SECRET_KEY` and `GEMINI_API_KEY`. Never put database credentials or the Gemini key in frontend code or a `VITE_` variable, and never commit `.env` files.

macOS/Linux equivalents:

```sh
npm ci
python3 -m venv backend/.venv
. backend/.venv/bin/activate
python -m pip install -r backend/requirements.txt
cp backend/.env.example backend/.env
```

## Run Locally

Start Flask in one terminal:

```powershell
python backend/app.py
```

It listens on `http://127.0.0.1:5000` by default. In a second terminal, start the existing Express/Vite host, which proxies `/api` requests and session cookies to Flask:

```powershell
npm.cmd run dev:server
```

Open [http://localhost:3000](http://localhost:3000). The frontend and API proxy share an origin, including the HttpOnly session cookie.

Alternatively, run Vite directly with `npm.cmd run dev` and open [http://localhost:5173](http://localhost:5173); `vite.config.ts` proxies `/api` to Flask. For a direct frontend-to-Flask connection, set `VITE_API_URL=http://127.0.0.1:5000/api` and add the exact frontend origin to `FRONTEND_ORIGINS` in `backend/.env`.

The root `.env.example` is for frontend/Vite settings. Flask reads `backend/.env`.

For a production build, keep Flask running and start the bundled Express/static frontend proxy:

```powershell
npm.cmd run build
$env:NODE_ENV = "production"
npm.cmd start
```

Set `FLASK_API_URL` to the Flask origin if it is not `http://127.0.0.1:5000`. The Express host defaults to port `3000`; override with `PORT`.

## Database And Files

The provided MySQL environment template targets `ai_interview_db`. Configure it with the `MYSQL_*` variables in `backend/.env`, or provide a SQLAlchemy `DATABASE_URL` such as `mysql+pymysql://user:password@127.0.0.1:3306/ai_interview_db?charset=utf8mb4`. `DATABASE_URL` takes precedence. If neither MySQL nor a URL is configured, local development falls back to SQLite.

Resume files are saved under `backend/instance/uploads` by default; set `UPLOAD_FOLDER` to change that location. The database and uploaded files are ignored by Git. `db.create_all()` creates missing tables on startup; it does not migrate existing SQLite data to MySQL. Existing records must be exported/imported separately if they need to be retained.

SQLAlchemy creates these tables on startup:

- `users`: name, unique email, password hash, registration profile, and creation timestamp.
- `resumes`: one current resume per user, including filename, MIME type, size, and server-side file path.
- `interviews`: type/role, date, status, score, and generated report.
- `questions`: ordered interview questions and repeat counts.
- `answers`: submitted/skipped answers, evaluations, and scores.
- `performance`: score and correct/incorrect answer counts per completed interview.
- `interview_history`: completed interview history for the current user.
- `saved_jobs`: job title, company, location, URL, and saved date per user.

`backend/init_db.sql` creates the database; SQLAlchemy creates missing tables on Flask startup. `db.create_all()` is not a schema migration tool and does not copy existing SQLite records into MySQL. Export/import existing users and interview history separately if you need those records in the new database.

## API Routes

All endpoints are under `/api`. Authenticated routes require the HttpOnly Flask session cookie.

| Method and route | Purpose |
| --- | --- |
| `GET /api/health` | Check Flask and database connectivity. |
| `POST /api/auth/register` | Register the onboarding profile and password. |
| `POST /api/auth/login`, `GET /api/auth/me`, `POST /api/auth/logout` | Start, restore, and end a user session. |
| `PUT /api/auth/profile` | Update profile data. |
| `GET/POST/DELETE /api/resumes` | Get metadata, upload/replace, or delete the current resume. |
| `GET /api/resumes/file` | View or download the signed-in user’s resume. |
| `POST /api/interviews` | Start an interview and persist AI-generated questions. |
| `GET /api/interviews`, `GET /api/interviews/<id>` | Retrieve interview history or one session. |
| `POST /api/interviews/<id>/questions/<question_id>/repeat` | Record a repeat action. |
| `POST /api/interviews/<id>/skip` | Persist a skipped question. |
| `POST /api/interviews/<id>/answers` | Evaluate and persist an answer. |
| `POST /api/interviews/<id>/complete` | Save the final report and performance/history records. |
| `GET /api/performance` | Retrieve aggregate score and answer statistics. |
| `GET/POST /api/saved-jobs`, `DELETE /api/saved-jobs/<id>` | List, save, or remove the current user’s saved jobs. |

Flask-CORS allows the configured frontend origins with credentials. In local development, prefer the Vite proxy configured in `vite.config.ts`. Session cookies are HttpOnly and SameSite=Lax; production deployments must use HTTPS and set `SESSION_COOKIE_SECURE=true` and a persistent `SECRET_KEY`.

## Test The Connection

With Flask running, open [http://127.0.0.1:5000/api/health](http://127.0.0.1:5000/api/health). A successful response looks like:

```json
{"status":"ok","database":"ok"}
```

Then open the Vite URL, register through onboarding, sign in, upload a resume, and start a practice interview. Missing/invalid credentials, unavailable Gemini configuration, invalid files, and database failures return JSON errors that the frontend displays.

## Validation

```powershell
npm.cmd run lint
npm.cmd run build
```

`lint` runs TypeScript with `--noEmit`. Python runtime tests require Python and the packages in `backend/requirements.txt`; install them in the virtual environment before running Flask.

## Existing Functionality And Notes

- Interview setup, spoken question playback, repeat, skip, text/speech answers, camera/microphone controls, and report screens remain in the existing React application.
- Questions, answers, reports, performance, and resume files are stored on the Flask backend rather than being generated as frontend fallback data. AI question/evaluation/report endpoints require `GEMINI_API_KEY`; failures are returned to the UI for retry.
- The sample Job Alerts list and browser theme remain frontend-provided data/preferences.
- `server.ts` now hosts the existing Vite frontend and proxies API traffic to Flask; it no longer runs the old Gemini API implementation.

## Key Files

- `backend/app.py` - Flask API, SQLAlchemy models, auth, resumes, interviews, and performance routes.
- `backend/requirements.txt` - Python dependencies.
- `src/utils/api.ts` - credentialed frontend API client and error handling.
- `src/App.tsx` and `src/hooks/useAppState.tsx` - routes, authenticated sidebar, session restoration, and backend history hydration.
- `src/pages/` - existing login, registration, resume, interview, and report UI connected to Flask.

## Authentication, validation and sessions

- **Sessions**: signing in creates a server-side session (`auth_sessions` table). The browser cookie (`intervyou_session`, HttpOnly, SameSite=Lax, `Secure` in production) only holds a random token. Logout revokes the session on the server; sessions expire after `SESSION_LIFETIME_HOURS` (default 168 = 7 days from sign-in).
- **Restarts**: in development, if `SECRET_KEY` is unset a random key is generated once into `backend/instance/.dev_secret_key`, so restarting the backend no longer signs everyone out. Production (`FLASK_ENV=production`) refuses to start without `SECRET_KEY`, `DATABASE_URL`/MySQL settings, and with `AI_PROVIDER=mock`.
- **Validation** is enforced on the backend (`backend/validators.py`) for registration *and* profile updates, and mirrored in `src/utils/validation.ts`:
  name 2-100 letters (spaces, `'`, `-`, `.`), email via `email-validator`, mobile exactly 10 digits starting 6-9, language one of English/Telugu/Hindi, graduation year exactly 4 digits between 1970 and current year + 8, password 8-128 characters.
- **Login** returns the same error for unknown email and wrong password and is throttled per email+IP (`LOGIN_MAX_ATTEMPTS` in `LOGIN_WINDOW_SECONDS`, in-memory per process; use a shared store if you run several processes).

## Mock AI mode (development only)

Set `AI_PROVIDER=mock` in `backend/.env` to try the whole interview flow without a Gemini key. Questions, scores and reports are generated by a fixed, explainable rubric and labelled **simulated** in the UI and API (`simulated: true`). Use `AI_PROVIDER=gemini` plus `GEMINI_API_KEY` for real AI.

## Running the tests

```
# backend (uses an isolated temporary SQLite database)
cd backend && pip install -r requirements-dev.txt && python -m pytest tests -q

# frontend lint, unit tests, build
npm run lint && npm test && npm run build

# browser tests: start the backend (AI_PROVIDER=mock) and `npm run dev:server`, then
npx playwright install chromium && npm run test:e2e
```

## Interview rounds (private sector)

On the setup page choose **Mixed, HR, Technical, Behavioural, Coding or Resume-based**. The round is stored in `interviews.interview_type` (for example `Coding Round`), so no database migration is needed, and it is shown in History (with a round filter) and in the interview room.

- **Coding**: a code editor (Tab indents; choose Python, JavaScript, Java or C++). Answers are scored on approach, complexity awareness, edge cases and code quality. **Code is read, never executed**, and the feedback says so. A timer of 30 minutes is used.
- **Resume-based**: questions come from your uploaded resume (it requires a readable resume and explains what to do if there is none).
- Camera/voice-only measurements (eye contact, pronunciation, listening, time management) are not shown for rounds where they cannot be measured; the report only lists categories that were actually measured.

## ATS score

On **My Resume**, the ATS panel scores the uploaded resume out of 100 using transparent rules (`backend/ats.py`): contact details 10, section structure 20, keyword match 30 (against a pasted job description, or role keywords if none), impact and achievements 15, length and readability 15, parsing safety 10. It lists matched and missing keywords and concrete fixes. It is an **estimate**, not the score any specific employer's ATS would give, and it needs no API key. Scanned/image-only PDFs cannot be read and produce a clear message. Endpoint: `POST /api/resumes/ats` with optional `jobDescription`, `role` or `text`.

