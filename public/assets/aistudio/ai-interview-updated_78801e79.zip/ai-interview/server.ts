import express from 'express';
import http from 'node:http';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

const FLASK_API = new URL(process.env.FLASK_API_URL || 'http://127.0.0.1:5000');

async function startServer() {
  const app = express();

  app.use((req, res, next) => {
    if (req.url !== '/api' && !req.url?.startsWith('/api/')) {
      next();
      return;
    }

    const proxyRequest = http.request({
      hostname: FLASK_API.hostname,
      port: Number(FLASK_API.port || 80),
      path: req.url,
      method: req.method,
      headers: { ...req.headers, host: FLASK_API.host },
    }, (upstream) => {
      res.statusCode = upstream.statusCode || 502;
      Object.entries(upstream.headers).forEach(([header, value]) => {
        if (value !== undefined) res.setHeader(header, value);
      });
      upstream.pipe(res);
    });

    proxyRequest.on('error', (error) => {
      console.error('Flask API proxy error:', error.message);
      if (!res.headersSent) {
        res.status(502).json({ error: 'The Flask backend is unavailable. Start backend/app.py and try again.' });
      } else {
        res.destroy(error);
      }
    });

    req.pipe(proxyRequest);
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT || 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`Frontend server and Flask API proxy running on http://localhost:${port}`);
    console.log(`Flask API target: ${FLASK_API.origin}`);
  });
}

startServer().catch((error) => {
  console.error('Could not start the frontend server:', error);
  process.exitCode = 1;
});